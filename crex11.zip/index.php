<?php
require_once __DIR__ . '/includes/auth.php';
$user = getCurrentUser();
if (!$user) {
    header('Location: login.php');
    exit;
}
$db = getDB();

// Fetch settings
$siteName = getSetting('site_name', 'CREX 11');
$siteLogo = getSetting('site_logo');
$primaryColor = getSetting('primary_color', '#1DB954');
$secondaryColor = getSetting('secondary_color', '#1A1A1A');
$accentColor = getSetting('accent_color', '#FACC15');

// Get user balance
$bal = getUserBalance($user['id']);

// Get unread notifications count
$stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE (user_id = ? OR is_global = 1) AND is_read = 0");
$stmt->execute([$user['id']]);
$unreadNotifs = $stmt->fetchColumn();

// Check unread chat messages
$stmt2 = $db->prepare("SELECT COUNT(*) FROM chat_messages WHERE user_id = ? AND sender = 'admin' AND is_read = 0");
$stmt2->execute([$user['id']]);
$unreadChat = $stmt2->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/user.css">
    <style>
        :root {
            --primary-color: <?= htmlspecialchars($primaryColor) ?>;
            --secondary-bg: <?= htmlspecialchars($secondaryColor) ?>;
            --accent-color: <?= htmlspecialchars($accentColor) ?>;
        }
    </style>
</head>
<body>

<!-- App Header -->
<header class="app-header" id="mainHeader">
    <div class="header-left">
        <?php if ($siteLogo): ?>
            <img src="<?= htmlspecialchars($siteLogo) ?>" alt="Logo" class="header-logo">
        <?php else: ?>
            <div class="header-logo-text"><?= htmlspecialchars(substr($siteName,0,1)) ?></div>
        <?php endif; ?>
        <div>
            <div class="header-site-name"><?= htmlspecialchars($siteName) ?></div>
            <div class="header-subtitle">Hi, <?= htmlspecialchars($user['full_name'] ?: $user['username']) ?></div>
        </div>
    </div>
    <div class="header-right">
        <button class="wallet-chip" onclick="showSection('wallet')">
            <i class="bi bi-wallet2"></i>
            <span id="headerBalance">₹<?= number_format($bal['cash_balance'] + $bal['bonus_balance'] + $bal['winning_balance'], 0) ?></span>
        </button>
        <button class="notification-icon" onclick="showSection('notifications')">
            <i class="bi bi-bell"></i>
            <?php if ($unreadNotifs > 0): ?>
                <span class="notification-badge" id="notifBadge"><?= $unreadNotifs ?></span>
            <?php endif; ?>
        </button>
    </div>
</header>

<div id="globalLoader" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:9999;display:none;justify-content:center;align-items:center;">
    <div class="spinner-border" style="color:var(--primary-color);width:3rem;height:3rem;" role="status"></div>
</div>

<div class="main-content">

<!-- HOME SECTION -->
<section id="home" class="section active">
    <!-- Banner Slider -->
    <div class="swiper promoSwiper" style="border-radius:12px;margin-bottom:20px;height:180px;">
        <div class="swiper-wrapper" id="bannerWrapper">
            <div class="swiper-slide" style="background:linear-gradient(135deg,#1DB954,#0f3d1f);display:flex;align-items:center;justify-content:center;border-radius:12px;">
                <div style="text-align:center;color:white;padding:20px;">
                    <h3 style="font-weight:700;">Welcome to <?= htmlspecialchars($siteName) ?></h3>
                    <p>Play Tournaments & Win Real Cash</p>
                </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

    <!-- Live Matches -->
    <div class="section-header">
        <i class="bi bi-circle-fill text-danger pulse-dot"></i>
        <h2 class="section-title">Live Matches</h2>
        <span class="badge bg-danger" id="liveMatchBadge">0</span>
    </div>
    <div id="liveMatchesContainer">
        <div class="empty-state">
            <i class="bi bi-globe"></i>
            <p>No live matches right now</p>
        </div>
    </div>

    <!-- Upcoming Matches -->
    <div class="section-header mt-3">
        <i class="bi bi-calendar3"></i>
        <h2 class="section-title">Upcoming Matches</h2>
        <span class="badge bg-primary" id="upcomingMatchBadge">0</span>
    </div>
    <div id="upcomingMatchesContainer">
        <div class="loading-cards">
            <div class="skeleton-card"></div>
            <div class="skeleton-card"></div>
        </div>
    </div>

    <!-- Tournaments -->
    <div class="section-header mt-3">
        <i class="bi bi-trophy"></i>
        <h2 class="section-title">Tournaments</h2>
    </div>
    <div class="tournament-tabs">
        <button class="tab-btn active" onclick="filterTournaments('upcoming')"><i class="bi bi-clock"></i> Upcoming</button>
        <button class="tab-btn" onclick="filterTournaments('live')"><i class="bi bi-broadcast"></i> Live</button>
        <button class="tab-btn" onclick="filterTournaments('completed')"><i class="bi bi-check-circle"></i> Completed</button>
    </div>
    <div id="tournamentsContainer">
        <div class="loading-cards">
            <div class="skeleton-card"></div>
            <div class="skeleton-card"></div>
        </div>
    </div>
</section>

<!-- MATCHES SECTION -->
<section id="matches" class="section">
    <div class="page-header">
        <i class="bi bi-globe"></i>
        <h2>Matches</h2>
    </div>
    <div class="match-tabs">
        <button class="tab-btn active" onclick="loadMatches('live')">Live</button>
        <button class="tab-btn" onclick="loadMatches('upcoming')">Upcoming</button>
        <button class="tab-btn" onclick="loadMatches('completed')">Completed</button>
    </div>
    <div id="matchesContainer"></div>
</section>

<!-- MY BETS SECTION -->
<section id="mybets" class="section">
    <div class="page-header">
        <i class="bi bi-clipboard-check"></i>
        <h2>My Bets</h2>
    </div>
    <div class="match-tabs">
        <button class="tab-btn active" onclick="loadBets('unsettled')">Unsettled <span class="badge bg-warning text-dark ms-1" id="unsettledCount">0</span></button>
        <button class="tab-btn" onclick="loadBets('settled')">Settled</button>
    </div>
    <div id="betsContainer"></div>
</section>

<!-- WALLET SECTION -->
<section id="wallet" class="section">
    <div class="page-header">
        <i class="bi bi-wallet2"></i>
        <h2>My Wallet</h2>
    </div>
    
    <!-- Balance Card -->
    <div class="wallet-balance-card">
        <div class="wb-label">TOTAL BALANCE</div>
        <div class="wb-amount" id="walletTotalBalance">₹<?= number_format($bal['cash_balance'] + $bal['bonus_balance'] + $bal['winning_balance'], 2) ?></div>
        <div class="wb-breakdown">
            <div class="wb-item">
                <div class="wb-item-label">DEPOSIT</div>
                <div class="wb-item-value text-primary" id="wbDeposit">₹<?= number_format($bal['cash_balance'], 2) ?></div>
            </div>
            <div class="wb-item">
                <div class="wb-item-label">BONUS</div>
                <div class="wb-item-value text-warning" id="wbBonus">₹<?= number_format($bal['bonus_balance'], 2) ?></div>
            </div>
            <div class="wb-item">
                <div class="wb-item-label">WINNINGS</div>
                <div class="wb-item-value text-success" id="wbWinnings">₹<?= number_format($bal['winning_balance'], 2) ?></div>
            </div>
        </div>
    </div>

    <div class="wallet-actions">
        <button class="btn-add-money" onclick="showDepositModal()">
            <i class="bi bi-plus-circle"></i> Add Money
        </button>
        <button class="btn-withdraw" onclick="showWithdrawModal()">
            <i class="bi bi-arrow-down-circle"></i> Withdraw
        </button>
    </div>

    <!-- Coupon -->
    <div class="coupon-box custom-card">
        <i class="bi bi-ticket-perforated text-warning"></i>
        <input type="text" id="couponInput" placeholder="Enter coupon code" class="coupon-input">
        <button onclick="applyCoupon()" class="btn-coupon">Apply</button>
    </div>
    <div id="couponStatus" class="mt-2"></div>

    <!-- Transactions -->
    <div class="match-tabs mt-3">
        <button class="tab-btn active" onclick="loadTransactions('all')">Transactions</button>
        <button class="tab-btn" onclick="loadTransactions('withdrawals')">Withdrawals</button>
        <button class="tab-btn" onclick="loadTransactions('deposits')">Deposits</button>
    </div>
    <div id="transactionsContainer" class="mt-2"></div>
</section>

<!-- PROFILE SECTION -->
<section id="profile" class="section">
    <div class="profile-header-card">
        <div class="profile-avatar-wrapper">
            <img src="<?= $user['avatar'] ? htmlspecialchars($user['avatar']) : 'assets/images/default-avatar.png' ?>" 
                 alt="Avatar" class="profile-avatar" id="profileAvatar">
            <label for="avatarUploadInput" class="avatar-edit-btn">
                <i class="bi bi-pencil-fill"></i>
            </label>
            <input type="file" id="avatarUploadInput" style="display:none;" accept="image/*" onchange="uploadAvatar(this)">
        </div>
        <div class="profile-name"><?= htmlspecialchars($user['full_name'] ?: $user['username']) ?></div>
        <div class="profile-username">@<?= htmlspecialchars($user['username']) ?></div>
        <?php if ($user['kyc_status'] !== 'verified'): ?>
            <span class="badge bg-warning text-dark"><?= strtoupper($user['kyc_status']) ?></span>
        <?php else: ?>
            <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>VERIFIED</span>
        <?php endif; ?>
    </div>

    <!-- Stats -->
    <div class="profile-stats">
        <div class="stat-item">
            <strong>₹<?= number_format($bal['cash_balance'] + $bal['bonus_balance'] + $bal['winning_balance'], 0) ?></strong>
            <span>Balance</span>
        </div>
        <div class="stat-item">
            <strong><?= $user['total_bets'] ?></strong>
            <span>Total Bets</span>
        </div>
        <div class="stat-item">
            <strong><?= $user['total_wins'] ?></strong>
            <span>Wins</span>
        </div>
    </div>

    <!-- Referral -->
    <div class="referral-card">
        <div class="ref-label">REFERRAL CODE</div>
        <div class="ref-code" id="myRefCode"><?= htmlspecialchars($user['referral_code']) ?></div>
        <button class="btn-copy-ref" onclick="copyReferral()">
            <i class="bi bi-clipboard"></i> Copy
        </button>
        <button class="btn-share-ref" onclick="shareReferral()">
            <i class="bi bi-share"></i> Share
        </button>
    </div>

    <!-- Profile Menu -->
    <div class="profile-menu">
        <a class="menu-item" onclick="showPage('edit-profile')">
            <i class="bi bi-pencil-square text-primary"></i>
            <span>Edit Profile</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showPage('kyc')">
            <i class="bi bi-shield-check text-success"></i>
            <span>KYC Verification</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showPage('bank-details')">
            <i class="bi bi-bank text-warning"></i>
            <span>Bank Details</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showSection('notifications')">
            <i class="bi bi-bell text-info"></i>
            <span>Notifications</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showPage('referral-program')">
            <i class="bi bi-people-fill text-purple" style="color:#a855f7"></i>
            <span>Referral Program</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showModal('termsModal')">
            <i class="bi bi-file-text text-secondary"></i>
            <span>Terms of Service</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showModal('privacyModal')">
            <i class="bi bi-shield text-secondary"></i>
            <span>Privacy Policy</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item" onclick="showModal('helpModal')">
            <i class="bi bi-question-circle text-secondary"></i>
            <span>Help & FAQ</span>
            <i class="bi bi-chevron-right"></i>
        </a>
        <a class="menu-item text-danger" onclick="doLogout()">
            <i class="bi bi-box-arrow-right text-danger"></i>
            <span>Logout</span>
            <i class="bi bi-chevron-right"></i>
        </a>
    </div>
    <div class="text-center text-muted small mt-3">v2.0 · <?= htmlspecialchars($siteName) ?></div>
</section>

<!-- NOTIFICATIONS SECTION -->
<section id="notifications" class="section">
    <div class="page-header">
        <i class="bi bi-bell"></i>
        <h2>Notifications</h2>
    </div>
    <div id="notificationsContainer"></div>
</section>

<!-- SUBPAGES (hidden by default) -->
<!-- Edit Profile Page -->
<section id="page-edit-profile" class="section">
    <div class="page-header with-back">
        <button class="back-btn" onclick="hidePage('edit-profile')"><i class="bi bi-arrow-left"></i></button>
        <h2>Edit Profile</h2>
    </div>
    <form id="editProfileForm" onsubmit="updateProfile(event)" class="custom-card">
        <div class="mb-3 text-center">
            <img src="<?= $user['avatar'] ? htmlspecialchars($user['avatar']) : 'assets/images/default-avatar.png' ?>" 
                 class="profile-avatar mb-2" id="editAvatar" style="width:80px;height:80px;">
            <label for="avatarInput2" class="btn btn-sm btn-outline-secondary d-block">
                <i class="bi bi-camera"></i> Change Photo
            </label>
            <input type="file" id="avatarInput2" style="display:none;" accept="image/*" onchange="uploadAvatarEdit(this)">
        </div>
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="tel" class="form-control" name="phone" value="<?= htmlspecialchars($user['phone']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">New Password (leave blank to keep)</label>
            <input type="password" class="form-control" name="new_password" placeholder="Enter new password">
        </div>
        <div id="editProfileStatus" class="mb-3"></div>
        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-check2"></i> Save Changes</button>
    </form>
</section>

<!-- KYC Page -->
<section id="page-kyc" class="section">
    <div class="page-header with-back">
        <button class="back-btn" onclick="hidePage('kyc')"><i class="bi bi-arrow-left"></i></button>
        <h2>KYC Verification</h2>
    </div>
    <div id="kycContent"></div>
</section>

<!-- Bank Details Page -->
<section id="page-bank-details" class="section">
    <div class="page-header with-back">
        <button class="back-btn" onclick="hidePage('bank-details')"><i class="bi bi-arrow-left"></i></button>
        <h2>Bank Details</h2>
    </div>
    <form id="bankDetailsForm" onsubmit="saveBankDetails(event)" class="custom-card">
        <h6 class="mb-3"><i class="bi bi-phone"></i> UPI Details</h6>
        <div class="mb-3">
            <label class="form-label">UPI ID</label>
            <input type="text" class="form-control" name="upi_id" value="<?= htmlspecialchars($user['upi_id']) ?>" placeholder="yourname@upi">
        </div>
        <hr>
        <h6 class="mb-3"><i class="bi bi-bank"></i> Bank Account</h6>
        <div class="mb-3">
            <label class="form-label">Account Holder Name</label>
            <input type="text" class="form-control" name="account_holder" value="<?= htmlspecialchars($user['account_holder']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Account Number</label>
            <input type="text" class="form-control" name="bank_account" value="<?= htmlspecialchars($user['bank_account']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">IFSC Code</label>
            <input type="text" class="form-control" name="bank_ifsc" value="<?= htmlspecialchars($user['bank_ifsc']) ?>" placeholder="SBIN0000123">
        </div>
        <div class="mb-3">
            <label class="form-label">Bank Name</label>
            <input type="text" class="form-control" name="bank_name" value="<?= htmlspecialchars($user['bank_name']) ?>">
        </div>
        <div id="bankStatus" class="mb-2"></div>
        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-save"></i> Save Details</button>
    </form>
</section>

<!-- Referral Program Page -->
<section id="page-referral-program" class="section">
    <div class="page-header with-back">
        <button class="back-btn" onclick="hidePage('referral-program')"><i class="bi bi-arrow-left"></i></button>
        <h2>Referral Program</h2>
    </div>
    <div class="custom-card text-center mb-3">
        <i class="bi bi-gift" style="font-size:2.5rem;color:var(--accent-color);"></i>
        <h5 class="mt-2">Invite Friends & Earn</h5>
        <p class="text-muted small" id="referralBonusText">Loading...</p>
        <div class="referral-card mt-3">
            <div class="ref-code"><?= htmlspecialchars($user['referral_code']) ?></div>
            <button class="btn-copy-ref mt-2" onclick="copyReferral()"><i class="bi bi-clipboard"></i> Copy Code</button>
            <button class="btn-share-ref mt-2 ms-2" onclick="shareReferral()"><i class="bi bi-whatsapp"></i> Share</button>
        </div>
    </div>
    <div class="custom-card">
        <h6>Your Referrals</h6>
        <div id="referralsList"><div class="text-center text-muted py-3">Loading...</div></div>
    </div>
</section>

<!-- MATCH DETAIL MODAL -->
<div class="modal fade" id="matchDetailModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="matchDetailTitle">Match Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="matchDetailBody"></div>
        </div>
    </div>
</div>

<!-- BET MODAL -->
<div class="modal fade" id="betModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Place Your Bet</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="bet-teams" id="betTeamsDisplay"></div>
                <div class="mb-3">
                    <label class="form-label">Your Pick</label>
                    <div id="betPickDisplay" class="bet-pick-display"></div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Bet Amount (₹)</label>
                    <input type="number" class="form-control" id="betAmount" min="10" placeholder="Enter amount">
                    <div class="amount-presets mt-2">
                        <button onclick="setBetAmount(50)" class="preset-btn">₹50</button>
                        <button onclick="setBetAmount(100)" class="preset-btn">₹100</button>
                        <button onclick="setBetAmount(200)" class="preset-btn">₹200</button>
                        <button onclick="setBetAmount(500)" class="preset-btn">₹500</button>
                    </div>
                </div>
                <div class="bet-summary">
                    <div class="d-flex justify-content-between">
                        <span class="text-muted">Potential Win:</span>
                        <strong class="text-success" id="potentialWin">₹0.00</strong>
                    </div>
                    <div class="d-flex justify-content-between mt-1">
                        <span class="text-muted">Odds:</span>
                        <span id="betOdds">1.9x</span>
                    </div>
                </div>
                <div id="betStatus" class="mt-2"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitBet()">
                    <i class="bi bi-check2-circle"></i> Place Bet
                </button>
            </div>
        </div>
    </div>
</div>

<!-- DEPOSIT MODAL -->
<div class="modal fade" id="depositModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add Money</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="depositModalBody">
                <!-- Step 1: Amount -->
                <div id="depositStep1">
                    <label class="form-label">ENTER AMOUNT (₹)</label>
                    <input type="number" class="form-control form-control-lg" id="depositAmountInput" placeholder="Min ₹100">
                    <small class="text-muted" id="depositLimits">Min: ₹100 · Max: ₹1,00,000</small>
                    <div class="amount-presets mt-3">
                        <button onclick="setDeposit(100)" class="preset-btn">₹100</button>
                        <button onclick="setDeposit(500)" class="preset-btn">₹500</button>
                        <button onclick="setDeposit(1000)" class="preset-btn">₹1000</button>
                        <button onclick="setDeposit(2000)" class="preset-btn">₹2000</button>
                        <button onclick="setDeposit(5000)" class="preset-btn">₹5000</button>
                    </div>
                    <button class="btn btn-success w-100 mt-4" onclick="proceedToPayment()">
                        Proceed to Payment <i class="bi bi-arrow-right"></i>
                    </button>
                </div>
                <!-- Step 2: Payment -->
                <div id="depositStep2" style="display:none;">
                    <div class="payment-amount-display">
                        <div class="text-muted small">Amount to Pay</div>
                        <div class="payment-amount" id="payAmountDisplay">₹0</div>
                    </div>
                    <!-- QR Code -->
                    <div class="payment-qr-card" id="qrCard"></div>
                    <!-- UPI ID -->
                    <div class="upi-display" id="upiDisplay"></div>
                    <div class="payment-note">
                        <i class="bi bi-info-circle text-primary"></i>
                        Pay to the UPI ID shown and upload your payment receipt with UTR number for verification.
                    </div>
                    <div class="how-to-pay">
                        <strong>How to Pay:</strong>
                        <div class="step-item"><span class="step-num">1</span> Scan QR code or copy UPI ID</div>
                        <div class="step-item"><span class="step-num" style="background:#F59E0B">2</span> Pay from any UPI app</div>
                        <div class="step-item"><span class="step-num" style="background:#1DB954">3</span> Note the UTR/Transaction ID</div>
                        <div class="step-item"><span class="step-num" style="background:#EF4444">4</span> Enter UTR below & upload receipt</div>
                    </div>
                    <div class="submit-payment-card">
                        <h6>Submit Payment Proof</h6>
                        <div class="mb-3">
                            <label class="form-label">UTR / TRANSACTION ID *</label>
                            <input type="text" class="form-control" id="utrInput" placeholder="Enter 6-12 digit UTR number">
                            <small class="text-muted">Find this in your UPI app under payment history</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">UPLOAD RECEIPT (OPTIONAL)</label>
                            <div class="upload-area" onclick="document.getElementById('receiptFile').click()">
                                <i class="bi bi-cloud-upload"></i>
                                <p>Tap to upload payment screenshot</p>
                                <small>JPG / PNG · Max 5MB</small>
                                <input type="file" id="receiptFile" style="display:none;" accept="image/*" onchange="previewReceipt(this)">
                            </div>
                            <div id="receiptPreview" style="display:none;margin-top:8px;">
                                <img id="receiptPreviewImg" style="max-width:100%;border-radius:8px;max-height:150px;">
                            </div>
                        </div>
                        <div id="depositSubmitStatus" class="mb-2"></div>
                        <button class="btn btn-success w-100" onclick="submitDeposit()">
                            <i class="bi bi-check-circle"></i> Submit Payment
                        </button>
                        <button class="btn btn-link w-100 mt-2" onclick="goBackDeposit()">
                            <i class="bi bi-arrow-left"></i> Back
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- WITHDRAW MODAL -->
<div class="modal fade" id="withdrawModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-arrow-down-circle me-2"></i>Withdraw Winnings</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2">
                    <span class="text-muted">Withdrawable balance: </span>
                    <strong class="text-success" id="withdrawableBalance">₹0.00</strong>
                </div>
                <div class="match-tabs mb-3">
                    <button class="tab-btn active" onclick="switchWithdrawTab('upi')">UPI</button>
                    <button class="tab-btn" onclick="switchWithdrawTab('bank')">Bank Transfer</button>
                </div>
                <!-- UPI Tab -->
                <div id="withdrawUpiTab">
                    <div class="mb-3">
                        <label class="form-label">YOUR UPI ID</label>
                        <input type="text" class="form-control" id="withdrawUpiId" placeholder="name@upi" value="<?= htmlspecialchars($user['upi_id']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">AMOUNT (₹)</label>
                        <input type="number" class="form-control" id="withdrawAmountUpi" placeholder="Enter amount">
                    </div>
                    <div id="withdrawUpiStatus" class="mb-2"></div>
                    <button class="btn btn-primary w-100" onclick="submitWithdrawal('upi')">Submit Withdrawal</button>
                </div>
                <!-- Bank Tab -->
                <div id="withdrawBankTab" style="display:none;">
                    <div class="mb-2">
                        <label class="form-label">ACCOUNT HOLDER NAME</label>
                        <input type="text" class="form-control" id="wBankHolder" placeholder="Full name" value="<?= htmlspecialchars($user['account_holder']) ?>">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">ACCOUNT NUMBER</label>
                        <input type="text" class="form-control" id="wBankAccount" placeholder="Account number" value="<?= htmlspecialchars($user['bank_account']) ?>">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">IFSC CODE</label>
                        <input type="text" class="form-control" id="wBankIfsc" placeholder="SBIN0000123" value="<?= htmlspecialchars($user['bank_ifsc']) ?>">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">BANK NAME</label>
                        <input type="text" class="form-control" id="wBankName" placeholder="Bank name" value="<?= htmlspecialchars($user['bank_name']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">AMOUNT (₹)</label>
                        <input type="number" class="form-control" id="withdrawAmountBank" placeholder="Enter amount">
                    </div>
                    <div id="withdrawBankStatus" class="mb-2"></div>
                    <button class="btn btn-primary w-100" onclick="submitWithdrawal('bank')">Submit Withdrawal</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TOURNAMENT JOIN MODAL -->
<div class="modal fade" id="tournamentJoinModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tjModalTitle">Join Tournament</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="tjModalBody"></div>
        </div>
    </div>
</div>

<!-- ROOM ID MODAL -->
<div class="modal fade" id="roomIdModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-key me-2"></i>Room ID & Password</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="roomIdBody"></div>
        </div>
    </div>
</div>

<!-- SUPPORT CHAT -->
<div id="chatWidget" class="chat-widget" style="display:none;">
    <div class="chat-header">
        <div class="chat-header-info">
            <div class="chat-avatar">S</div>
            <div>
                <div class="chat-name">Support Team</div>
                <div class="chat-status"><span class="online-dot"></span> Online</div>
            </div>
        </div>
        <button onclick="closeChatWidget()" style="background:none;border:none;color:white;font-size:1.2rem;"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="chat-messages" id="chatMessages"></div>
    <div class="chat-input-area">
        <input type="text" id="chatInput" placeholder="Type a message..." onkeypress="if(event.key==='Enter')sendChat()">
        <button onclick="sendChat()"><i class="bi bi-send-fill"></i></button>
    </div>
</div>
<button class="chat-fab" onclick="toggleChat()" id="chatFab">
    <i class="bi bi-chat-dots-fill"></i>
    <?php if ($unreadChat > 0): ?>
        <span class="chat-badge" id="chatBadge"><?= $unreadChat ?></span>
    <?php endif; ?>
</button>

<!-- TERMS MODAL -->
<div class="modal fade" id="termsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Terms of Service</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="termsContent" style="white-space:pre-wrap;line-height:1.7;">Loading...</div>
        </div>
    </div>
</div>

<!-- PRIVACY MODAL -->
<div class="modal fade" id="privacyModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Privacy Policy</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="privacyContent" style="white-space:pre-wrap;line-height:1.7;">Loading...</div>
        </div>
    </div>
</div>

<!-- HELP MODAL -->
<div class="modal fade" id="helpModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Help & FAQ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="helpContent" style="white-space:pre-wrap;line-height:1.7;">Loading...</div>
        </div>
    </div>
</div>

</div><!-- /main-content -->

<!-- Bottom Navigation -->
<nav class="bottom-nav">
    <button class="nav-item active" onclick="showSection('home')" id="nav-home">
        <i class="bi bi-house-fill"></i>
        <span>HOME</span>
    </button>
    <button class="nav-item" onclick="showSection('matches')" id="nav-matches">
        <i class="bi bi-globe"></i>
        <span>MATCHES</span>
    </button>
    <button class="nav-item" onclick="showSection('mybets')" id="nav-mybets">
        <i class="bi bi-clipboard-check"></i>
        <span>MY BETS</span>
    </button>
    <button class="nav-item" onclick="showSection('wallet')" id="nav-wallet">
        <i class="bi bi-wallet2"></i>
        <span>WALLET</span>
    </button>
    <button class="nav-item" onclick="showSection('profile')" id="nav-profile">
        <i class="bi bi-person"></i>
        <span>PROFILE</span>
    </button>
</nav>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="assets/js/user.js"></script>
<script>
// Pass PHP data to JS
const APP = {
    userId: <?= $user['id'] ?>,
    username: '<?= htmlspecialchars($user['username']) ?>',
    referralCode: '<?= htmlspecialchars($user['referral_code']) ?>',
    cashBalance: <?= $bal['cash_balance'] ?>,
    bonusBalance: <?= $bal['bonus_balance'] ?>,
    winningBalance: <?= $bal['winning_balance'] ?>,
    siteName: '<?= htmlspecialchars($siteName) ?>'
};

// Init Swiper
const promoSwiper = new Swiper('.promoSwiper', {
    loop: true,
    autoplay: { delay: 3000 },
    pagination: { el: '.swiper-pagination', clickable: true }
});

// Load banners
fetch('api/get_banners.php').then(r=>r.json()).then(data => {
    if (data.success && data.banners.length > 0) {
        const wrapper = document.getElementById('bannerWrapper');
        wrapper.innerHTML = '';
        data.banners.forEach(b => {
            const slide = document.createElement('div');
            slide.className = 'swiper-slide';
            slide.innerHTML = `<img src="${b.image}" style="width:100%;height:180px;object-fit:cover;border-radius:12px;" onclick="${b.link_url ? `window.open('${b.link_url}')` : ''}">`;
            wrapper.appendChild(slide);
        });
        promoSwiper.update();
    }
});
</script>
</body>
</html>

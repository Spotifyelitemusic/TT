-- CREX11 Tournament Platform Database Schema
-- Run this SQL to set up the database

CREATE DATABASE IF NOT EXISTS crex11_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crex11_db;

-- Site Settings
CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255),
    full_name VARCHAR(100),
    phone VARCHAR(20),
    avatar VARCHAR(255) DEFAULT '',
    google_id VARCHAR(100) DEFAULT NULL,
    auth_provider ENUM('email','google') DEFAULT 'email',
    referral_code VARCHAR(20) UNIQUE NOT NULL,
    referred_by INT DEFAULT NULL,
    cash_balance DECIMAL(12,2) DEFAULT 0.00,
    bonus_balance DECIMAL(12,2) DEFAULT 0.00,
    winning_balance DECIMAL(12,2) DEFAULT 0.00,
    total_bets INT DEFAULT 0,
    total_wins INT DEFAULT 0,
    kyc_status ENUM('pending','submitted','verified','rejected') DEFAULT 'pending',
    kyc_doc VARCHAR(255) DEFAULT '',
    upi_id VARCHAR(100) DEFAULT '',
    bank_account VARCHAR(30) DEFAULT '',
    bank_ifsc VARCHAR(20) DEFAULT '',
    bank_name VARCHAR(100) DEFAULT '',
    account_holder VARCHAR(100) DEFAULT '',
    is_active TINYINT(1) DEFAULT 1,
    email_verified TINYINT(1) DEFAULT 0,
    otp VARCHAR(10) DEFAULT '',
    otp_expires DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME DEFAULT NULL,
    INDEX idx_email (email),
    INDEX idx_referral (referral_code)
);

-- Admin Users
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) DEFAULT 'Admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Games
CREATE TABLE IF NOT EXISTS games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(255) DEFAULT '',
    description TEXT,
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tournaments / Matches
CREATE TABLE IF NOT EXISTS tournaments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    banner_image VARCHAR(255) DEFAULT '',
    entry_fee DECIMAL(10,2) DEFAULT 0.00,
    prize_pool DECIMAL(12,2) DEFAULT 0.00,
    max_slots INT DEFAULT 100,
    filled_slots INT DEFAULT 0,
    start_time DATETIME NOT NULL,
    end_time DATETIME DEFAULT NULL,
    status ENUM('upcoming','live','completed','cancelled') DEFAULT 'upcoming',
    game_type VARCHAR(50) DEFAULT '',
    room_id VARCHAR(100) DEFAULT '',
    room_password VARCHAR(100) DEFAULT '',
    rules TEXT,
    prize_distribution TEXT,
    per_kill_prize DECIMAL(10,2) DEFAULT 0.00,
    tournament_type ENUM('solo','duo','squad') DEFAULT 'solo',
    map VARCHAR(100) DEFAULT '',
    version VARCHAR(50) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE SET NULL
);

-- Tournament Registrations
CREATE TABLE IF NOT EXISTS tournament_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tournament_id INT NOT NULL,
    user_id INT NOT NULL,
    team_name VARCHAR(100) DEFAULT '',
    slot_number INT DEFAULT 0,
    status ENUM('registered','confirmed','cancelled','winner') DEFAULT 'registered',
    kills INT DEFAULT 0,
    rank_position INT DEFAULT 0,
    prize_won DECIMAL(10,2) DEFAULT 0.00,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_reg (tournament_id, user_id),
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Matches (for IPL-style betting)
CREATE TABLE IF NOT EXISTS matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team1 VARCHAR(100) NOT NULL,
    team2 VARCHAR(100) NOT NULL,
    team1_logo VARCHAR(255) DEFAULT '',
    team2_logo VARCHAR(255) DEFAULT '',
    match_type VARCHAR(100) DEFAULT 'IPL T20',
    start_time DATETIME NOT NULL,
    status ENUM('upcoming','live','completed','cancelled') DEFAULT 'upcoming',
    winner VARCHAR(100) DEFAULT '',
    odds_team1 DECIMAL(5,2) DEFAULT 1.90,
    odds_team2 DECIMAL(5,2) DEFAULT 1.90,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bets on Matches
CREATE TABLE IF NOT EXISTS bets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    match_id INT NOT NULL,
    pick VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    potential_win DECIMAL(10,2) NOT NULL,
    status ENUM('pending','won','lost','cancelled','refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settled_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
);

-- Transactions
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('deposit','withdrawal','bet','win','refund','bonus','referral','coupon') NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    balance_type ENUM('cash','bonus','winning') DEFAULT 'cash',
    status ENUM('pending','completed','failed','rejected') DEFAULT 'pending',
    reference VARCHAR(100) DEFAULT '',
    utr_number VARCHAR(50) DEFAULT '',
    receipt_image VARCHAR(255) DEFAULT '',
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Withdrawals
CREATE TABLE IF NOT EXISTS withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    method ENUM('upi','bank') DEFAULT 'upi',
    upi_id VARCHAR(100) DEFAULT '',
    account_holder VARCHAR(100) DEFAULT '',
    account_number VARCHAR(30) DEFAULT '',
    ifsc_code VARCHAR(20) DEFAULT '',
    bank_name VARCHAR(100) DEFAULT '',
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Deposits
CREATE TABLE IF NOT EXISTS deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    utr_number VARCHAR(50) DEFAULT '',
    receipt_image VARCHAR(255) DEFAULT '',
    payment_method VARCHAR(50) DEFAULT 'upi',
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info','success','warning','error') DEFAULT 'info',
    is_read TINYINT(1) DEFAULT 0,
    is_global TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Promotions/Banners
CREATE TABLE IF NOT EXISTS promotions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) DEFAULT '',
    image VARCHAR(255) NOT NULL,
    link_url VARCHAR(500) DEFAULT '',
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Coupons
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    balance_type ENUM('cash','bonus','winning') DEFAULT 'bonus',
    max_uses INT DEFAULT 1,
    used_count INT DEFAULT 0,
    expires_at DATETIME NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Coupon Uses
CREATE TABLE IF NOT EXISTS coupon_uses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coupon_id INT NOT NULL,
    user_id INT NOT NULL,
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_use (coupon_id, user_id),
    FOREIGN KEY (coupon_id) REFERENCES coupons(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Chat Messages (Support)
CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    sender ENUM('user','admin') DEFAULT 'user',
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Leaderboard
CREATE TABLE IF NOT EXISTS leaderboard (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tournament_id INT DEFAULT NULL,
    points INT DEFAULT 0,
    rank_position INT DEFAULT 0,
    period VARCHAR(20) DEFAULT 'monthly',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- KYC Verifications  
CREATE TABLE IF NOT EXISTS kyc_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    doc_type ENUM('aadhar','pan','driving','passport') DEFAULT 'aadhar',
    doc_front VARCHAR(255) DEFAULT '',
    doc_back VARCHAR(255) DEFAULT '',
    selfie VARCHAR(255) DEFAULT '',
    status ENUM('pending','verified','rejected') DEFAULT 'pending',
    admin_note TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sessions
CREATE TABLE IF NOT EXISTS user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Default Settings
INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES
('site_name', 'CREX 11'),
('site_logo', ''),
('site_tagline', 'Play & Win'),
('primary_color', '#1DB954'),
('secondary_color', '#1A1A1A'),
('accent_color', '#FACC15'),
('upi_id', 'match11@upi'),
('upi_name', 'Match11 Official'),
('qr_image', ''),
('min_deposit', '100'),
('max_deposit', '100000'),
('min_withdrawal', '100'),
('max_withdrawal', '50000'),
('referral_bonus', '50'),
('referral_bonus_type', 'cash'),
('google_client_id', ''),
('google_client_secret', ''),
('onesignal_app_id', ''),
('onesignal_rest_key', ''),
('maintenance_mode', '0'),
('terms_content', 'Welcome to CREX 11. Please read these terms carefully before using our platform.'),
('privacy_content', 'Your privacy is important to us. We collect and use your data only as described here.'),
('about_content', 'CREX 11 is a premier cricket tournament and prediction platform.'),
('refund_policy', 'Refunds are processed within 3-5 business days.'),
('withdrawal_note', 'Withdrawals are processed within 24-48 hours after approval.');

-- Default Admin (password: admin123 - CHANGE THIS!)
INSERT IGNORE INTO admins (email, password, name) VALUES 
('admin@crex11.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uXPhCDFMG', 'Super Admin');

-- Default Games
INSERT IGNORE INTO games (id, name, image, description, is_active) VALUES
(1, 'BGMI', '', 'Battlegrounds Mobile India', 1),
(2, 'Free Fire', '', 'Free Fire Battle Royale', 1),
(3, 'COD Mobile', '', 'Call of Duty Mobile', 1),
(4, 'Cricket', '', 'Cricket Prediction', 1);

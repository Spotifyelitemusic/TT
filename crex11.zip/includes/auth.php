<?php
require_once __DIR__ . '/../config/database.php';

session_start();

function generateReferralCode() {
    return strtoupper(substr(md5(uniqid(rand(), true)), 0, 10));
}

function generateToken($length = 64) {
    return bin2hex(random_bytes($length));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function createSession($userId) {
    $db = getDB();
    $token = generateToken();
    $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
    $stmt = $db->prepare("INSERT INTO user_sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $token, $expires]);
    setcookie('auth_token', $token, strtotime('+30 days'), '/', '', false, true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['auth_token'] = $token;
    return $token;
}

function getCurrentUser() {
    $db = getDB();
    $token = $_COOKIE['auth_token'] ?? $_SESSION['auth_token'] ?? null;
    if (!$token) return null;
    
    $stmt = $db->prepare("
        SELECT u.* FROM users u 
        JOIN user_sessions s ON s.user_id = u.id 
        WHERE s.session_token = ? AND s.expires_at > NOW() AND u.is_active = 1
    ");
    $stmt->execute([$token]);
    return $stmt->fetch();
}

function requireAuth() {
    $user = getCurrentUser();
    if (!$user) {
        header('Location: /crex11/login.php');
        exit;
    }
    return $user;
}

function requireAdmin() {
    session_start();
    if (empty($_SESSION['admin_id'])) {
        header('Location: /crex11/admin/login.php');
        exit;
    }
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    if (!$admin) {
        session_destroy();
        header('Location: /crex11/admin/login.php');
        exit;
    }
    return $admin;
}

function logout() {
    $db = getDB();
    $token = $_COOKIE['auth_token'] ?? null;
    if ($token) {
        $stmt = $db->prepare("DELETE FROM user_sessions WHERE session_token = ?");
        $stmt->execute([$token]);
    }
    setcookie('auth_token', '', time() - 3600, '/');
    session_destroy();
}

function getUserBalance($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT cash_balance, bonus_balance, winning_balance FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function addBalance($userId, $amount, $type = 'cash', $transType = 'deposit', $note = '', $ref = '') {
    $db = getDB();
    $col = $type === 'bonus' ? 'bonus_balance' : ($type === 'winning' ? 'winning_balance' : 'cash_balance');
    $db->prepare("UPDATE users SET {$col} = {$col} + ? WHERE id = ?")->execute([$amount, $userId]);
    $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_type, status, reference, note) VALUES (?, ?, ?, ?, 'completed', ?, ?)")
       ->execute([$userId, $transType, $amount, $type, $ref, $note]);
}

function deductBalance($userId, $amount, $type = 'cash') {
    $db = getDB();
    $col = $type === 'bonus' ? 'bonus_balance' : ($type === 'winning' ? 'winning_balance' : 'cash_balance');
    $stmt = $db->prepare("UPDATE users SET {$col} = {$col} - ? WHERE id = ? AND {$col} >= ?");
    $stmt->execute([$amount, $userId, $amount]);
    return $stmt->rowCount() > 0;
}

function sendNotification($userId, $title, $message, $type = 'info') {
    $db = getDB();
    $db->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)")
       ->execute([$userId, $title, $message, $type]);
}

function jsonResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function uploadFile($file, $folder = 'uploads', $allowed = ['jpg','jpeg','png','gif','webp']) {
    $uploadDir = __DIR__ . '/../assets/uploads/' . $folder . '/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return ['success' => false, 'message' => 'Invalid file type'];
    if ($file['size'] > 5 * 1024 * 1024) return ['success' => false, 'message' => 'File too large (max 5MB)'];
    
    $filename = uniqid() . '_' . time() . '.' . $ext;
    $destination = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'path' => 'assets/uploads/' . $folder . '/' . $filename];
    }
    return ['success' => false, 'message' => 'Upload failed'];
}

// CREX 11 Admin JS
let currentChatUserId = null;
let chatPoll = null;
let currentUsersPage = 1;
const perPage = 20;

// ---- NAVIGATION ----
function loadSection(name) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    const sec = document.getElementById('sec-' + name);
    if (sec) sec.classList.add('active');
    document.getElementById('adminPageTitle').textContent = name.charAt(0).toUpperCase() + name.slice(1).replace('-',' ');
    document.querySelectorAll('.nav-link[data-section]').forEach(l => l.classList.toggle('active', l.dataset.section === name));
    
    const loaders = {
        users: () => loadUsers(),
        deposits: () => loadDeposits(),
        withdrawals: () => loadWithdrawals(),
        tournaments: () => loadTournaments(),
        'tourn-manage': () => loadTournamentManage(),
        matches: () => loadMatches(),
        games: () => loadGames(),
        promotions: () => loadBanners(),
        coupons: () => loadCoupons(),
        kyc: () => loadKYC(),
        leaderboard: () => loadLeaderboard(),
        chat: () => loadChatUsers(),
        analytics: () => loadAnalytics(),
        settings: () => initSettingsContent()
    };
    if (loaders[name]) loaders[name]();
    if (name !== 'chat' && chatPoll) { clearInterval(chatPoll); chatPoll = null; }
}

// ---- UTILS ----
function showAlert(msg, type = 'success') {
    const el = document.getElementById('alertBox');
    el.textContent = msg;
    el.className = `custom-alert ${type === 'error' ? 'error' : ''}`;
    void el.offsetWidth;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3000);
}

function showLoader(show) {
    document.getElementById('adminLoader').style.display = show ? 'flex' : 'none';
}

function adminStatus(id, msg, type='success') {
    const el = document.getElementById(id);
    if (!el) return;
    const colors = {success:'#22C55E',error:'#EF4444',warning:'#F59E0B',info:'#3B82F6'};
    el.innerHTML = `<div style="padding:8px 12px;border-radius:8px;background:${colors[type]}15;border:1px solid ${colors[type]}40;color:${colors[type]};font-size:0.85rem;">${msg}</div>`;
}

async function adminAPI(url, data = null) {
    const opts = { method: data ? 'POST' : 'GET' };
    if (data) {
        if (data instanceof FormData) opts.body = data;
        else { opts.headers = {'Content-Type':'application/json'}; opts.body = JSON.stringify(data); }
    }
    const res = await fetch(url, opts);
    return res.json();
}

function statusBadge(s) {
    return `<span class="status-badge status-${s}">${s.charAt(0).toUpperCase()+s.slice(1)}</span>`;
}

function previewImage(src) {
    document.getElementById('previewImg').src = src;
    new bootstrap.Modal(document.getElementById('imgPreviewModal')).show();
}

function timeAgo(dt) {
    const d = Math.floor((Date.now()-new Date(dt))/1000);
    if (d<60) return 'Just now'; if (d<3600) return Math.floor(d/60)+'m ago';
    if (d<86400) return Math.floor(d/3600)+'h ago'; return Math.floor(d/86400)+'d ago';
}

// ---- DASHBOARD ----
async function loadDashboardData() {
    const [depRes, usrRes] = await Promise.all([
        adminAPI('../admin/api/admin_deposits.php?status=pending&limit=5'),
        adminAPI('../admin/api/admin_users.php?limit=5')
    ]);
    if (depRes.success) {
        document.getElementById('recentDeposits').innerHTML = depRes.deposits.length
            ? depRes.deposits.map(d => `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #222;">
                <div><div style="font-size:0.88rem;font-weight:600;">${d.username}</div><div style="font-size:0.75rem;color:#aaa;">${d.utr_number}</div></div>
                <div style="text-align:right;"><div style="font-weight:700;color:#22C55E;">₹${Number(d.amount).toFixed(0)}</div>${statusBadge(d.status)}</div>
            </div>`).join('')
            : '<p class="text-muted text-center small py-3">No pending deposits</p>';
    }
    if (usrRes.success) {
        document.getElementById('recentUsers').innerHTML = usrRes.users.map(u => `
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #222;">
                <div class="user-initial">${(u.username||'U').charAt(0).toUpperCase()}</div>
                <div style="flex:1"><div style="font-size:0.88rem;font-weight:600;">${u.username}</div><div style="font-size:0.75rem;color:#aaa;">${u.email}</div></div>
                <div style="font-size:0.75rem;color:#aaa;">${timeAgo(u.created_at)}</div>
            </div>`).join('');
    }
}

// ---- USERS ----
async function loadUsers(page = 1) {
    currentUsersPage = page;
    const search = document.getElementById('userSearch')?.value || '';
    const res = await adminAPI(`api/admin_users.php?page=${page}&search=${encodeURIComponent(search)}&limit=${perPage}`);
    if (!res.success) return;
    document.getElementById('usersCount').textContent = `${res.total} users`;
    document.getElementById('usersTable').innerHTML = res.users.map(u => `
        <tr>
            <td><div style="display:flex;align-items:center;gap:8px;">
                <div class="user-initial">${u.username.charAt(0).toUpperCase()}</div>
                <div><div style="font-weight:600;">${u.username}</div><div style="font-size:0.75rem;color:#aaa;">#${u.id}</div></div>
            </div></td>
            <td>${u.email}</td>
            <td>
                <div style="font-size:0.82rem;">C: ₹${Number(u.cash_balance).toFixed(0)}</div>
                <div style="font-size:0.82rem;color:#F59E0B;">B: ₹${Number(u.bonus_balance).toFixed(0)}</div>
                <div style="font-size:0.82rem;color:#22C55E;">W: ₹${Number(u.winning_balance).toFixed(0)}</div>
            </td>
            <td>${statusBadge(u.kyc_status)}</td>
            <td style="font-size:0.8rem;color:#aaa;">${new Date(u.created_at).toLocaleDateString()}</td>
            <td>
                <div class="action-btns">
                    <button class="btn btn-sm btn-outline-secondary btn-xs" onclick="openUserModal(${u.id})"><i class="bi bi-eye"></i></button>
                    <button class="btn btn-sm btn-success btn-xs" onclick="openAddBalanceModal(${u.id},'${u.username}')"><i class="bi bi-wallet2"></i> Balance</button>
                    <button class="btn btn-sm ${u.is_active?'btn-danger':'btn-success'} btn-xs" onclick="toggleUser(${u.id},${u.is_active})">
                        ${u.is_active ? '<i class="bi bi-ban"></i>' : '<i class="bi bi-check-circle"></i>'}
                    </button>
                </div>
            </td>
        </tr>`).join('') || '<tr><td colspan="6" class="text-center text-muted py-4">No users found</td></tr>';
    
    // Pagination
    const pages = Math.ceil(res.total / perPage);
    let pag = '';
    for (let i = 1; i <= Math.min(pages,10); i++) {
        pag += `<button class="btn btn-sm ${i===page?'btn-primary':'btn-outline-secondary'} btn-xs me-1" onclick="loadUsers(${i})">${i}</button>`;
    }
    document.getElementById('usersPagination').innerHTML = pag;
}

document.addEventListener('input', function(e) {
    if (e.target.id === 'userSearch') { clearTimeout(window.searchTimeout); window.searchTimeout = setTimeout(() => loadUsers(1), 400); }
});

async function openUserModal(userId) {
    const res = await adminAPI(`api/admin_user_detail.php?id=${userId}`);
    if (!res.success) return;
    const u = res.user;
    document.getElementById('userModalBody').innerHTML = `
        <div class="row g-3">
            <div class="col-md-6">
                <h6>Account Details</h6>
                <table class="table table-sm" style="font-size:0.85rem;">
                    <tr><td class="text-muted">Username</td><td><strong>${u.username}</strong></td></tr>
                    <tr><td class="text-muted">Email</td><td>${u.email}</td></tr>
                    <tr><td class="text-muted">Phone</td><td>${u.phone||'N/A'}</td></tr>
                    <tr><td class="text-muted">Referral Code</td><td><code>${u.referral_code}</code></td></tr>
                    <tr><td class="text-muted">Cash</td><td>₹${Number(u.cash_balance).toFixed(2)}</td></tr>
                    <tr><td class="text-muted">Bonus</td><td>₹${Number(u.bonus_balance).toFixed(2)}</td></tr>
                    <tr><td class="text-muted">Winnings</td><td>₹${Number(u.winning_balance).toFixed(2)}</td></tr>
                    <tr><td class="text-muted">Total Bets</td><td>${u.total_bets}</td></tr>
                    <tr><td class="text-muted">KYC Status</td><td>${statusBadge(u.kyc_status)}</td></tr>
                    <tr><td class="text-muted">Joined</td><td>${new Date(u.created_at).toLocaleString()}</td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Balance Management</h6>
                <form onsubmit="addBalance(event,${u.id})">
                    <div class="mb-2"><label class="form-label">Action</label>
                        <select class="form-select" name="action"><option value="add">Add Balance</option><option value="deduct">Deduct Balance</option></select>
                    </div>
                    <div class="mb-2"><label class="form-label">Amount</label><input type="number" class="form-control" name="amount" min="0.01" step="0.01" required></div>
                    <div class="mb-2"><label class="form-label">Type</label>
                        <select class="form-select" name="balance_type">
                            <option value="cash">Cash</option><option value="bonus">Bonus</option><option value="winning">Winning</option>
                        </select>
                    </div>
                    <div class="mb-2"><label class="form-label">Note</label><input type="text" class="form-control" name="note" placeholder="Reason"></div>
                    <div id="balanceStatus" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary btn-sm w-100">Apply</button>
                </form>
            </div>
            ${u.upi_id || u.bank_account ? `<div class="col-12"><h6>Payment Details</h6>
                ${u.upi_id ? `<p class="mb-1"><small class="text-muted">UPI:</small> ${u.upi_id}</p>` : ''}
                ${u.bank_account ? `<p class="mb-1"><small class="text-muted">Bank:</small> ${u.account_holder} · ${u.bank_account} · ${u.bank_ifsc}</p>` : ''}
            </div>` : ''}
        </div>`;
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

async function addBalance(e, userId) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('user_id', userId);
    const res = await adminAPI('../admin/api/admin_balance.php', fd);
    adminStatus('balanceStatus', res.message, res.success ? 'success' : 'error');
    if (res.success) { showAlert(res.message); loadUsers(currentUsersPage); }
}

async function openAddBalanceModal(userId, username) {
    const res = await adminAPI(`api/admin_user_detail.php?id=${userId}`);
    if (res.success) openUserModal(userId);
}

async function toggleUser(userId, currentStatus) {
    if (!confirm(currentStatus ? 'Ban this user?' : 'Activate this user?')) return;
    const res = await adminAPI('../admin/api/admin_toggle_user.php', { user_id: userId, is_active: currentStatus ? 0 : 1 });
    if (res.success) { showAlert(res.message); loadUsers(currentUsersPage); }
    else showAlert(res.message, 'error');
}

function exportUsers() {
    window.open('../admin/api/admin_export.php?type=users', '_blank');
}

// ---- DEPOSITS ----
async function loadDeposits() {
    const status = document.getElementById('depositFilter')?.value || 'pending';
    const res = await adminAPI(`api/admin_deposits.php?status=${status}`);
    if (!res.success) return;
    document.getElementById('depositsTable').innerHTML = res.deposits.length
        ? res.deposits.map(d => `<tr>
            <td><div style="font-weight:600;">${d.username}</div><div style="font-size:0.75rem;color:#aaa;">#${d.user_id}</div></td>
            <td style="font-weight:700;color:#22C55E;">₹${Number(d.amount).toFixed(2)}</td>
            <td><code style="font-size:0.8rem;">${d.utr_number||'-'}</code></td>
            <td>${d.receipt_image ? `<img src="../${d.receipt_image}" class="preview-img" onclick="previewImage('../${d.receipt_image}')">` : '-'}</td>
            <td style="font-size:0.8rem;color:#aaa;">${new Date(d.created_at).toLocaleString()}</td>
            <td>${statusBadge(d.status)}</td>
            <td class="action-btns">
                ${d.status==='pending' ? `
                <button class="btn btn-success btn-xs" onclick="approveDeposit(${d.id})"><i class="bi bi-check-circle"></i> Approve</button>
                <button class="btn btn-danger btn-xs" onclick="rejectDeposit(${d.id})"><i class="bi bi-x-circle"></i> Reject</button>` : ''}
            </td>
        </tr>`).join('')
        : '<tr><td colspan="7" class="text-center text-muted py-4">No deposits</td></tr>';
}

async function approveDeposit(id) {
    if (!confirm('Approve this deposit?')) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_approve_deposit.php', { id, action: 'approve' });
    showLoader(false);
    if (res.success) { showAlert('Deposit approved!'); loadDeposits(); }
    else showAlert(res.message, 'error');
}

async function rejectDeposit(id) {
    const note = prompt('Rejection reason (optional):');
    if (note === null) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_approve_deposit.php', { id, action: 'reject', note });
    showLoader(false);
    if (res.success) { showAlert('Deposit rejected.'); loadDeposits(); }
    else showAlert(res.message, 'error');
}

// ---- WITHDRAWALS ----
async function loadWithdrawals() {
    const status = document.getElementById('withdrawFilter')?.value || 'pending';
    const res = await adminAPI(`api/admin_withdrawals.php?status=${status}`);
    if (!res.success) return;
    document.getElementById('withdrawalsTable').innerHTML = res.withdrawals.length
        ? res.withdrawals.map(w => `<tr>
            <td><div style="font-weight:600;">${w.username}</div></td>
            <td style="font-weight:700;color:#EF4444;">₹${Number(w.amount).toFixed(2)}</td>
            <td>${w.method==='upi'?'<span class="badge bg-info">UPI</span>':'<span class="badge bg-warning text-dark">Bank</span>'}</td>
            <td style="font-size:0.8rem;">${w.method==='upi' ? w.upi_id : `${w.account_holder}<br>${w.account_number}<br>${w.ifsc_code}<br>${w.bank_name}`}</td>
            <td style="font-size:0.8rem;color:#aaa;">${new Date(w.created_at).toLocaleString()}</td>
            <td>${statusBadge(w.status)}</td>
            <td class="action-btns">
                ${w.status==='pending' ? `
                <button class="btn btn-success btn-xs" onclick="approveWithdrawal(${w.id})"><i class="bi bi-check-circle"></i> Approve</button>
                <button class="btn btn-danger btn-xs" onclick="rejectWithdrawal(${w.id})"><i class="bi bi-x-circle"></i> Reject</button>` : ''}
            </td>
        </tr>`).join('')
        : '<tr><td colspan="7" class="text-center text-muted py-4">No withdrawals</td></tr>';
}

async function approveWithdrawal(id) {
    if (!confirm('Approve this withdrawal?')) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_approve_withdrawal.php', { id, action: 'approve' });
    showLoader(false);
    if (res.success) { showAlert('Withdrawal approved!'); loadWithdrawals(); }
    else showAlert(res.message, 'error');
}

async function rejectWithdrawal(id) {
    const note = prompt('Rejection reason:') || '';
    if (note === null) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_approve_withdrawal.php', { id, action: 'reject', note });
    showLoader(false);
    if (res.success) { showAlert('Withdrawal rejected. Balance refunded.'); loadWithdrawals(); }
    else showAlert(res.message, 'error');
}

// ---- TOURNAMENTS ----
async function loadTournaments() {
    const res = await adminAPI('../admin/api/admin_tournaments.php');
    if (!res.success) return;
    const gRes = await adminAPI('../admin/api/admin_games.php');
    if (gRes.success) {
        const sel = document.getElementById('tournGameSelect');
        if (sel) sel.innerHTML = gRes.games.map(g => `<option value="${g.id}">${g.name}</option>`).join('');
    }
    document.getElementById('tournamentsTable').innerHTML = res.tournaments.map(t => `<tr>
        <td>${t.banner_image ? `<img src="../${t.banner_image}" class="preview-img" onclick="previewImage('../${t.banner_image}')">` : '<span class="text-muted small">No image</span>'}</td>
        <td><div style="font-weight:600;max-width:150px;">${t.title}</div></td>
        <td>${t.game_name||'-'}</td>
        <td>${t.entry_fee>0?'₹'+t.entry_fee:'FREE'}</td>
        <td style="color:#FACC15;">₹${Number(t.prize_pool).toLocaleString()}</td>
        <td style="font-size:0.8rem;">${new Date(t.start_time).toLocaleString()}</td>
        <td>${t.filled_slots}/${t.max_slots}</td>
        <td>${statusBadge(t.status)}</td>
        <td class="action-btns">
            <button class="btn btn-outline-secondary btn-xs" onclick="editTournament(${t.id})"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-danger btn-xs" onclick="deleteTournament(${t.id})"><i class="bi bi-trash"></i></button>
        </td>
    </tr>`).join('') || '<tr><td colspan="9" class="text-center text-muted py-4">No tournaments</td></tr>';
}

function openTournamentModal() {
    document.getElementById('tournamentForm').reset();
    document.getElementById('tournId').value = '';
    document.getElementById('tournModalTitle').textContent = 'Add Tournament';
    document.getElementById('tournStatus').innerHTML = '';
    document.getElementById('tournBannerPreview').innerHTML = '';
    new bootstrap.Modal(document.getElementById('tournamentModal')).show();
}

async function editTournament(id) {
    const res = await adminAPI(`api/admin_tournaments.php?id=${id}`);
    if (!res.success) return;
    const t = res.tournament;
    const form = document.getElementById('tournamentForm');
    form.reset();
    Object.keys(t).forEach(k => { if (form[k]) form[k].value = t[k]; });
    if (t.start_time) form.start_time.value = t.start_time.replace(' ','T').slice(0,16);
    if (t.end_time) form.end_time.value = t.end_time.replace(' ','T').slice(0,16);
    document.getElementById('tournModalTitle').textContent = 'Edit Tournament';
    document.getElementById('tournBannerPreview').innerHTML = t.banner_image ? `<img src="../${t.banner_image}" style="max-height:80px;border-radius:8px;">` : '';
    new bootstrap.Modal(document.getElementById('tournamentModal')).show();
}

async function saveTournament(e) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_save_tournament.php', new FormData(e.target));
    showLoader(false);
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('tournamentModal')).hide();
        showAlert('Tournament saved!'); loadTournaments();
    } else adminStatus('tournStatus', res.message, 'error');
}

async function deleteTournament(id) {
    if (!confirm('Delete this tournament?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'tournament', id });
    if (res.success) { showAlert('Deleted!'); loadTournaments(); }
    else showAlert(res.message, 'error');
}

// ---- TOURNAMENT MANAGEMENT ----
async function loadTournamentManage() {
    const res = await adminAPI('../admin/api/admin_tournaments.php');
    if (!res.success) return;
    const sel = document.getElementById('tmTournSelect');
    sel.innerHTML = '<option value="">-- Select Tournament --</option>' + 
        res.tournaments.filter(t => t.status !== 'cancelled').map(t => `<option value="${t.id}">${t.title} (${t.status})</option>`).join('');
}

async function loadTournamentParticipants() {
    const tId = document.getElementById('tmTournSelect').value;
    if (!tId) { document.getElementById('participantsList').innerHTML = ''; return; }
    const res = await adminAPI(`api/admin_participants.php?tournament_id=${tId}`);
    if (!res.success) return;
    document.getElementById('participantsList').innerHTML = res.participants.map(p => `
        <div class="participant-row">
            <div class="participant-slot">${p.slot_number}</div>
            <div style="flex:1"><div style="font-weight:600;font-size:0.9rem;">${p.username}</div><div style="font-size:0.75rem;color:#aaa;">Slot #${p.slot_number}</div></div>
            <div style="display:flex;align-items:center;gap:8px;">
                <div><label style="font-size:0.72rem;color:#aaa;">Rank</label><input type="number" class="form-control form-control-sm" id="rank_${p.user_id}" value="${p.rank_position||''}" placeholder="#" style="width:65px;"></div>
                <div><label style="font-size:0.72rem;color:#aaa;">Kills</label><input type="number" class="form-control form-control-sm" id="kills_${p.user_id}" value="${p.kills||0}" style="width:65px;"></div>
                <div><label style="font-size:0.72rem;color:#aaa;">Prize ₹</label><input type="number" class="form-control form-control-sm" id="prize_${p.user_id}" value="${p.prize_won||0}" step="0.01" style="width:80px;"></div>
            </div>
        </div>`).join('') || '<p class="text-muted text-center py-3">No participants</p>';
    document.getElementById('participantsList').dataset.tournId = tId;
}

async function distributePrizes() {
    const tId = document.getElementById('participantsList').dataset.tournId;
    if (!tId) { showAlert('Select tournament first', 'error'); return; }
    
    const rows = document.querySelectorAll('.participant-row');
    const participants = [];
    rows.forEach(row => {
        const userId = row.querySelector('input[id^="rank_"]')?.id.replace('rank_','');
        if (userId) participants.push({
            user_id: userId,
            rank: document.getElementById(`rank_${userId}`)?.value || 0,
            kills: document.getElementById(`kills_${userId}`)?.value || 0,
            prize: document.getElementById(`prize_${userId}`)?.value || 0
        });
    });
    
    if (!confirm(`Distribute prizes to ${participants.length} participants?`)) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_distribute_prizes.php', { tournament_id: tId, participants });
    showLoader(false);
    if (res.success) showAlert('Prizes distributed!');
    else showAlert(res.message, 'error');
}

// ---- MATCHES ----
async function loadMatches() {
    const res = await adminAPI('../admin/api/admin_matches.php');
    if (!res.success) return;
    document.getElementById('matchesTable').innerHTML = res.matches.map(m => `<tr>
        <td><div style="font-weight:600;">${m.team1} vs ${m.team2}</div></td>
        <td><span class="badge bg-secondary">${m.match_type}</span></td>
        <td style="font-size:0.8rem;">${new Date(m.start_time).toLocaleString()}</td>
        <td>${statusBadge(m.status)}</td>
        <td style="font-size:0.82rem;">${m.odds_team1}x / ${m.odds_team2}x</td>
        <td>${m.bet_count||0}</td>
        <td class="action-btns">
            <button class="btn btn-outline-secondary btn-xs" onclick="editMatch(${m.id})"><i class="bi bi-pencil"></i></button>
            ${m.status==='live'||m.status==='completed'?`<button class="btn btn-warning btn-xs" onclick="settleMatch(${m.id})"><i class="bi bi-trophy"></i> Settle</button>`:''}
            <button class="btn btn-danger btn-xs" onclick="deleteMatch(${m.id})"><i class="bi bi-trash"></i></button>
        </td>
    </tr>`).join('') || '<tr><td colspan="7" class="text-center text-muted py-4">No matches</td></tr>';
}

function openMatchModal() {
    document.getElementById('matchForm').reset();
    document.getElementById('matchId').value = '';
    document.getElementById('matchModalTitle').textContent = 'Add Match';
    document.getElementById('matchStatus').innerHTML = '';
    new bootstrap.Modal(document.getElementById('matchModal')).show();
}

async function editMatch(id) {
    const res = await adminAPI(`api/admin_matches.php?id=${id}`);
    if (!res.success) return;
    const m = res.match;
    const form = document.getElementById('matchForm');
    form.reset();
    Object.keys(m).forEach(k => { if (form[k]) form[k].value = m[k]; });
    if (m.start_time) form.start_time.value = m.start_time.replace(' ','T').slice(0,16);
    document.getElementById('matchModalTitle').textContent = 'Edit Match';
    new bootstrap.Modal(document.getElementById('matchModal')).show();
}

async function saveMatch(e) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_save_match.php', new FormData(e.target));
    showLoader(false);
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('matchModal')).hide();
        showAlert('Match saved!'); loadMatches();
    } else adminStatus('matchStatus', res.message, 'error');
}

async function settleMatch(matchId) {
    const winner = prompt('Enter winner team name (exactly as shown):');
    if (!winner) return;
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_settle_match.php', { match_id: matchId, winner });
    showLoader(false);
    if (res.success) { showAlert(`Match settled! ${res.settled_bets} bets processed.`); loadMatches(); }
    else showAlert(res.message, 'error');
}

async function deleteMatch(id) {
    if (!confirm('Delete this match?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'match', id });
    if (res.success) { showAlert('Deleted!'); loadMatches(); }
}

// ---- GAMES ----
async function loadGames() {
    const res = await adminAPI('../admin/api/admin_games.php');
    if (!res.success) return;
    document.getElementById('gamesGrid').innerHTML = res.games.map(g => `
        <div class="col-6 col-md-3 mb-3">
            <div class="game-card-admin">
                ${g.image ? `<img src="../${g.image}" class="game-card-img" alt="${g.name}">` : `<div class="game-card-img-placeholder"><i class="bi bi-controller"></i></div>`}
                <div class="game-card-body">
                    <div class="game-card-name">${g.name}</div>
                    <div class="d-flex gap-1 mt-1">
                        <span class="badge ${g.is_active?'bg-success':'bg-secondary'}">${g.is_active?'Active':'Inactive'}</span>
                    </div>
                    <div class="d-flex gap-1 mt-2">
                        <button class="btn btn-outline-secondary btn-xs flex-grow-1" onclick="editGame(${g.id})"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-danger btn-xs" onclick="deleteGame(${g.id})"><i class="bi bi-trash"></i></button>
                    </div>
                </div>
            </div>
        </div>`).join('');
}

function openGameModal() {
    document.getElementById('gameForm').reset();
    document.getElementById('gameId').value = '';
    document.getElementById('gameModalTitle').textContent = 'Add Game';
    document.getElementById('gameImgPreview').innerHTML = '';
    new bootstrap.Modal(document.getElementById('gameModal')).show();
}

async function editGame(id) {
    const res = await adminAPI(`api/admin_games.php?id=${id}`);
    if (!res.success) return;
    const g = res.game;
    const form = document.getElementById('gameForm');
    form.reset();
    Object.keys(g).forEach(k => { if (form[k]) form[k].value = g[k]; });
    document.getElementById('gameImgPreview').innerHTML = g.image ? `<img src="../${g.image}" style="height:60px;border-radius:8px;">` : '';
    document.getElementById('gameModalTitle').textContent = 'Edit Game';
    new bootstrap.Modal(document.getElementById('gameModal')).show();
}

async function saveGame(e) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_save_game.php', new FormData(e.target));
    showLoader(false);
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('gameModal')).hide();
        showAlert('Game saved!'); loadGames();
    } else adminStatus('gameStatus', res.message, 'error');
}

async function deleteGame(id) {
    if (!confirm('Delete this game?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'game', id });
    if (res.success) { showAlert('Deleted!'); loadGames(); }
}

// ---- BANNERS ----
async function loadBanners() {
    const res = await adminAPI('../admin/api/admin_banners.php');
    if (!res.success) return;
    document.getElementById('bannersGrid').innerHTML = res.banners.map(b => `
        <div class="col-md-4 mb-3">
            <div class="banner-card">
                <img src="../${b.image}" class="banner-img" alt="${b.title||'Banner'}">
                <div class="banner-actions">
                    <span class="badge ${b.is_active?'bg-success':'bg-secondary'} me-auto">${b.is_active?'Active':'Inactive'}</span>
                    <button class="btn btn-outline-secondary btn-xs" onclick="editBanner(${b.id})"><i class="bi bi-pencil"></i></button>
                    <button class="btn btn-danger btn-xs" onclick="deleteBanner(${b.id})"><i class="bi bi-trash"></i></button>
                </div>
            </div>
        </div>`).join('') || '<div class="col-12 text-center text-muted py-5">No banners. Add some!</div>';
}

function openBannerModal() {
    document.getElementById('bannerForm').reset();
    document.getElementById('bannerId').value = '';
    document.getElementById('bannerModalTitle').textContent = 'Add Banner';
    document.getElementById('bannerImgPreview').innerHTML = '';
    new bootstrap.Modal(document.getElementById('bannerModal')).show();
}

async function editBanner(id) {
    const res = await adminAPI(`api/admin_banners.php?id=${id}`);
    if (!res.success) return;
    const b = res.banner;
    const form = document.getElementById('bannerForm');
    form.reset();
    Object.keys(b).forEach(k => { if (form[k]) form[k].value = b[k]; });
    document.getElementById('bannerImgPreview').innerHTML = b.image ? `<img src="../${b.image}" style="max-height:80px;border-radius:8px;">` : '';
    document.getElementById('bannerModalTitle').textContent = 'Edit Banner';
    new bootstrap.Modal(document.getElementById('bannerModal')).show();
}

async function saveBanner(e) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_save_banner.php', new FormData(e.target));
    showLoader(false);
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('bannerModal')).hide();
        showAlert('Banner saved!'); loadBanners();
    } else adminStatus('bannerStatus', res.message, 'error');
}

async function deleteBanner(id) {
    if (!confirm('Delete this banner?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'banner', id });
    if (res.success) { showAlert('Deleted!'); loadBanners(); }
}

// ---- COUPONS ----
async function loadCoupons() {
    const res = await adminAPI('../admin/api/admin_coupons.php');
    if (!res.success) return;
    document.getElementById('couponsList').innerHTML = res.coupons.length
        ? res.coupons.map(c => `
            <div style="padding:10px;background:var(--primary-bg);border-radius:8px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <code style="font-size:0.9rem;font-weight:700;">${c.code}</code>
                    <div style="font-size:0.75rem;color:#aaa;">₹${c.amount} ${c.balance_type} · ${c.used_count}/${c.max_uses} used · Exp: ${new Date(c.expires_at).toLocaleDateString()}</div>
                </div>
                <div class="d-flex gap-1">
                    <button class="btn btn-outline-secondary btn-xs" onclick="copyCoupon('${c.code}')"><i class="bi bi-clipboard"></i></button>
                    <button class="btn btn-danger btn-xs" onclick="deleteCoupon(${c.id})"><i class="bi bi-trash"></i></button>
                </div>
            </div>`).join('')
        : '<p class="text-muted text-center py-3">No active coupons</p>';
}

async function createCoupon(e) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_create_coupon.php', new FormData(e.target));
    showLoader(false);
    if (res.success) {
        showAlert(`${res.count} coupon(s) created!`);
        e.target.reset();
        loadCoupons();
        adminStatus('couponStatus', res.codes ? `Codes: ${res.codes.slice(0,3).join(', ')}${res.codes.length>3?'...':''}` : `${res.count} coupons created`, 'success');
    } else adminStatus('couponStatus', res.message, 'error');
}

function copyCoupon(code) {
    navigator.clipboard.writeText(code).then(() => showAlert('Coupon code copied!'));
}

async function deleteCoupon(id) {
    if (!confirm('Delete coupon?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'coupon', id });
    if (res.success) { showAlert('Deleted!'); loadCoupons(); }
}

// ---- KYC ----
async function loadKYC() {
    const status = document.getElementById('kycFilter')?.value || 'submitted';
    const res = await adminAPI(`api/admin_kyc.php?status=${status}`);
    if (!res.success) return;
    document.getElementById('kycTable').innerHTML = res.kyc.length
        ? res.kyc.map(k => `<tr>
            <td><div style="font-weight:600;">${k.username}</div><div style="font-size:0.75rem;color:#aaa;">${k.email}</div></td>
            <td>${k.doc_type}</td>
            <td>
                ${k.doc_front ? `<img src="../${k.doc_front}" class="preview-img me-1" onclick="previewImage('../${k.doc_front}')">` : ''}
                ${k.doc_back ? `<img src="../${k.doc_back}" class="preview-img me-1" onclick="previewImage('../${k.doc_back}')">` : ''}
                ${k.selfie ? `<img src="../${k.selfie}" class="preview-img" onclick="previewImage('../${k.selfie}')">` : ''}
            </td>
            <td style="font-size:0.8rem;color:#aaa;">${new Date(k.submitted_at).toLocaleString()}</td>
            <td>${statusBadge(k.status)}</td>
            <td class="action-btns">
                ${k.status==='submitted' ? `
                <button class="btn btn-success btn-xs" onclick="approveKYC(${k.user_id})"><i class="bi bi-check-circle"></i> Verify</button>
                <button class="btn btn-danger btn-xs" onclick="rejectKYC(${k.user_id})"><i class="bi bi-x-circle"></i> Reject</button>` : ''}
            </td>
        </tr>`).join('')
        : '<tr><td colspan="6" class="text-center text-muted py-4">No KYC requests</td></tr>';
}

async function approveKYC(userId) {
    if (!confirm('Verify KYC?')) return;
    const res = await adminAPI('../admin/api/admin_kyc_action.php', { user_id: userId, action: 'verify' });
    if (res.success) { showAlert('KYC verified!'); loadKYC(); }
    else showAlert(res.message, 'error');
}

async function rejectKYC(userId) {
    const note = prompt('Rejection reason:') || '';
    const res = await adminAPI('../admin/api/admin_kyc_action.php', { user_id: userId, action: 'reject', note });
    if (res.success) { showAlert('KYC rejected.'); loadKYC(); }
    else showAlert(res.message, 'error');
}

// ---- LEADERBOARD ----
async function loadLeaderboard() {
    const res = await adminAPI('../admin/api/admin_leaderboard.php');
    if (!res.success) return;
    document.getElementById('leaderboardTable').innerHTML = res.entries.map((e,i) => `<tr>
        <td><strong style="color:#FACC15;">#${i+1}</strong></td>
        <td>${e.username}</td>
        <td>${e.points}</td>
        <td><span class="badge bg-secondary">${e.period}</span></td>
        <td><button class="btn btn-danger btn-xs" onclick="deleteLeaderboard(${e.id})"><i class="bi bi-trash"></i></button></td>
    </tr>`).join('') || '<tr><td colspan="5" class="text-center text-muted py-4">No entries</td></tr>';
}

function openLeaderboardModal() {
    const userId = prompt('Enter User ID:');
    if (!userId) return;
    const points = prompt('Enter Points:');
    if (!points) return;
    adminAPI('../admin/api/admin_leaderboard.php', { action: 'add', user_id: userId, points }).then(res => {
        if (res.success) { showAlert('Entry added!'); loadLeaderboard(); }
        else showAlert(res.message, 'error');
    });
}

async function deleteLeaderboard(id) {
    if (!confirm('Delete entry?')) return;
    const res = await adminAPI('../admin/api/admin_delete.php', { type: 'leaderboard', id });
    if (res.success) { showAlert('Deleted!'); loadLeaderboard(); }
}

// ---- CHAT ----
async function loadChatUsers() {
    const res = await adminAPI('../admin/api/admin_chat_users.php');
    if (!res.success) return;
    const list = document.getElementById('chatUsersList');
    list.innerHTML = res.users.map(u => `
        <div class="chat-user-item ${currentChatUserId==u.id?'active':''}" onclick="openChat(${u.id},'${u.username}')" data-name="${u.username}">
            <div class="user-initial" style="flex-shrink:0;">${u.username.charAt(0).toUpperCase()}</div>
            <div class="chat-user-info">
                <div class="chat-user-name">${u.username}</div>
                <div class="chat-last-msg">${u.last_message||'No messages'}</div>
            </div>
            ${u.unread_count>0 ? `<span class="chat-unread">${u.unread_count}</span>` : ''}
        </div>`).join('') || '<div class="text-center text-muted p-4">No chats yet</div>';
}

function filterChatUsers() {
    const q = document.getElementById('chatUserSearch').value.toLowerCase();
    document.querySelectorAll('.chat-user-item').forEach(item => {
        item.style.display = item.dataset.name.toLowerCase().includes(q) ? 'flex' : 'none';
    });
}

async function openChat(userId, username) {
    currentChatUserId = userId;
    document.getElementById('activeChatHeader').textContent = `Chat with @${username}`;
    document.getElementById('chatInputArea').style.display = 'block';
    document.querySelectorAll('.chat-user-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.chat-user-item[onclick*="${userId}"]`)?.classList.add('active');
    
    if (chatPoll) clearInterval(chatPoll);
    await loadChatMessages(userId);
    chatPoll = setInterval(() => loadChatMessages(userId), 4000);
}

async function loadChatMessages(userId) {
    const res = await adminAPI(`api/admin_chat.php?user_id=${userId}`);
    if (!res.success) return;
    const container = document.getElementById('chatMessages');
    container.innerHTML = res.messages.length
        ? res.messages.map(m => `
            <div class="chat-msg ${m.sender==='user'?'from-user':'from-admin'}">
                <div class="chat-bubble">${m.message}</div>
                <div class="chat-time">${timeAgo(m.created_at)}</div>
            </div>`).join('')
        : '<div class="text-center text-muted py-5">No messages yet</div>';
    container.scrollTop = container.scrollHeight;
}

async function sendAdminMessage() {
    const input = document.getElementById('adminChatInput');
    const msg = input.value.trim();
    if (!msg || !currentChatUserId) return;
    input.value = '';
    const res = await adminAPI('../admin/api/admin_send_chat.php', { user_id: currentChatUserId, message: msg });
    if (res.success) loadChatMessages(currentChatUserId);
}

document.addEventListener('keypress', e => {
    if (e.key === 'Enter' && e.target.id === 'adminChatInput') sendAdminMessage();
});

// ---- NOTIFICATIONS ----
async function sendNotification(e, target) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('target_type', target);
    const statusId = target === 'user' ? 'notifStatus1' : 'notifStatus2';
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_send_notification.php', fd);
    showLoader(false);
    adminStatus(statusId, res.message, res.success ? 'success' : 'error');
    if (res.success) e.target.reset();
}

// ---- ANALYTICS ----
async function loadAnalytics() {
    const res = await adminAPI('../admin/api/admin_analytics.php');
    if (!res.success) return;
    
    const chartDefaults = { responsive: true, plugins: { legend: { labels: { color: '#aaa', font: { family: 'Poppins' } } } }, scales: { x: { ticks: { color: '#aaa' }, grid: { color: '#2a2a2a' } }, y: { ticks: { color: '#aaa' }, grid: { color: '#2a2a2a' } } } };
    
    if (window.chartInstances) window.chartInstances.forEach(c => c.destroy());
    window.chartInstances = [];
    
    if (res.user_growth) {
        window.chartInstances.push(new Chart(document.getElementById('userGrowthChart'), {
            type: 'line', options: { ...chartDefaults, plugins: { ...chartDefaults.plugins, title: { display: true, text: 'User Growth (30 days)', color: '#fff' } } },
            data: { labels: res.user_growth.map(d => d.date), datasets: [{ label: 'New Users', data: res.user_growth.map(d => d.count), borderColor: '#1DB954', backgroundColor: 'rgba(29,185,84,0.15)', tension: 0.4, fill: true }] }
        }));
    }
    if (res.deposit_stats) {
        window.chartInstances.push(new Chart(document.getElementById('depositChart'), {
            type: 'bar', options: { ...chartDefaults, plugins: { ...chartDefaults.plugins, title: { display: true, text: 'Deposits (30 days)', color: '#fff' } } },
            data: { labels: res.deposit_stats.map(d => d.date), datasets: [{ label: '₹ Deposited', data: res.deposit_stats.map(d => d.total), backgroundColor: 'rgba(59,130,246,0.5)', borderColor: '#3B82F6', borderWidth: 1 }] }
        }));
    }
    if (res.bet_stats) {
        window.chartInstances.push(new Chart(document.getElementById('betStatsChart'), {
            type: 'doughnut', options: { responsive: true, plugins: { legend: { labels: { color: '#aaa' } }, title: { display: true, text: 'Bet Status', color: '#fff' } } },
            data: { labels: ['Won', 'Lost', 'Pending'], datasets: [{ data: [res.bet_stats.won||0, res.bet_stats.lost||0, res.bet_stats.pending||0], backgroundColor: ['#22C55E','#EF4444','#F59E0B'] }] }
        }));
    }
    if (res.top_users) {
        document.getElementById('topUsersTable').innerHTML = `<table class="table table-sm" style="font-size:0.85rem;">
            <thead><tr><th>#</th><th>User</th><th>Total Balance</th></tr></thead>
            <tbody>${res.top_users.map((u,i) => `<tr><td>${i+1}</td><td>${u.username}</td><td style="color:#22C55E;font-weight:600;">₹${Number(u.total).toFixed(0)}</td></tr>`).join('')}</tbody>
        </table>`;
    }
}

// ---- SETTINGS ----
const contentKeyMap = { terms: 'terms_content', privacy: 'privacy_content', about: 'about_content', refund: 'refund_policy', withdrawal: 'withdrawal_note' };

function initSettingsContent() { switchContentTab('terms', document.querySelector('.nav-tabs .nav-link')); }

async function switchContentTab(type, el) {
    document.querySelectorAll('#contentTabs .nav-link').forEach(l => l.classList.remove('active'));
    if (el) el.classList.add('active');
    const key = contentKeyMap[type];
    document.getElementById('activeContentKey').value = key;
    const res = await adminAPI(`api/admin_get_content.php?key=${key}`);
    if (res.success) document.getElementById('contentEditor').value = res.value;
}

async function saveContent() {
    const key = document.getElementById('activeContentKey').value;
    const value = document.getElementById('contentEditor').value;
    const res = await adminAPI('../admin/api/admin_save_setting.php', { key, value });
    adminStatus('settingsStatus5', res.message, res.success ? 'success' : 'error');
    if (res.success) showAlert('Content saved!');
}

async function saveSettings(e, type) {
    e.preventDefault();
    showLoader(true);
    const res = await adminAPI('../admin/api/admin_save_settings.php', new FormData(e.target));
    showLoader(false);
    const statusIds = { general: 'settingsStatus1', payment: 'settingsStatus2', referral: 'settingsStatus3', google: 'settingsStatus4' };
    adminStatus(statusIds[type] || 'settingsStatus1', res.message, res.success ? 'success' : 'error');
    if (res.success) showAlert('Settings saved!');
}

async function changeAdminPassword(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const res = await adminAPI('../admin/api/admin_change_password.php', fd);
    adminStatus('pwdStatus', res.message, res.success ? 'success' : 'error');
    if (res.success) { e.target.reset(); showAlert('Password changed!'); }
}

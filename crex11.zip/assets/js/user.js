// CREX 11 User JS

let currentSection = 'home';
let currentBetMatch = null;
let currentBetPick = null;
let currentBetOdds = 1.9;
let depositAmount = 0;
let currentWithdrawTab = 'upi';
let chatOpen = false;
let chatPolling = null;

// ============ NAVIGATION ============
function showSection(name) {
    // Hide all subpages
    document.querySelectorAll('[id^="page-"]').forEach(el => el.classList.remove('active'));
    
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    const sec = document.getElementById(name);
    if (sec) { sec.classList.add('active'); currentSection = name; }
    
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navEl = document.getElementById('nav-' + name);
    if (navEl) navEl.classList.add('active');
    
    // Load section data
    if (name === 'home') { loadHomeData(); }
    else if (name === 'matches') { loadMatches('live'); }
    else if (name === 'mybets') { loadBets('unsettled'); }
    else if (name === 'wallet') { loadTransactions('all'); loadWalletBalance(); }
    else if (name === 'notifications') { loadNotifications(); }
    else if (name === 'profile') { loadReferrals(); }
    
    window.scrollTo(0, 0);
}

function showPage(name) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    const page = document.getElementById('page-' + name);
    if (page) { page.classList.add('active'); }
    
    if (name === 'kyc') loadKYC();
    if (name === 'referral-program') { loadReferrals(); loadReferralInfo(); }
    window.scrollTo(0, 0);
}

function hidePage(name) {
    const page = document.getElementById('page-' + name);
    if (page) page.classList.remove('active');
    showSection('profile');
}

function showModal(id) {
    const m = new bootstrap.Modal(document.getElementById(id));
    m.show();
    if (id === 'termsModal') loadContent('terms');
    if (id === 'privacyModal') loadContent('privacy');
    if (id === 'helpModal') loadContent('help');
}

// ============ TOAST ============
function showToast(msg, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `app-toast ${type}`;
    toast.innerHTML = `<i class="bi ${type==='success'?'bi-check-circle':type==='error'?'bi-x-circle':'bi-info-circle'} me-2"></i>${msg}`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(100%)'; setTimeout(() => toast.remove(), 300); }, 3000);
}

function showStatus(elId, msg, type = 'success') {
    const el = document.getElementById(elId);
    if (!el) return;
    const colors = { success: '#22C55E', error: '#EF4444', warning: '#F59E0B', info: '#3B82F6' };
    el.innerHTML = `<div style="padding:8px 12px;border-radius:8px;background:${colors[type]}20;border:1px solid ${colors[type]}40;color:${colors[type]};font-size:0.85rem;">${msg}</div>`;
}

function showLoader(show) {
    const el = document.getElementById('globalLoader');
    if (el) el.style.display = show ? 'flex' : 'none';
}

// ============ API CALLS ============
async function apiCall(url, data = null) {
    const opts = { method: data ? 'POST' : 'GET', headers: {} };
    if (data) {
        if (data instanceof FormData) { opts.body = data; }
        else { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(data); }
    }
    const res = await fetch(url, opts);
    return res.json();
}

// ============ HOME DATA ============
async function loadHomeData() {
    try {
        const [matchRes, tournRes] = await Promise.all([
            apiCall('api/get_matches.php?status=all'),
            apiCall('api/get_tournaments.php?status=upcoming')
        ]);
        if (matchRes.success) renderHomeMatches(matchRes.matches);
        if (tournRes.success) renderTournaments(tournRes.tournaments, 'upcoming');
        loadBanners();
    } catch(e) { console.error(e); }
}

function renderHomeMatches(matches) {
    const live = matches.filter(m => m.status === 'live');
    const upcoming = matches.filter(m => m.status === 'upcoming');
    
    document.getElementById('liveMatchBadge').textContent = live.length;
    document.getElementById('upcomingMatchBadge').textContent = upcoming.length;
    
    document.getElementById('liveMatchesContainer').innerHTML = live.length
        ? live.map(m => matchCard(m)).join('')
        : '<div class="empty-state"><i class="bi bi-globe"></i><p>No live matches right now</p></div>';
    
    document.getElementById('upcomingMatchesContainer').innerHTML = upcoming.length
        ? upcoming.slice(0,3).map(m => matchCard(m)).join('')
        : '<div class="empty-state"><i class="bi bi-calendar3"></i><p>No upcoming matches</p></div>';
}

function matchCard(m) {
    const statusHtml = m.status === 'live' 
        ? '<span class="match-status-live">LIVE</span>' 
        : m.status === 'upcoming' 
        ? `<span class="match-status-upcoming">UPCOMING</span>`
        : '<span class="match-status-completed">COMPLETED</span>';
    
    const timeStr = m.status === 'upcoming' 
        ? `<small style="color:var(--text-muted);font-size:0.72rem;">${new Date(m.start_time).toLocaleString('en-IN',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</small>` 
        : '';
    
    const actionsHtml = m.status !== 'completed' ? `
        <div class="match-actions">
            <button class="bet-team-btn" onclick="openBetModal(${m.id},'${m.team1}',${m.odds_team1})">
                <div class="bet-team-name">${m.team1}</div>
                <div class="bet-odds">${m.odds_team1}x</div>
            </button>
            <button class="bet-team-btn" onclick="openBetModal(${m.id},'${m.team2}',${m.odds_team2})">
                <div class="bet-team-name">${m.team2}</div>
                <div class="bet-odds">${m.odds_team2}x</div>
            </button>
        </div>` : (m.winner ? `<div style="text-align:center;padding:10px;color:var(--primary-color);font-weight:600;font-size:0.9rem;"><i class="bi bi-trophy"></i> Winner: ${m.winner}</div>` : '');
    
    return `<div class="match-card">
        <div class="match-card-header">
            <div>
                <div class="match-label">${m.match_type || 'Match'}</div>
                ${timeStr}
            </div>
            <div style="display:flex;gap:6px;align-items:center;">${statusHtml}</div>
        </div>
        <div class="match-teams">
            <div class="team-block">
                ${m.team1_logo ? `<img src="${m.team1_logo}" class="team-logo" alt="${m.team1}">` : `<div class="team-logo" style="display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.2rem;">${m.team1.charAt(0)}</div>`}
                <div class="team-name">${m.team1}</div>
            </div>
            <div class="vs-divider">VS</div>
            <div class="team-block">
                ${m.team2_logo ? `<img src="${m.team2_logo}" class="team-logo" alt="${m.team2}">` : `<div class="team-logo" style="display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.2rem;">${m.team2.charAt(0)}</div>`}
                <div class="team-name">${m.team2}</div>
            </div>
        </div>
        ${actionsHtml}
    </div>`;
}

// ============ MATCHES ============
function loadMatches(status) {
    document.querySelectorAll('#matches .tab-btn').forEach((b,i) => {
        b.classList.toggle('active', ['live','upcoming','completed'][i] === status);
    });
    document.getElementById('matchesContainer').innerHTML = '<div class="skeleton-card"></div><div class="skeleton-card"></div>';
    
    apiCall(`api/get_matches.php?status=${status}`).then(res => {
        if (res.success) {
            document.getElementById('matchesContainer').innerHTML = res.matches.length
                ? res.matches.map(m => matchCard(m)).join('')
                : `<div class="empty-state"><i class="bi bi-calendar3"></i><p>No ${status} matches</p></div>`;
        }
    });
}

// ============ BETTING ============
function openBetModal(matchId, team, odds) {
    currentBetMatch = matchId;
    currentBetPick = team;
    currentBetOdds = odds;
    
    document.getElementById('betPickDisplay').textContent = team;
    document.getElementById('betOdds').textContent = odds + 'x';
    document.getElementById('betAmount').value = '';
    document.getElementById('potentialWin').textContent = '₹0.00';
    document.getElementById('betStatus').innerHTML = '';
    
    new bootstrap.Modal(document.getElementById('betModal')).show();
}

function setBetAmount(amount) {
    document.getElementById('betAmount').value = amount;
    updatePotentialWin();
}

document.addEventListener('input', function(e) {
    if (e.target.id === 'betAmount') updatePotentialWin();
});

function updatePotentialWin() {
    const amount = parseFloat(document.getElementById('betAmount').value) || 0;
    const win = (amount * currentBetOdds).toFixed(2);
    document.getElementById('potentialWin').textContent = '₹' + win;
}

async function submitBet() {
    const amount = parseFloat(document.getElementById('betAmount').value);
    if (!amount || amount < 10) { showStatus('betStatus', 'Minimum bet is ₹10', 'error'); return; }
    
    showLoader(true);
    const res = await apiCall('api/place_bet.php', { match_id: currentBetMatch, pick: currentBetPick, amount });
    showLoader(false);
    
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('betModal')).hide();
        showToast('Bet placed successfully!', 'success');
        updateHeaderBalance(res.new_balance);
    } else {
        showStatus('betStatus', res.message || 'Failed to place bet', 'error');
    }
}

// ============ TOURNAMENTS ============
function filterTournaments(status) {
    document.querySelectorAll('#home .tournament-tabs .tab-btn').forEach((b,i) => {
        b.classList.toggle('active', ['upcoming','live','completed'][i] === status);
    });
    document.getElementById('tournamentsContainer').innerHTML = '<div class="skeleton-card"></div>';
    
    apiCall(`api/get_tournaments.php?status=${status}`).then(res => {
        if (res.success) renderTournaments(res.tournaments, status);
    });
}

function renderTournaments(tournaments, status) {
    const container = document.getElementById('tournamentsContainer');
    if (!tournaments.length) {
        container.innerHTML = `<div class="empty-state"><i class="bi bi-trophy"></i><p>No ${status} tournaments</p></div>`;
        return;
    }
    container.innerHTML = tournaments.map(t => tournamentCard(t)).join('');
}

function tournamentCard(t) {
    const fillPct = t.max_slots > 0 ? Math.round((t.filled_slots / t.max_slots) * 100) : 0;
    const spotsLeft = t.max_slots - t.filled_slots;
    const timeStr = new Date(t.start_time).toLocaleString('en-IN', {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
    
    const joinBtn = t.is_registered
        ? `<button class="btn-join-tournament" onclick="viewRoomId(${t.id})" style="background:linear-gradient(135deg,#3B82F6,#1D4ED8)"><i class="bi bi-key"></i> Room ID</button>`
        : t.status === 'upcoming' && spotsLeft > 0
        ? `<button class="btn-join-tournament" onclick="openTournamentJoin(${t.id})"><i class="bi bi-plus-circle"></i> Join ₹${t.entry_fee}</button>`
        : `<button class="btn-join-tournament" style="opacity:0.5;cursor:not-allowed;" disabled>${t.status === 'live' ? 'In Progress' : 'Full'}</button>`;
    
    return `<div class="tournament-card">
        ${t.banner_image 
            ? `<img src="${t.banner_image}" class="tournament-banner" alt="${t.title}" loading="lazy">`
            : `<div class="tournament-banner-placeholder"><i class="bi bi-trophy"></i></div>`}
        <div class="tournament-body">
            <div class="tournament-header">
                <span class="tournament-tag">${t.game_name || 'Game'} · ${t.tournament_type || 'Solo'}</span>
                <span class="tournament-timer">${timeStr}</span>
            </div>
            <div class="tournament-title"><i class="bi bi-trophy" style="color:var(--accent-color)"></i> ${t.title}</div>
            <div class="tournament-info">
                <div class="ti-item">
                    <div class="ti-label">Prize Pool</div>
                    <div class="ti-value prize">₹${Number(t.prize_pool).toLocaleString('en-IN')}</div>
                </div>
                <div class="ti-item">
                    <div class="ti-label">Entry</div>
                    <div class="ti-value">${t.entry_fee > 0 ? '₹'+t.entry_fee : 'FREE'}</div>
                </div>
                <div class="ti-item">
                    <div class="ti-label">Slots</div>
                    <div class="ti-value">${t.filled_slots}/${t.max_slots}</div>
                </div>
            </div>
            <div class="tournament-spots">${spotsLeft} spots left</div>
            <div class="spots-bar"><div class="spots-fill" style="width:${fillPct}%"></div></div>
            <div class="tournament-actions">
                ${joinBtn}
                <button class="btn-tournament-details" onclick="viewTournamentDetails(${t.id})"><i class="bi bi-info-circle"></i></button>
            </div>
        </div>
    </div>`;
}

async function openTournamentJoin(tournId) {
    showLoader(true);
    const res = await apiCall(`api/get_tournament.php?id=${tournId}`);
    showLoader(false);
    if (!res.success) { showToast(res.message || 'Error', 'error'); return; }
    
    const t = res.tournament;
    const slots = res.slots || [];
    const occupiedSlots = slots.map(s => s.slot_number);
    
    document.getElementById('tjModalTitle').textContent = t.title;
    
    let slotsHtml = '';
    for (let i = 1; i <= t.max_slots; i++) {
        const isOccupied = occupiedSlots.includes(i);
        const isMine = res.my_slot === i;
        const cls = isMine ? 'mine' : isOccupied ? 'occupied' : 'available';
        slotsHtml += `<button class="slot-btn ${cls}" data-slot="${i}" ${isOccupied && !isMine ? 'disabled' : ''} onclick="selectSlot(${i})">${i}</button>`;
    }
    
    document.getElementById('tjModalBody').innerHTML = `
        <div style="background:var(--primary-bg);padding:12px;border-radius:10px;margin-bottom:15px;">
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.85rem;">
                <span class="text-muted">Entry Fee:</span><strong>₹${t.entry_fee}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.85rem;margin-top:6px;">
                <span class="text-muted">Prize Pool:</span><strong style="color:var(--accent-color);">₹${Number(t.prize_pool).toLocaleString()}</strong>
            </div>
        </div>
        <div style="margin-bottom:10px;">
            <div style="display:flex;gap:10px;margin-bottom:8px;font-size:0.78rem;">
                <span><span class="slot-btn available" style="display:inline-block;width:20px;height:20px;padding:0;pointer-events:none;"></span> Available</span>
                <span><span class="slot-btn occupied" style="display:inline-block;width:20px;height:20px;padding:0;pointer-events:none;"></span> Occupied</span>
                <span><span class="slot-btn mine" style="display:inline-block;width:20px;height:20px;padding:0;pointer-events:none;"></span> Yours</span>
            </div>
            <div class="slot-grid">${slotsHtml}</div>
        </div>
        <div id="selectedSlotInfo" style="display:none;padding:12px;background:rgba(29,185,84,0.1);border:1px solid var(--primary-color);border-radius:10px;margin-bottom:15px;text-align:center;">
            Selected Slot: <strong id="selectedSlotNum">-</strong>
        </div>
        <div id="joinStatus" class="mb-2"></div>
        <button class="btn btn-success w-100" id="confirmJoinBtn" onclick="confirmJoin(${t.id}, ${t.entry_fee})">
            <i class="bi bi-check2-circle"></i> Confirm Join
        </button>`;
    
    new bootstrap.Modal(document.getElementById('tournamentJoinModal')).show();
}

let selectedSlot = null;
function selectSlot(num) {
    selectedSlot = num;
    document.querySelectorAll('.slot-btn.available').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll(`.slot-btn[data-slot="${num}"]`).forEach(b => b.classList.add('selected'));
    const info = document.getElementById('selectedSlotInfo');
    const num2 = document.getElementById('selectedSlotNum');
    if (info) { info.style.display = 'block'; num2.textContent = num; }
}

async function confirmJoin(tournId, fee) {
    if (!selectedSlot) { showStatus('joinStatus', 'Please select a slot', 'error'); return; }
    showLoader(true);
    const res = await apiCall('api/join_tournament.php', { tournament_id: tournId, slot_number: selectedSlot });
    showLoader(false);
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('tournamentJoinModal')).hide();
        showToast('Successfully joined tournament!', 'success');
        updateHeaderBalance(res.new_balance);
        filterTournaments('upcoming');
    } else {
        showStatus('joinStatus', res.message || 'Failed to join', 'error');
    }
}

async function viewRoomId(tournId) {
    const res = await apiCall(`api/get_room.php?tournament_id=${tournId}`);
    if (!res.success) { showToast(res.message || 'Room not available yet', 'warning'); return; }
    
    document.getElementById('roomIdBody').innerHTML = `
        <div class="room-info-box">
            <div class="room-label">ROOM ID</div>
            <div class="room-value-row">
                <div class="room-value">${res.room_id || 'Not set yet'}</div>
                ${res.room_id ? `<button class="copy-btn-sm" onclick="copyText('${res.room_id}')"><i class="bi bi-clipboard"></i></button>` : ''}
            </div>
        </div>
        <div class="room-info-box">
            <div class="room-label">PASSWORD</div>
            <div class="room-value-row">
                <div class="room-value">${res.room_password || 'Not set yet'}</div>
                ${res.room_password ? `<button class="copy-btn-sm" onclick="copyText('${res.room_password}')"><i class="bi bi-clipboard"></i></button>` : ''}
            </div>
        </div>
        <p class="text-muted small mt-2"><i class="bi bi-info-circle"></i> Room ID & Password will be shared before match starts</p>`;
    
    new bootstrap.Modal(document.getElementById('roomIdModal')).show();
}

async function viewTournamentDetails(tournId) {
    const res = await apiCall(`api/get_tournament.php?id=${tournId}`);
    if (!res.success) return;
    const t = res.tournament;
    document.getElementById('matchDetailTitle').textContent = t.title;
    document.getElementById('matchDetailBody').innerHTML = `
        <p><strong>Game:</strong> ${t.game_name}</p>
        <p><strong>Type:</strong> ${t.tournament_type}</p>
        <p><strong>Start Time:</strong> ${new Date(t.start_time).toLocaleString('en-IN')}</p>
        <p><strong>Entry Fee:</strong> ₹${t.entry_fee}</p>
        <p><strong>Prize Pool:</strong> ₹${Number(t.prize_pool).toLocaleString()}</p>
        <p><strong>Per Kill Prize:</strong> ₹${t.per_kill_prize}</p>
        ${t.map ? `<p><strong>Map:</strong> ${t.map}</p>` : ''}
        ${t.version ? `<p><strong>Version:</strong> ${t.version}</p>` : ''}
        ${t.rules ? `<hr><strong>Rules:</strong><pre style="background:var(--primary-bg);padding:10px;border-radius:8px;color:var(--text-muted);font-size:0.83rem;white-space:pre-wrap;">${t.rules}</pre>` : ''}
        ${t.prize_distribution ? `<hr><strong>Prize Distribution:</strong><pre style="background:var(--primary-bg);padding:10px;border-radius:8px;color:var(--text-muted);font-size:0.83rem;white-space:pre-wrap;">${t.prize_distribution}</pre>` : ''}`;
    new bootstrap.Modal(document.getElementById('matchDetailModal')).show();
}

// ============ BETS ============
async function loadBets(type) {
    document.querySelectorAll('#mybets .tab-btn').forEach((b,i) => {
        b.classList.toggle('active', ['unsettled','settled'][i] === type);
    });
    document.getElementById('betsContainer').innerHTML = '<div class="skeleton-card"></div>';
    const res = await apiCall(`api/get_bets.php?type=${type}`);
    if (res.success) {
        const container = document.getElementById('betsContainer');
        if (!res.bets.length) {
            container.innerHTML = `<div class="empty-state"><i class="bi bi-clipboard"></i><p>No ${type} bets</p></div>`;
            return;
        }
        if (type === 'unsettled') document.getElementById('unsettledCount').textContent = res.bets.length;
        container.innerHTML = res.bets.map(b => `
            <div class="bet-card ${b.status}">
                <div class="bet-card-header">
                    <div class="bet-match">${b.team1} vs ${b.team2} · ${b.match_type}</div>
                    <div class="bet-time">${new Date(b.created_at).toLocaleString('en-IN')}</div>
                    <span class="badge bg-${b.status==='pending'?'warning text-dark':b.status==='won'?'success':'danger'}">${b.status.toUpperCase()}</span>
                </div>
                <div class="bet-details">
                    <div class="bet-question">Who will win the match?</div>
                    <div class="bet-info-grid">
                        <div class="bet-info-item"><label>Your Pick</label><span style="color:var(--info)">${b.pick}</span></div>
                        <div class="bet-info-item"><label>Amount</label><span>₹${b.amount}</span></div>
                        <div class="bet-info-item"><label>${b.status==='won'?'Won':'Potential Win'}</label><span style="color:var(--success)">₹${b.potential_win}</span></div>
                    </div>
                </div>
            </div>`).join('');
    }
}

// ============ WALLET ============
async function loadWalletBalance() {
    const res = await apiCall('api/get_balance.php');
    if (res.success) {
        const total = parseFloat(res.cash) + parseFloat(res.bonus) + parseFloat(res.winning);
        document.getElementById('walletTotalBalance').textContent = '₹' + total.toFixed(2);
        document.getElementById('wbDeposit').textContent = '₹' + parseFloat(res.cash).toFixed(2);
        document.getElementById('wbBonus').textContent = '₹' + parseFloat(res.bonus).toFixed(2);
        document.getElementById('wbWinnings').textContent = '₹' + parseFloat(res.winning).toFixed(2);
        document.getElementById('headerBalance').textContent = '₹' + Math.floor(total);
        document.getElementById('withdrawableBalance').textContent = '₹' + parseFloat(res.winning).toFixed(2);
    }
}

function updateHeaderBalance(total) {
    const el = document.getElementById('headerBalance');
    if (el) el.textContent = '₹' + Math.floor(total);
}

async function loadTransactions(type) {
    document.querySelectorAll('#wallet .match-tabs .tab-btn').forEach((b,i) => {
        b.classList.toggle('active', ['all','withdrawals','deposits'][i] === type);
    });
    const container = document.getElementById('transactionsContainer');
    container.innerHTML = '<div class="skeleton-card"></div>';
    const res = await apiCall(`api/get_transactions.php?type=${type}`);
    if (res.success) {
        if (!res.transactions.length) {
            container.innerHTML = `<div class="empty-state"><i class="bi bi-receipt"></i><p>No transactions</p></div>`;
            return;
        }
        container.innerHTML = res.transactions.map(t => {
            const isCredit = ['deposit','win','bonus','referral','coupon'].includes(t.type);
            const iconClass = isCredit ? 'green' : 'red';
            const icon = t.type === 'deposit' ? 'bi-arrow-down-circle' : t.type === 'withdrawal' ? 'bi-arrow-up-circle' : t.type === 'win' ? 'bi-trophy' : 'bi-wallet';
            return `<div class="transaction-item">
                <div class="tx-icon ${iconClass}"><i class="bi ${icon}"></i></div>
                <div class="tx-info">
                    <div class="tx-title">${t.type.charAt(0).toUpperCase() + t.type.slice(1)}</div>
                    <div class="tx-date">${t.balance_type?.charAt(0).toUpperCase()+t.balance_type?.slice(1)} · ${new Date(t.created_at).toLocaleString('en-IN')}</div>
                </div>
                <div style="text-align:right;">
                    <div class="tx-amount" style="color:${isCredit?'#22C55E':'#EF4444'}">${isCredit?'+':'-'}₹${parseFloat(t.amount).toFixed(2)}</div>
                    <div class="tx-status status-${t.status}">${t.status.charAt(0).toUpperCase()+t.status.slice(1)}</div>
                </div>
            </div>`;
        }).join('');
    }
}

// ============ DEPOSIT ============
function showDepositModal() {
    document.getElementById('depositStep1').style.display = 'block';
    document.getElementById('depositStep2').style.display = 'none';
    document.getElementById('depositAmountInput').value = '';
    
    apiCall('api/get_settings.php').then(res => {
        if (res.success) {
            document.getElementById('depositLimits').textContent = `Min: ₹${res.min_deposit} · Max: ₹${Number(res.max_deposit).toLocaleString()}`;
        }
    });
    new bootstrap.Modal(document.getElementById('depositModal')).show();
}

function setDeposit(amount) {
    document.getElementById('depositAmountInput').value = amount;
}

async function proceedToPayment() {
    depositAmount = parseFloat(document.getElementById('depositAmountInput').value);
    if (!depositAmount || depositAmount < 100) { showToast('Minimum deposit is ₹100', 'error'); return; }
    
    showLoader(true);
    const res = await apiCall('api/get_payment_info.php');
    showLoader(false);
    
    document.getElementById('depositStep1').style.display = 'none';
    document.getElementById('depositStep2').style.display = 'block';
    document.getElementById('payAmountDisplay').textContent = '₹' + depositAmount.toFixed(2);
    
    if (res.success) {
        const qrCard = document.getElementById('qrCard');
        qrCard.innerHTML = res.qr_image 
            ? `<img src="${res.qr_image}" alt="QR Code" style="max-width:200px;border-radius:8px;"><p class="mt-2 text-muted small">Scan QR Code to Pay</p>`
            : `<div style="padding:20px;color:var(--text-muted);"><i class="bi bi-qr-code" style="font-size:3rem;"></i><p class="mt-2">QR Code not available</p></div>`;
        
        document.getElementById('upiDisplay').innerHTML = res.upi_id
            ? `<div class="upi-id-text" onclick="copyText('${res.upi_id}')">${res.upi_id} <i class="bi bi-clipboard" style="font-size:0.8rem;"></i></div>
               <div class="upi-label">${res.upi_name || ''} · Tap to copy</div>`
            : '';
    }
}

function goBackDeposit() {
    document.getElementById('depositStep1').style.display = 'block';
    document.getElementById('depositStep2').style.display = 'none';
}

function previewReceipt(input) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('receiptPreviewImg').src = e.target.result;
            document.getElementById('receiptPreview').style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

async function submitDeposit() {
    const utr = document.getElementById('utrInput').value.trim();
    if (!utr || utr.length < 6) { showStatus('depositSubmitStatus', 'Please enter valid UTR number (6+ digits)', 'error'); return; }
    
    const formData = new FormData();
    formData.append('amount', depositAmount);
    formData.append('utr_number', utr);
    const receipt = document.getElementById('receiptFile').files[0];
    if (receipt) formData.append('receipt', receipt);
    
    showLoader(true);
    const res = await apiCall('api/submit_deposit.php', formData);
    showLoader(false);
    
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('depositModal')).hide();
        showToast('Deposit request submitted! Admin will verify shortly.', 'success');
    } else {
        showStatus('depositSubmitStatus', res.message || 'Submission failed', 'error');
    }
}

// ============ WITHDRAW ============
function showWithdrawModal() {
    loadWalletBalance();
    new bootstrap.Modal(document.getElementById('withdrawModal')).show();
}

function switchWithdrawTab(tab) {
    currentWithdrawTab = tab;
    document.querySelectorAll('#withdrawModal .tab-btn').forEach((b,i) => {
        b.classList.toggle('active', ['upi','bank'][i] === tab);
    });
    document.getElementById('withdrawUpiTab').style.display = tab === 'upi' ? 'block' : 'none';
    document.getElementById('withdrawBankTab').style.display = tab === 'bank' ? 'block' : 'none';
}

async function submitWithdrawal(method) {
    const data = { method };
    const statusId = `withdraw${method.charAt(0).toUpperCase()+method.slice(1)}Status`;
    
    if (method === 'upi') {
        data.upi_id = document.getElementById('withdrawUpiId').value.trim();
        data.amount = parseFloat(document.getElementById('withdrawAmountUpi').value);
        if (!data.upi_id) { showStatus(statusId, 'Enter UPI ID', 'error'); return; }
    } else {
        data.account_holder = document.getElementById('wBankHolder').value.trim();
        data.account_number = document.getElementById('wBankAccount').value.trim();
        data.ifsc_code = document.getElementById('wBankIfsc').value.trim();
        data.bank_name = document.getElementById('wBankName').value.trim();
        data.amount = parseFloat(document.getElementById('withdrawAmountBank').value);
        if (!data.account_holder || !data.account_number || !data.ifsc_code) {
            showStatus(statusId, 'Fill all bank details', 'error'); return;
        }
    }
    
    if (!data.amount || data.amount < 100) { showStatus(statusId, 'Minimum withdrawal is ₹100', 'error'); return; }
    
    showLoader(true);
    const res = await apiCall('api/submit_withdrawal.php', data);
    showLoader(false);
    
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('withdrawModal')).hide();
        showToast('Withdrawal request submitted!', 'success');
        loadWalletBalance();
    } else {
        showStatus(statusId, res.message || 'Failed', 'error');
    }
}

// ============ COUPON ============
async function applyCoupon() {
    const code = document.getElementById('couponInput').value.trim().toUpperCase();
    if (!code) { showStatus('couponStatus', 'Enter a coupon code', 'warning'); return; }
    
    showLoader(true);
    const res = await apiCall('api/apply_coupon.php', { code });
    showLoader(false);
    
    if (res.success) {
        showStatus('couponStatus', `Coupon applied! ₹${res.amount} added to your ${res.balance_type} balance.`, 'success');
        document.getElementById('couponInput').value = '';
        loadWalletBalance();
    } else {
        showStatus('couponStatus', res.message || 'Invalid coupon', 'error');
    }
}

// ============ PROFILE / KYC ============
async function updateProfile(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    showLoader(true);
    const res = await apiCall('api/update_profile.php', formData);
    showLoader(false);
    showStatus('editProfileStatus', res.message, res.success ? 'success' : 'error');
}

async function uploadAvatar(input) {
    const file = input.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('avatar', file);
    showLoader(true);
    const res = await apiCall('api/upload_avatar.php', formData);
    showLoader(false);
    if (res.success) {
        document.getElementById('profileAvatar').src = res.path;
        showToast('Avatar updated!', 'success');
    } else { showToast(res.message || 'Failed', 'error'); }
}

async function uploadAvatarEdit(input) {
    const file = input.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('avatar', file);
    showLoader(true);
    const res = await apiCall('api/upload_avatar.php', formData);
    showLoader(false);
    if (res.success) {
        document.getElementById('editAvatar').src = res.path;
        showToast('Avatar updated!', 'success');
    }
}

async function saveBankDetails(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    showLoader(true);
    const res = await apiCall('api/save_bank.php', formData);
    showLoader(false);
    showStatus('bankStatus', res.message, res.success ? 'success' : 'error');
}

async function loadKYC() {
    const res = await apiCall('api/get_kyc.php');
    const container = document.getElementById('kycContent');
    if (res.success && res.kyc && res.kyc.status === 'verified') {
        container.innerHTML = `<div class="kyc-status-card"><i class="bi bi-shield-check" style="font-size:3rem;color:#22C55E;display:block;margin-bottom:10px;"></i><h5>KYC Verified</h5><p class="text-muted">Your identity has been verified successfully.</p></div>`;
        return;
    }
    if (res.success && res.kyc && res.kyc.status === 'submitted') {
        container.innerHTML = `<div class="kyc-status-card"><i class="bi bi-clock" style="font-size:3rem;color:#F59E0B;display:block;margin-bottom:10px;"></i><h5>Under Review</h5><p class="text-muted">Your KYC documents are being reviewed. This may take 24-48 hours.</p></div>`;
        return;
    }
    container.innerHTML = `
        <div class="custom-card">
            <p class="text-muted small mb-3"><i class="bi bi-info-circle"></i> Upload your identity documents to verify your account.</p>
            <form id="kycForm" onsubmit="submitKYC(event)">
                <div class="mb-3">
                    <label class="form-label">Document Type</label>
                    <select class="form-select" name="doc_type" required>
                        <option value="aadhar">Aadhar Card</option>
                        <option value="pan">PAN Card</option>
                        <option value="driving">Driving License</option>
                        <option value="passport">Passport</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Document Front</label>
                    <div class="upload-area" onclick="document.getElementById('kycFront').click()">
                        <i class="bi bi-cloud-upload"></i><p>Tap to upload front side</p><small>JPG/PNG Max 5MB</small>
                        <input type="file" id="kycFront" name="doc_front" style="display:none;" accept="image/*" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Document Back</label>
                    <div class="upload-area" onclick="document.getElementById('kycBack').click()">
                        <i class="bi bi-cloud-upload"></i><p>Tap to upload back side</p><small>JPG/PNG Max 5MB</small>
                        <input type="file" id="kycBack" name="doc_back" style="display:none;" accept="image/*">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Selfie with Document</label>
                    <div class="upload-area" onclick="document.getElementById('kycSelfie').click()">
                        <i class="bi bi-camera"></i><p>Tap to upload selfie</p><small>JPG/PNG Max 5MB</small>
                        <input type="file" id="kycSelfie" name="selfie" style="display:none;" accept="image/*" required>
                    </div>
                </div>
                <div id="kycStatus" class="mb-2"></div>
                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-upload"></i> Submit KYC</button>
            </form>
        </div>`;
}

async function submitKYC(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    showLoader(true);
    const res = await apiCall('api/submit_kyc.php', formData);
    showLoader(false);
    if (res.success) {
        showToast('KYC submitted successfully!', 'success');
        loadKYC();
    } else {
        showStatus('kycStatus', res.message || 'Failed', 'error');
    }
}

// ============ NOTIFICATIONS ============
async function loadNotifications() {
    const container = document.getElementById('notificationsContainer');
    container.innerHTML = '<div class="skeleton-card"></div><div class="skeleton-card"></div>';
    const res = await apiCall('api/get_notifications.php');
    if (res.success) {
        if (!res.notifications.length) {
            container.innerHTML = '<div class="empty-state"><i class="bi bi-bell-slash"></i><p>No notifications</p></div>';
            return;
        }
        const icons = { success: 'bi-check-circle-fill', warning: 'bi-exclamation-circle-fill', error: 'bi-x-circle-fill', info: 'bi-info-circle-fill' };
        container.innerHTML = res.notifications.map(n => `
            <div class="notif-item ${n.is_read ? '' : 'unread'}">
                <div class="notif-icon ${n.type}"><i class="bi ${icons[n.type] || 'bi-bell'}"></i></div>
                <div>
                    <div class="notif-title">${n.title}</div>
                    <div class="notif-msg">${n.message}</div>
                    <div class="notif-time">${timeAgo(n.created_at)}</div>
                </div>
            </div>`).join('');
        // Mark as read
        apiCall('api/mark_notifications.php', { action: 'read_all' });
        document.getElementById('notifBadge')?.remove();
    }
}

// ============ REFERRALS ============
async function loadReferrals() {
    const res = await apiCall('api/get_referrals.php');
    const el = document.getElementById('referralsList');
    if (!el) return;
    if (res.success && res.referrals.length) {
        el.innerHTML = res.referrals.map(r => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-color);">
                <div>
                    <div style="font-weight:600;font-size:0.9rem;">${r.username}</div>
                    <div style="font-size:0.75rem;color:var(--text-muted);">${timeAgo(r.created_at)}</div>
                </div>
                <div style="color:#22C55E;font-weight:700;">+₹${r.bonus}</div>
            </div>`).join('');
    } else {
        el.innerHTML = '<div class="text-center text-muted py-3">No referrals yet</div>';
    }
}

async function loadReferralInfo() {
    const res = await apiCall('api/get_settings.php');
    if (res.success) {
        const el = document.getElementById('referralBonusText');
        if (el) el.textContent = `Earn ₹${res.referral_bonus} when a friend registers using your code!`;
    }
}

function copyReferral() {
    copyText(APP.referralCode);
    showToast('Referral code copied!', 'success');
}

function shareReferral() {
    const msg = `Join ${APP.siteName} and get bonus! Use my referral code: ${APP.referralCode}\nSign up: ${window.location.origin}${window.location.pathname.replace('index.php','')}register.php?ref=${APP.referralCode}`;
    if (navigator.share) {
        navigator.share({ title: APP.siteName, text: msg });
    } else {
        const wa = `https://wa.me/?text=${encodeURIComponent(msg)}`;
        window.open(wa, '_blank');
    }
}

// ============ CHAT ============
async function toggleChat() {
    chatOpen = !chatOpen;
    const widget = document.getElementById('chatWidget');
    const fab = document.getElementById('chatFab');
    widget.style.display = chatOpen ? 'flex' : 'none';
    if (chatOpen) {
        fab.style.display = 'none';
        loadChatMessages();
        startChatPolling();
    } else {
        fab.style.display = 'flex';
        stopChatPolling();
    }
}

function closeChatWidget() {
    chatOpen = false;
    document.getElementById('chatWidget').style.display = 'none';
    document.getElementById('chatFab').style.display = 'flex';
    stopChatPolling();
}

async function loadChatMessages() {
    const res = await apiCall('api/get_chat.php');
    if (res.success) {
        const container = document.getElementById('chatMessages');
        if (!res.messages.length) {
            container.innerHTML = '<div class="chat-msg from-admin"><div class="chat-bubble">Hello! How can we help you today?</div></div>';
        } else {
            container.innerHTML = res.messages.map(m => `
                <div class="chat-msg ${m.sender === 'user' ? 'from-user' : 'from-admin'}">
                    <div class="chat-bubble">${m.message}</div>
                    <div class="chat-time">${timeAgo(m.created_at)}</div>
                </div>`).join('');
        }
        container.scrollTop = container.scrollHeight;
        document.getElementById('chatBadge')?.remove();
    }
}

function startChatPolling() {
    chatPolling = setInterval(loadChatMessages, 5000);
}

function stopChatPolling() {
    if (chatPolling) { clearInterval(chatPolling); chatPolling = null; }
}

async function sendChat() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    
    const res = await apiCall('api/send_chat.php', { message: msg });
    if (res.success) loadChatMessages();
}

// ============ CONTENT ============
async function loadContent(type) {
    const res = await apiCall(`api/get_content.php?type=${type}`);
    const elId = type === 'terms' ? 'termsContent' : type === 'privacy' ? 'privacyContent' : 'helpContent';
    const el = document.getElementById(elId);
    if (el && res.success) el.textContent = res.content;
}

async function loadBanners() {
    // Banners loaded via inline script in index.php
}

// ============ LOGOUT ============
async function doLogout() {
    if (!confirm('Are you sure you want to logout?')) return;
    await apiCall('api/logout.php');
    window.location.href = 'login.php';
}

// ============ UTILITIES ============
function copyText(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Copied!', 'success')).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
        showToast('Copied!', 'success');
    });
}

function timeAgo(dateStr) {
    const diff = Math.floor((Date.now() - new Date(dateStr)) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff/60) + 'm ago';
    if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
    return Math.floor(diff/86400) + 'd ago';
}

// ============ INIT ============
document.addEventListener('DOMContentLoaded', function() {
    loadHomeData();
    
    // Keyboard shortcut for chat
    document.getElementById('chatInput')?.addEventListener('keypress', e => {
        if (e.key === 'Enter') sendChat();
    });
    
    // Hash navigation
    const hash = window.location.hash.replace('#', '');
    if (hash && ['home','matches','mybets','wallet','profile'].includes(hash)) {
        showSection(hash);
    }
});

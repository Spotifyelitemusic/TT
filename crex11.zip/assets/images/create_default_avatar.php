<?php
// Creates a simple default avatar SVG
$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="#1A1A1A"/><circle cx="50" cy="38" r="18" fill="#555"/><path d="M10 90c0-22 18-35 40-35s40 13 40 35" fill="#555"/></svg>';
file_put_contents(__DIR__.'/default-avatar.png', $svg);

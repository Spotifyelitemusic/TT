<?php
require_once __DIR__ . '/includes/auth.php';

// If already logged in, redirect
$user = getCurrentUser();
if ($user) { header('Location: index.php'); exit; }

$siteName = getSetting('site_name', 'CREX 11');
$siteLogo = getSetting('site_logo');
$primaryColor = getSetting('primary_color', '#1DB954');
$googleClientId = getSetting('google_client_id');
$refCode = $_GET['ref'] ?? '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    header('Content-Type: application/json');
    
    if ($action === 'login') {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (!$email || !$password) { echo json_encode(['success'=>false,'message'=>'Fill all fields']); exit; }
        
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && verifyPassword($password, $user['password'])) {
            $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
            createSession($user['id']);
            echo json_encode(['success'=>true]);
        } else {
            echo json_encode(['success'=>false,'message'=>'Invalid email or password']);
        }
        exit;
    }
    
    if ($action === 'register') {
        $username = sanitize($_POST['username'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $fullName = sanitize($_POST['full_name'] ?? '');
        $referral = sanitize($_POST['referral_code'] ?? '');
        
        if (!$username || !$email || !$password || !$fullName) {
            echo json_encode(['success'=>false,'message'=>'Fill all required fields']); exit;
        }
        if (strlen($password) < 6) {
            echo json_encode(['success'=>false,'message'=>'Password must be at least 6 characters']); exit;
        }
        
        $db = getDB();
        
        // Check duplicate
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            echo json_encode(['success'=>false,'message'=>'Email or username already taken']); exit;
        }
        
        // Handle referral
        $referredBy = null;
        if ($referral) {
            $rStmt = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
            $rStmt->execute([$referral]);
            $rUser = $rStmt->fetch();
            if ($rUser) $referredBy = $rUser['id'];
        }
        
        $code = generateReferralCode();
        $hash = hashPassword($password);
        
        $stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, referral_code, referred_by, email_verified) VALUES (?,?,?,?,?,?,1)");
        $stmt->execute([$username, $email, $hash, $fullName, $code, $referredBy]);
        $userId = $db->lastInsertId();
        
        // Auto referral bonus
        if ($referredBy) {
            $bonusAmt = getSetting('referral_bonus', 50);
            $bonusType = getSetting('referral_bonus_type', 'cash');
            addBalance($referredBy, $bonusAmt, $bonusType, 'referral', "Referral bonus from @$username", $code);
            sendNotification($referredBy, 'Referral Bonus!', "You earned ₹{$bonusAmt} referral bonus! @{$username} joined using your code.", 'success');
            $db->prepare("UPDATE users SET total_wins = total_wins + 1 WHERE id = ?")->execute([$referredBy]);
        }
        
        createSession($userId);
        echo json_encode(['success'=>true]);
        exit;
    }
    
    if ($action === 'google_auth') {
        $token = $_POST['token'] ?? '';
        $clientId = getSetting('google_client_id');
        
        // Verify Google token
        $url = "https://oauth2.googleapis.com/tokeninfo?id_token=" . urlencode($token);
        $response = @file_get_contents($url);
        $payload = json_decode($response, true);
        
        if (!$payload || ($payload['aud'] ?? '') !== $clientId) {
            echo json_encode(['success'=>false,'message'=>'Invalid Google token']); exit;
        }
        
        $googleId = $payload['sub'];
        $email = $payload['email'];
        $fullName = $payload['name'] ?? '';
        $avatar = $payload['picture'] ?? '';
        
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE google_id = ? OR email = ?");
        $stmt->execute([$googleId, $email]);
        $user = $stmt->fetch();
        
        if ($user) {
            $db->prepare("UPDATE users SET google_id = ?, last_login = NOW() WHERE id = ?")->execute([$googleId, $user['id']]);
            createSession($user['id']);
        } else {
            $username = 'user' . time() . rand(100, 999);
            $code = generateReferralCode();
            $referral = sanitize($_POST['ref'] ?? '');
            $referredBy = null;
            if ($referral) {
                $rStmt = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
                $rStmt->execute([$referral]);
                $rUser = $rStmt->fetch();
                if ($rUser) $referredBy = $rUser['id'];
            }
            
            $stmt = $db->prepare("INSERT INTO users (username, email, full_name, avatar, google_id, auth_provider, referral_code, referred_by, email_verified) VALUES (?,?,?,?,?,'google',?,?,1)");
            $stmt->execute([$username, $email, $fullName, $avatar, $googleId, $code, $referredBy]);
            $userId = $db->lastInsertId();
            
            if ($referredBy) {
                $bonusAmt = getSetting('referral_bonus', 50);
                $bonusType = getSetting('referral_bonus_type', 'cash');
                addBalance($referredBy, $bonusAmt, $bonusType, 'referral', "Referral bonus", $code);
                sendNotification($referredBy, 'Referral Bonus!', "You earned ₹{$bonusAmt} referral bonus!", 'success');
            }
            createSession($userId);
        }
        echo json_encode(['success'=>true]);
        exit;
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($siteName) ?> - Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php if ($googleClientId): ?>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <?php endif; ?>
    <style>
        :root { --primary: <?= htmlspecialchars($primaryColor) ?>; }
        * { margin:0;padding:0;box-sizing:border-box; }
        body { font-family:'Poppins',sans-serif; background:#000; color:#fff; min-height:100vh; display:flex; flex-direction:column; justify-content:center; padding:20px; }
        .auth-container { max-width:420px; margin:0 auto; width:100%; }
        .auth-header { text-align:center; margin-bottom:30px; }
        .auth-logo { width:70px;height:70px;border-radius:50%;border:3px solid var(--primary);background:var(--primary);display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:800;color:#000;margin:0 auto 15px; }
        .auth-logo img { width:100%;height:100%;border-radius:50%;object-fit:cover; }
        .auth-title { font-size:1.8rem;font-weight:800; }
        .auth-subtitle { color:#888;font-size:0.88rem; }
        .auth-card { background:#1A1A1A;border-radius:16px;padding:28px 24px;border:1px solid #2A2A2A; }
        .tab-nav { display:flex;background:#000;border-radius:10px;padding:4px;margin-bottom:24px; }
        .tab-nav button { flex:1;border:none;background:none;color:#888;padding:10px;border-radius:7px;font-weight:600;font-size:0.9rem;cursor:pointer;transition:all 0.2s; }
        .tab-nav button.active { background:var(--primary);color:#000; }
        .form-group { margin-bottom:16px; }
        .form-label { font-size:0.8rem;font-weight:600;color:#888;letter-spacing:0.5px;margin-bottom:6px;display:block; }
        .form-control { background:#000;border:1px solid #333;border-radius:8px;padding:11px 14px;color:#fff;font-size:0.92rem;width:100%; }
        .form-control:focus { outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(29,185,84,0.15); }
        .form-control::placeholder { color:#555; }
        .btn-main { background:var(--primary);color:#000;border:none;border-radius:10px;padding:13px;font-size:1rem;font-weight:700;width:100%;cursor:pointer;transition:filter 0.2s; }
        .btn-main:hover { filter:brightness(1.1); }
        .divider { text-align:center;margin:18px 0;position:relative;color:#555; }
        .divider::before,.divider::after { content:'';position:absolute;top:50%;width:42%;height:1px;background:#2A2A2A; }
        .divider::before { left:0; } .divider::after { right:0; }
        .divider span { background:#1A1A1A;padding:0 12px;font-size:0.8rem; }
        .btn-google { background:#fff;color:#333;border:none;border-radius:10px;padding:12px;font-size:0.92rem;font-weight:600;width:100%;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:filter 0.2s; }
        .btn-google:hover { filter:brightness(0.95); }
        .google-icon { width:20px;height:20px; }
        .status-msg { padding:10px 14px;border-radius:8px;font-size:0.87rem;margin-top:12px; }
        .status-msg.error { background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#EF4444; }
        .status-msg.success { background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:#22C55E; }
        .terms-label { font-size:0.78rem;color:#888; }
        .terms-label a { color:var(--primary); }
    </style>
</head>
<body>
<div class="auth-container">
    <div class="auth-header">
        <div class="auth-logo">
            <?php if ($siteLogo): ?>
                <img src="<?= htmlspecialchars($siteLogo) ?>" alt="Logo">
            <?php else: ?>
                <?= htmlspecialchars(substr($siteName, 0, 1)) ?>
            <?php endif; ?>
        </div>
        <div class="auth-title"><?= htmlspecialchars($siteName) ?></div>
        <div class="auth-subtitle">Play & Win Real Cash</div>
    </div>
    
    <div class="auth-card">
        <div class="tab-nav">
            <button class="active" onclick="switchTab('login')">Login</button>
            <button onclick="switchTab('register')">Sign Up</button>
        </div>
        
        <!-- LOGIN FORM -->
        <div id="loginForm">
            <?php if ($googleClientId): ?>
            <button class="btn-google mb-3" onclick="googleSignIn()">
                <svg class="google-icon" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with Google
            </button>
            <div class="divider"><span>OR</span></div>
            <?php endif; ?>
            <form id="loginFormEl" onsubmit="doLogin(event)">
                <div class="form-group">
                    <label class="form-label">EMAIL</label>
                    <input type="email" class="form-control" name="email" placeholder="your@email.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">PASSWORD</label>
                    <div style="position:relative;">
                        <input type="password" class="form-control" name="password" id="loginPassword" placeholder="Your password" required style="padding-right:42px;">
                        <button type="button" onclick="togglePwd('loginPassword')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#666;cursor:pointer;"><i class="bi bi-eye" id="loginEyeIcon"></i></button>
                    </div>
                </div>
                <div id="loginStatus"></div>
                <button type="submit" class="btn-main mt-2">Login</button>
            </form>
        </div>
        
        <!-- REGISTER FORM -->
        <div id="registerForm" style="display:none;">
            <?php if ($googleClientId): ?>
            <button class="btn-google mb-3" onclick="googleSignIn()">
                <svg class="google-icon" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Sign up with Google
            </button>
            <div class="divider"><span>OR</span></div>
            <?php endif; ?>
            <form id="registerFormEl" onsubmit="doRegister(event)">
                <div class="form-group">
                    <label class="form-label">FULL NAME</label>
                    <input type="text" class="form-control" name="full_name" placeholder="Your full name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">USERNAME</label>
                    <input type="text" class="form-control" name="username" placeholder="unique_username" required>
                </div>
                <div class="form-group">
                    <label class="form-label">EMAIL</label>
                    <input type="email" class="form-control" name="email" placeholder="your@email.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">PASSWORD</label>
                    <div style="position:relative;">
                        <input type="password" class="form-control" name="password" id="regPassword" placeholder="Min 6 characters" required style="padding-right:42px;">
                        <button type="button" onclick="togglePwd('regPassword')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#666;cursor:pointer;"><i class="bi bi-eye" id="regEyeIcon"></i></button>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">REFERRAL CODE (OPTIONAL)</label>
                    <input type="text" class="form-control" name="referral_code" placeholder="Enter referral code" value="<?= htmlspecialchars($refCode) ?>" style="text-transform:uppercase;">
                </div>
                <div class="form-group">
                    <label class="terms-label">
                        <input type="checkbox" required style="margin-right:6px;">
                        I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                    </label>
                </div>
                <div id="registerStatus"></div>
                <button type="submit" class="btn-main">Create Account</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const REF_CODE = '<?= htmlspecialchars($refCode) ?>';
const GOOGLE_CLIENT_ID = '<?= htmlspecialchars($googleClientId) ?>';

function switchTab(tab) {
    document.querySelectorAll('.tab-nav button').forEach((b,i) => b.classList.toggle('active', ['login','register'][i] === tab));
    document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
    document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
}

function togglePwd(id) {
    const input = document.getElementById(id);
    const icon = document.getElementById(id === 'loginPassword' ? 'loginEyeIcon' : 'regEyeIcon');
    if (input.type === 'password') { input.type = 'text'; icon.className = 'bi bi-eye-slash'; }
    else { input.type = 'password'; icon.className = 'bi bi-eye'; }
}

function showStatus(id, msg, type) {
    document.getElementById(id).innerHTML = `<div class="status-msg ${type}">${msg}</div>`;
}

async function doLogin(e) {
    e.preventDefault();
    const form = e.target;
    const data = { action: 'login', email: form.email.value, password: form.password.value };
    const btn = form.querySelector('button[type=submit]');
    btn.textContent = 'Logging in...'; btn.disabled = true;
    
    const res = await fetch('', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
    const json = await res.json();
    btn.textContent = 'Login'; btn.disabled = false;
    
    if (json.success) { window.location.href = 'index.php'; }
    else { showStatus('loginStatus', json.message, 'error'); }
}

async function doRegister(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    formData.append('action', 'register');
    
    const btn = form.querySelector('button[type=submit]');
    btn.textContent = 'Creating...'; btn.disabled = true;
    
    const res = await fetch('', { method:'POST', body: formData });
    const json = await res.json();
    btn.textContent = 'Create Account'; btn.disabled = false;
    
    if (json.success) { window.location.href = 'index.php'; }
    else { showStatus('registerStatus', json.message, 'error'); }
}

// Google Sign In
function googleSignIn() {
    if (!GOOGLE_CLIENT_ID) { alert('Google sign-in not configured'); return; }
    google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: handleGoogleResponse
    });
    google.accounts.id.prompt();
}

async function handleGoogleResponse(response) {
    const res = await fetch('', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ action: 'google_auth', token: response.credential, ref: REF_CODE })
    });
    const json = await res.json();
    if (json.success) { window.location.href = 'index.php'; }
    else { alert(json.message || 'Google sign-in failed'); }
}

// Check if ?tab=register in URL
if (window.location.search.includes('tab=register')) switchTab('register');
</script>
</body>
</html>

<?php
$ref = $_GET['ref'] ?? '';
header("Location: login.php?tab=register" . ($ref ? "&ref=$ref" : ""));
exit;

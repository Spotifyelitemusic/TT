<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$type = $_GET['type'] ?? 'unsettled';
$where = $type === 'settled' ? "b.status IN ('won','lost','cancelled','refunded')" : "b.status = 'pending'";
$stmt = $db->prepare("SELECT b.*, m.team1, m.team2, m.match_type, m.winner FROM bets b JOIN matches m ON m.id = b.match_id WHERE b.user_id = ? AND {$where} ORDER BY b.created_at DESC");
$stmt->execute([$user['id']]);
jsonResponse(['success'=>true,'bets'=>$stmt->fetchAll()]);

<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$fullName = sanitize($_POST['full_name'] ?? '');
$username = sanitize($_POST['username'] ?? '');
$phone = sanitize($_POST['phone'] ?? '');
$newPwd = $_POST['new_password'] ?? '';
if (!$fullName || !$username) { jsonResponse(['success'=>false,'message'=>'Name and username required']); }
$db = getDB();
$stmt = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
$stmt->execute([$username, $user['id']]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'Username already taken']); }
if ($newPwd) {
    if (strlen($newPwd) < 6) { jsonResponse(['success'=>false,'message'=>'Password must be at least 6 chars']); }
    $db->prepare("UPDATE users SET full_name=?,username=?,phone=?,password=? WHERE id=?")
       ->execute([$fullName,$username,$phone,hashPassword($newPwd),$user['id']]);
} else {
    $db->prepare("UPDATE users SET full_name=?,username=?,phone=? WHERE id=?")->execute([$fullName,$username,$phone,$user['id']]);
}
jsonResponse(['success'=>true,'message'=>'Profile updated successfully!']);

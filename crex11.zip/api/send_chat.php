<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$input = json_decode(file_get_contents('php://input'), true);
$msg = trim($input['message'] ?? '');
if (!$msg) { jsonResponse(['success'=>false,'message'=>'Empty message']); }
$db = getDB();
$db->prepare("INSERT INTO chat_messages (user_id,sender,message) VALUES (?,'user',?)")->execute([$user['id'],$msg]);
jsonResponse(['success'=>true]);

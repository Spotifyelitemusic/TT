<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$stmt = $db->prepare("SELECT * FROM kyc_verifications WHERE user_id = ?");
$stmt->execute([$user['id']]);
$kyc = $stmt->fetch();
jsonResponse(['success'=>true,'kyc'=>$kyc]);

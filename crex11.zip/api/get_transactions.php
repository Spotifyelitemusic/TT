<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$type = $_GET['type'] ?? 'all';
if ($type === 'withdrawals') {
    $stmt = $db->prepare("SELECT id, amount, status, created_at, 'withdrawal' as type, 'winning' as balance_type, '' as note FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
    $stmt->execute([$user['id']]);
} elseif ($type === 'deposits') {
    $stmt = $db->prepare("SELECT id, amount, status, created_at, 'deposit' as type, 'cash' as balance_type, '' as note FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
    $stmt->execute([$user['id']]);
} else {
    $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 100");
    $stmt->execute([$user['id']]);
}
jsonResponse(['success'=>true,'transactions'=>$stmt->fetchAll()]);

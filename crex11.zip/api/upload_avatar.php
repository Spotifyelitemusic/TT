<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
if (empty($_FILES['avatar'])) { jsonResponse(['success'=>false,'message'=>'No file']); }
$up = uploadFile($_FILES['avatar'], 'avatars');
if ($up['success']) {
    $db = getDB();
    $db->prepare("UPDATE users SET avatar = ? WHERE id = ?")->execute([$up['path'], $user['id']]);
    jsonResponse(['success'=>true,'path'=>$up['path']]);
} else {
    jsonResponse(['success'=>false,'message'=>$up['message']]);
}

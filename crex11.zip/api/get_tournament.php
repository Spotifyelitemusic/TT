<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { jsonResponse(['success'=>false,'message'=>'Invalid ID']); }

$stmt = $db->prepare("SELECT t.*, g.name as game_name FROM tournaments t LEFT JOIN games g ON g.id = t.game_id WHERE t.id = ?");
$stmt->execute([$id]);
$tournament = $stmt->fetch();
if (!$tournament) { jsonResponse(['success'=>false,'message'=>'Tournament not found']); }

// Get slots
$sStmt = $db->prepare("SELECT tr.slot_number, u.username FROM tournament_registrations tr JOIN users u ON u.id = tr.user_id WHERE tr.tournament_id = ?");
$sStmt->execute([$id]);
$slots = $sStmt->fetchAll();

// My slot
$mStmt = $db->prepare("SELECT slot_number FROM tournament_registrations WHERE tournament_id = ? AND user_id = ?");
$mStmt->execute([$id, $user['id']]);
$myReg = $mStmt->fetch();
$mySlot = $myReg ? $myReg['slot_number'] : null;

jsonResponse(['success'=>true,'tournament'=>$tournament,'slots'=>$slots,'my_slot'=>$mySlot]);

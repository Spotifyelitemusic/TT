<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$amount = (float)($_POST['amount'] ?? 0);
$utr = sanitize($_POST['utr_number'] ?? '');
if ($amount < 100 || !$utr) { jsonResponse(['success'=>false,'message'=>'Invalid data']); }
$db = getDB();
// Check duplicate UTR
$stmt = $db->prepare("SELECT id FROM deposits WHERE utr_number = ?");
$stmt->execute([$utr]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'This UTR number already submitted']); }
$receiptPath = '';
if (!empty($_FILES['receipt']['tmp_name'])) {
    $up = uploadFile($_FILES['receipt'], 'receipts');
    if ($up['success']) $receiptPath = $up['path'];
}
$db->prepare("INSERT INTO deposits (user_id, amount, utr_number, receipt_image, status) VALUES (?,?,?,?,'pending')")->execute([$user['id'],$amount,$utr,$receiptPath]);
sendNotification($user['id'],'Deposit Submitted','Your deposit of ₹'.$amount.' has been submitted and is under review.','info');
jsonResponse(['success'=>true,'message'=>'Deposit submitted successfully!']);

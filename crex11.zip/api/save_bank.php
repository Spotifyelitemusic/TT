<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$db->prepare("UPDATE users SET upi_id=?,account_holder=?,bank_account=?,bank_ifsc=?,bank_name=? WHERE id=?")
   ->execute([sanitize($_POST['upi_id']??''),sanitize($_POST['account_holder']??''),sanitize($_POST['bank_account']??''),sanitize($_POST['bank_ifsc']??''),sanitize($_POST['bank_name']??''),$user['id']]);
jsonResponse(['success'=>true,'message'=>'Bank details saved!']);

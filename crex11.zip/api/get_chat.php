<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$stmt = $db->prepare("SELECT * FROM chat_messages WHERE user_id = ? ORDER BY created_at ASC LIMIT 100");
$stmt->execute([$user['id']]);
$msgs = $stmt->fetchAll();
$db->prepare("UPDATE chat_messages SET is_read = 1 WHERE user_id = ? AND sender = 'admin'")->execute([$user['id']]);
jsonResponse(['success'=>true,'messages'=>$msgs]);

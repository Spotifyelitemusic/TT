<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
jsonResponse(['success'=>true,'upi_id'=>getSetting('upi_id'),'upi_name'=>getSetting('upi_name'),'qr_image'=>getSetting('qr_image')]);

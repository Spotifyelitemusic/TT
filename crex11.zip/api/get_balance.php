<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$bal = getUserBalance($user['id']);
jsonResponse(['success'=>true,'cash'=>$bal['cash_balance'],'bonus'=>$bal['bonus_balance'],'winning'=>$bal['winning_balance']]);

<?php
require_once __DIR__ . '/../includes/auth.php';
$type = $_GET['type'] ?? 'terms';
$keys = ['terms'=>'terms_content','privacy'=>'privacy_content','help'=>'about_content'];
$key = $keys[$type] ?? 'terms_content';
jsonResponse(['success'=>true,'content'=>getSetting($key,'Content not available.')]);

<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$tId = (int)($_GET['tournament_id'] ?? 0);
$stmt = $db->prepare("SELECT id FROM tournament_registrations WHERE tournament_id = ? AND user_id = ?");
$stmt->execute([$tId,$user['id']]);
if (!$stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'You are not registered for this tournament']); }
$stmt = $db->prepare("SELECT room_id, room_password FROM tournaments WHERE id = ?");
$stmt->execute([$tId]);
$tourn = $stmt->fetch();
if (!$tourn || !$tourn['room_id']) { jsonResponse(['success'=>false,'message'=>'Room ID not set yet. Check back closer to match time.']); }
jsonResponse(['success'=>true,'room_id'=>$tourn['room_id'],'room_password'=>$tourn['room_password']]);

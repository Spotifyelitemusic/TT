<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$input = json_decode(file_get_contents('php://input'), true);
$method = sanitize($input['method'] ?? '');
$amount = (float)($input['amount'] ?? 0);
$minW = getSetting('min_withdrawal', 100);
if ($amount < $minW) { jsonResponse(['success'=>false,'message'=>"Minimum withdrawal is ₹$minW"]); }
$bal = getUserBalance($user['id']);
if ($bal['winning_balance'] < $amount) { jsonResponse(['success'=>false,'message'=>'Insufficient winning balance']); }
$db = getDB();
$data = [$user['id'],$amount,$method];
if ($method === 'upi') {
    $upi = sanitize($input['upi_id'] ?? '');
    if (!$upi) { jsonResponse(['success'=>false,'message'=>'Enter UPI ID']); }
    $db->prepare("INSERT INTO withdrawals (user_id,amount,method,upi_id) VALUES (?,?,?,?)")->execute(array_merge($data,[$upi]));
} else {
    $db->prepare("INSERT INTO withdrawals (user_id,amount,method,account_holder,account_number,ifsc_code,bank_name) VALUES (?,?,?,?,?,?,?)")
       ->execute([$user['id'],$amount,$method,$input['account_holder']??'',$input['account_number']??'',$input['ifsc_code']??'',$input['bank_name']??'']);
}
deductBalance($user['id'],$amount,'winning');
$db->prepare("INSERT INTO transactions (user_id,type,amount,balance_type,status,note) VALUES (?,?,?,?,?,?)")
   ->execute([$user['id'],'withdrawal',$amount,'winning','pending','Withdrawal request']);
sendNotification($user['id'],'Withdrawal Submitted','Your withdrawal of ₹'.$amount.' has been submitted. Balance deducted. Will be processed after approval.','warning');
jsonResponse(['success'=>true,'message'=>'Withdrawal submitted!']);

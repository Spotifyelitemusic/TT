<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$docType = sanitize($_POST['doc_type'] ?? 'aadhar');
$front = $back = $selfie = '';
if (!empty($_FILES['doc_front']['tmp_name'])) { $u = uploadFile($_FILES['doc_front'],'kyc'); if($u['success']) $front=$u['path']; }
if (!empty($_FILES['doc_back']['tmp_name'])) { $u = uploadFile($_FILES['doc_back'],'kyc'); if($u['success']) $back=$u['path']; }
if (!empty($_FILES['selfie']['tmp_name'])) { $u = uploadFile($_FILES['selfie'],'kyc'); if($u['success']) $selfie=$u['path']; }
if (!$front) { jsonResponse(['success'=>false,'message'=>'Front document required']); }
$db = getDB();
$db->prepare("INSERT INTO kyc_verifications (user_id,doc_type,doc_front,doc_back,selfie,status) VALUES (?,?,?,?,?,'submitted') ON DUPLICATE KEY UPDATE doc_type=?,doc_front=?,doc_back=?,selfie=?,status='submitted',submitted_at=NOW()")
   ->execute([$user['id'],$docType,$front,$back,$selfie,$docType,$front,$back,$selfie]);
$db->prepare("UPDATE users SET kyc_status='submitted' WHERE id=?")->execute([$user['id']]);
sendNotification($user['id'],'KYC Submitted','Your KYC documents have been submitted for review.','info');
jsonResponse(['success'=>true,'message'=>'KYC submitted successfully!']);

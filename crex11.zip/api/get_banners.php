<?php
require_once __DIR__ . '/../includes/auth.php';
$db = getDB();
$stmt = $db->prepare("SELECT * FROM promotions WHERE is_active = 1 ORDER BY sort_order ASC");
$stmt->execute();
jsonResponse(['success'=>true,'banners'=>$stmt->fetchAll()]);

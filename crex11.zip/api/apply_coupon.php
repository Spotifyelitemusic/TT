<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$input = json_decode(file_get_contents('php://input'), true);
$code = strtoupper(sanitize($input['code'] ?? ''));
if (!$code) { jsonResponse(['success'=>false,'message'=>'Invalid code']); }
$db = getDB();
$stmt = $db->prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1 AND expires_at > NOW() AND used_count < max_uses");
$stmt->execute([$code]);
$coupon = $stmt->fetch();
if (!$coupon) { jsonResponse(['success'=>false,'message'=>'Invalid or expired coupon']); }
$stmt = $db->prepare("SELECT id FROM coupon_uses WHERE coupon_id = ? AND user_id = ?");
$stmt->execute([$coupon['id'],$user['id']]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'Coupon already used']); }
$db->prepare("INSERT INTO coupon_uses (coupon_id,user_id) VALUES (?,?)")->execute([$coupon['id'],$user['id']]);
$db->prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?")->execute([$coupon['id']]);
addBalance($user['id'],$coupon['amount'],$coupon['balance_type'],'coupon',"Coupon: $code",$code);
sendNotification($user['id'],'Coupon Applied!','₹'.$coupon['amount'].' added to your '.$coupon['balance_type'].' balance.','success');
jsonResponse(['success'=>true,'amount'=>$coupon['amount'],'balance_type'=>$coupon['balance_type']]);

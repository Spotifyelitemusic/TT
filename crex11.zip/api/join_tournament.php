<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }

$input = json_decode(file_get_contents('php://input'), true);
$tournId = (int)($input['tournament_id'] ?? 0);
$slotNum = (int)($input['slot_number'] ?? 0);

if (!$tournId || !$slotNum) { jsonResponse(['success'=>false,'message'=>'Missing data']); }

$db = getDB();

// Get tournament
$stmt = $db->prepare("SELECT * FROM tournaments WHERE id = ? AND status = 'upcoming'");
$stmt->execute([$tournId]);
$tourn = $stmt->fetch();
if (!$tourn) { jsonResponse(['success'=>false,'message'=>'Tournament not available']); }

// Check if already registered
$stmt = $db->prepare("SELECT id FROM tournament_registrations WHERE tournament_id = ? AND user_id = ?");
$stmt->execute([$tournId, $user['id']]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'Already registered for this tournament']); }

// Check slot availability
$stmt = $db->prepare("SELECT id FROM tournament_registrations WHERE tournament_id = ? AND slot_number = ?");
$stmt->execute([$tournId, $slotNum]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'Slot already taken']); }

// Check slots available
if ($tourn['filled_slots'] >= $tourn['max_slots']) { jsonResponse(['success'=>false,'message'=>'Tournament is full']); }

// Check balance
$fee = $tourn['entry_fee'];
if ($fee > 0) {
    $bal = getUserBalance($user['id']);
    $total = $bal['cash_balance'] + $bal['bonus_balance'];
    if ($total < $fee) { jsonResponse(['success'=>false,'message'=>'Insufficient balance. Please add money.']); }
    
    // Deduct from cash first, then bonus
    if ($bal['cash_balance'] >= $fee) {
        deductBalance($user['id'], $fee, 'cash');
    } else {
        $cashUsed = $bal['cash_balance'];
        $bonusUsed = $fee - $cashUsed;
        if ($cashUsed > 0) deductBalance($user['id'], $cashUsed, 'cash');
        deductBalance($user['id'], $bonusUsed, 'bonus');
    }
    
    // Record transaction
    $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_type, status, note) VALUES (?,?,?,?,?,?)")
       ->execute([$user['id'], 'bet', $fee, 'cash', 'completed', "Joined tournament: {$tourn['title']}"]);
}

// Register
$db->prepare("INSERT INTO tournament_registrations (tournament_id, user_id, slot_number) VALUES (?,?,?)")
   ->execute([$tournId, $user['id'], $slotNum]);

// Update filled slots
$db->prepare("UPDATE tournaments SET filled_slots = filled_slots + 1 WHERE id = ?")->execute([$tournId]);

// Update user total bets
$db->prepare("UPDATE users SET total_bets = total_bets + 1 WHERE id = ?")->execute([$user['id']]);

$bal = getUserBalance($user['id']);
$newBalance = $bal['cash_balance'] + $bal['bonus_balance'] + $bal['winning_balance'];

sendNotification($user['id'], 'Tournament Joined!', "You've joined \"{$tourn['title']}\" at slot #{$slotNum}. Good luck!", 'success');

jsonResponse(['success'=>true,'message'=>'Successfully joined!','new_balance'=>$newBalance]);

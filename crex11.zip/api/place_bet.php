<?php
// API: Place Bet
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }

$input = json_decode(file_get_contents('php://input'), true);
$matchId = (int)($input['match_id'] ?? 0);
$pick = sanitize($input['pick'] ?? '');
$amount = (float)($input['amount'] ?? 0);

if (!$matchId || !$pick || $amount < 10) { jsonResponse(['success'=>false,'message'=>'Invalid bet data']); }

$db = getDB();

// Get match
$stmt = $db->prepare("SELECT * FROM matches WHERE id = ? AND status IN ('upcoming','live')");
$stmt->execute([$matchId]);
$match = $stmt->fetch();
if (!$match) { jsonResponse(['success'=>false,'message'=>'Match not available for betting']); }

// Check if already bet
$stmt = $db->prepare("SELECT id FROM bets WHERE user_id = ? AND match_id = ?");
$stmt->execute([$user['id'], $matchId]);
if ($stmt->fetch()) { jsonResponse(['success'=>false,'message'=>'Already placed a bet on this match']); }

// Determine odds
$odds = ($pick === $match['team1']) ? $match['odds_team1'] : (($pick === $match['team2']) ? $match['odds_team2'] : 0);
if (!$odds) { jsonResponse(['success'=>false,'message'=>'Invalid pick']); }

// Check balance
$bal = getUserBalance($user['id']);
$totalBal = $bal['cash_balance'] + $bal['bonus_balance'];
if ($totalBal < $amount) { jsonResponse(['success'=>false,'message'=>'Insufficient balance']); }

// Deduct balance
if ($bal['cash_balance'] >= $amount) {
    deductBalance($user['id'], $amount, 'cash');
} else {
    $c = $bal['cash_balance'];
    $b = $amount - $c;
    if ($c > 0) deductBalance($user['id'], $c, 'cash');
    deductBalance($user['id'], $b, 'bonus');
}

$potentialWin = round($amount * $odds, 2);

$db->prepare("INSERT INTO bets (user_id, match_id, pick, amount, potential_win) VALUES (?,?,?,?,?)")
   ->execute([$user['id'], $matchId, $pick, $amount, $potentialWin]);

$db->prepare("UPDATE users SET total_bets = total_bets + 1 WHERE id = ?")->execute([$user['id']]);
$db->prepare("INSERT INTO transactions (user_id, type, amount, balance_type, status, note) VALUES (?,?,?,?,?,?)")
   ->execute([$user['id'], 'bet', $amount, 'cash', 'completed', "Bet on {$match['team1']} vs {$match['team2']}"]);

$bal = getUserBalance($user['id']);
$newBalance = $bal['cash_balance'] + $bal['bonus_balance'] + $bal['winning_balance'];
jsonResponse(['success'=>true,'new_balance'=>$newBalance]);

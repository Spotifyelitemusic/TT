<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$stmt = $db->prepare("SELECT * FROM notifications WHERE (user_id = ? OR is_global = 1) ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
jsonResponse(['success'=>true,'notifications'=>$stmt->fetchAll()]);

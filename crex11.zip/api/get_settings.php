<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
jsonResponse(['success'=>true,'min_deposit'=>getSetting('min_deposit',100),'max_deposit'=>getSetting('max_deposit',100000),'min_withdrawal'=>getSetting('min_withdrawal',100),'referral_bonus'=>getSetting('referral_bonus',50),'referral_bonus_type'=>getSetting('referral_bonus_type','cash')]);

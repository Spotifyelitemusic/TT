<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }

$db = getDB();
$status = $_GET['status'] ?? 'upcoming';

$sql = "SELECT t.*, g.name as game_name,
    (SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.tournament_id = t.id AND tr.user_id = ?) as is_registered
    FROM tournaments t LEFT JOIN games g ON g.id = t.game_id";

$params = [$user['id']];
if ($status !== 'all') {
    $sql .= " WHERE t.status = ?";
    $params[] = $status;
}
$sql .= " ORDER BY t.start_time ASC LIMIT 50";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$tournaments = $stmt->fetchAll();

jsonResponse(['success'=>true,'tournaments'=>$tournaments]);

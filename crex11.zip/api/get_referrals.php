<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$bonusAmt = getSetting('referral_bonus', 50);
$stmt = $db->prepare("SELECT username, created_at FROM users WHERE referred_by = ? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$referrals = $stmt->fetchAll();
$referrals = array_map(fn($r) => array_merge($r, ['bonus'=>$bonusAmt]), $referrals);
jsonResponse(['success'=>true,'referrals'=>$referrals]);

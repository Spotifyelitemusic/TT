<?php
require_once __DIR__ . '/../includes/auth.php';
$user = getCurrentUser();
if (!$user) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }

$db = getDB();
$status = $_GET['status'] ?? 'all';

if ($status === 'all') {
    $stmt = $db->prepare("SELECT * FROM matches ORDER BY FIELD(status,'live','upcoming','completed'), start_time ASC");
    $stmt->execute();
} else {
    $stmt = $db->prepare("SELECT * FROM matches WHERE status = ? ORDER BY start_time ASC");
    $stmt->execute([$status]);
}
$matches = $stmt->fetchAll();
jsonResponse(['success'=>true,'matches'=>$matches]);

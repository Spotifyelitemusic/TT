# CREX 11 - Tournament Website

## Setup Instructions

### 1. Database Setup
- Open phpMyAdmin or MySQL CLI
- Run the SQL file: `config/install.sql`
- This creates database `crex11_db` with all tables

### 2. Configure Database
- Edit `config/database.php`
- Set DB_HOST, DB_USER, DB_PASS if needed

### 3. Upload to Server
- Upload all files to your web server's public folder (e.g., `public_html/crex11/`)
- Or root folder for direct access

### 4. Permissions
- chmod 755 `assets/uploads/` and all subdirectories
- chmod 755 all PHP files

### 5. Access
- **User Site:** `http://yourdomain.com/crex11/login.php`
- **Admin Panel:** `http://yourdomain.com/crex11/admin/login.php`

### 6. Default Admin Credentials
- Email: admin@crex11.com
- Password: admin123
- **CHANGE IMMEDIATELY after first login!**

### 7. Site Configuration (Admin Panel)
- Go to Admin > Site Settings
- Update: Site Name, Logo, UPI ID, QR Code
- Set referral bonus amount
- Add Google OAuth credentials (optional)

## Features
- User registration/login with Google OAuth
- Tournament management with slot booking
- Match betting system with odds
- Manual deposit (UPI/QR) verification
- UPI & Bank withdrawal system
- Referral system (auto credit on registration)
- Coupon management (single & bulk)
- KYC verification
- Support chat
- Push notifications
- Leaderboard
- Analytics dashboard
- Full admin control - nothing hardcoded

## Tech Stack
- PHP 7.4+ (Backend)
- MySQL (Database)  
- Bootstrap 5.3 (UI)
- Swiper.js (Banners)
- Chart.js (Analytics)

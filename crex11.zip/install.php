<?php
// Quick install/check script
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
    require_once 'config/database.php';
    try {
        $pdo = new PDO("mysql:host=".DB_HOST.";charset=utf8mb4", DB_USER, DB_PASS);
        $sql = file_get_contents('config/install.sql');
        $pdo->exec($sql);
        echo '<p style="color:green">Database installed successfully! <a href="login.php">Go to site</a></p>';
    } catch(PDOException $e) {
        echo '<p style="color:red">Error: ' . $e->getMessage() . '</p>';
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Install CREX 11</title><style>body{font-family:sans-serif;background:#000;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;}.box{background:#1a1a1a;padding:30px;border-radius:12px;max-width:500px;}input{display:block;width:100%;padding:8px;margin:8px 0 16px;background:#000;border:1px solid #333;color:#fff;border-radius:6px;}button{background:#1DB954;color:#000;border:none;padding:10px 20px;font-weight:700;border-radius:8px;cursor:pointer;}</style></head>
<body><div class="box">
<h2>CREX 11 Install</h2>
<p>This will create the database and tables. Edit <code>config/database.php</code> with your DB credentials first.</p>
<form method="POST">
    <button type="submit" name="install" value="1">Install Database</button>
</form>
<hr style="border-color:#333;margin:20px 0;">
<p style="color:#aaa;font-size:0.85rem;">After install, delete this file and login at <a href="login.php" style="color:#1DB954;">login.php</a></p>
</div></body>
</html>

<?php
require_once __DIR__ . '/../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
$db = getDB();
$stmt = $db->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();
if (!$admin) { session_destroy(); header('Location: login.php'); exit; }

$siteName = getSetting('site_name', 'CREX 11');
$siteLogo = getSetting('site_logo');

// Dashboard stats
$stats = [];
$stats['total_users'] = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$stats['total_deposits'] = $db->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='approved'")->fetchColumn();
$stats['pending_deposits'] = $db->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn();
$stats['pending_withdrawals'] = $db->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
$stats['total_tournaments'] = $db->query("SELECT COUNT(*) FROM tournaments")->fetchColumn();
$stats['active_matches'] = $db->query("SELECT COUNT(*) FROM matches WHERE status IN ('live','upcoming')")->fetchColumn();
$stats['total_bets'] = $db->query("SELECT COUNT(*) FROM bets")->fetchColumn();
$stats['pending_kyc'] = $db->query("SELECT COUNT(*) FROM kyc_verifications WHERE status='submitted'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?= htmlspecialchars($siteName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<div id="adminLoader" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:9999;justify-content:center;align-items:center;">
    <div class="spinner-border" style="color:#1DB954;width:3rem;height:3rem;"></div>
</div>

<div id="alertBox" class="custom-alert"></div>

<!-- Header -->
<header class="app-header">
    <div class="header-left">
        <button class="menu-toggle-btn" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar">
            <i class="bi bi-list"></i>
        </button>
        <?php if ($siteLogo): ?>
            <img src="../<?= htmlspecialchars($siteLogo) ?>" class="header-logo" alt="Logo">
        <?php endif; ?>
        <h1 class="header-title ms-1" id="adminPageTitle">Dashboard</h1>
    </div>
    <div class="header-right">
        <span style="font-size:0.82rem;color:#aaa;display:none;" id="adminEmail" class="d-sm-inline"><?= htmlspecialchars($admin['email']) ?></span>
        <a href="logout.php" class="btn btn-sm btn-outline-danger"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</header>

<!-- Sidebar -->
<div class="offcanvas offcanvas-start" id="adminSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title"><?= htmlspecialchars($siteName) ?> Admin</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <ul class="nav flex-column">
            <li><a class="nav-link active" href="#" data-section="dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li><a class="nav-link" href="#" data-section="users"><i class="bi bi-people"></i> Users</a></li>
            <li><a class="nav-link" href="#" data-section="deposits"><i class="bi bi-arrow-down-circle"></i> Deposits <span class="badge bg-danger ms-1"><?= $stats['pending_deposits'] ?></span></a></li>
            <li><a class="nav-link" href="#" data-section="withdrawals"><i class="bi bi-arrow-up-circle"></i> Withdrawals <span class="badge bg-warning text-dark ms-1"><?= $stats['pending_withdrawals'] ?></span></a></li>
            <li><a class="nav-link" href="#" data-section="tournaments"><i class="bi bi-trophy"></i> Tournaments</a></li>
            <li><a class="nav-link" href="#" data-section="tourn-manage"><i class="bi bi-award-fill"></i> Match Results</a></li>
            <li><a class="nav-link" href="#" data-section="matches"><i class="bi bi-globe"></i> Matches</a></li>
            <li><a class="nav-link" href="#" data-section="games"><i class="bi bi-controller"></i> Games</a></li>
            <li><a class="nav-link" href="#" data-section="promotions"><i class="bi bi-images"></i> Banners</a></li>
            <li><a class="nav-link" href="#" data-section="coupons"><i class="bi bi-gift-fill"></i> Coupons</a></li>
            <li><a class="nav-link" href="#" data-section="kyc"><i class="bi bi-shield-check"></i> KYC Verification <span class="badge bg-info ms-1"><?= $stats['pending_kyc'] ?></span></a></li>
            <li><a class="nav-link" href="#" data-section="leaderboard"><i class="bi bi-bar-chart-line"></i> Leaderboard</a></li>
            <li><a class="nav-link" href="#" data-section="chat"><i class="bi bi-chat-dots-fill"></i> Support Chat</a></li>
            <li><a class="nav-link" href="#" data-section="notifications"><i class="bi bi-bell"></i> Notifications</a></li>
            <li><a class="nav-link" href="#" data-section="analytics"><i class="bi bi-graph-up"></i> Analytics</a></li>
            <li><a class="nav-link" href="#" data-section="settings"><i class="bi bi-gear-fill"></i> Site Settings</a></li>
        </ul>
    </div>
</div>

<div class="main-content">

<!-- DASHBOARD -->
<section id="sec-dashboard" class="section active">
    <h2 class="section-title">Dashboard</h2>
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="stat-card" onclick="loadSection('users')">
            <div class="stat-icon" style="background:rgba(29,185,84,0.15);color:#1DB954"><i class="bi bi-people-fill"></i></div>
            <div class="stat-value"><?= number_format($stats['total_users']) ?></div>
            <div class="stat-label">Total Users</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card" onclick="loadSection('deposits')">
            <div class="stat-icon" style="background:rgba(59,130,246,0.15);color:#3B82F6"><i class="bi bi-arrow-down-circle-fill"></i></div>
            <div class="stat-value">₹<?= number_format($stats['total_deposits']) ?></div>
            <div class="stat-label">Total Deposits</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card pending-action" onclick="loadSection('deposits')">
            <div class="stat-icon" style="background:rgba(239,68,68,0.15);color:#EF4444"><i class="bi bi-clock-fill"></i></div>
            <div class="stat-value"><?= $stats['pending_deposits'] ?></div>
            <div class="stat-label">Pending Deposits</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card pending-action" onclick="loadSection('withdrawals')">
            <div class="stat-icon" style="background:rgba(245,158,11,0.15);color:#F59E0B"><i class="bi bi-clock-fill"></i></div>
            <div class="stat-value"><?= $stats['pending_withdrawals'] ?></div>
            <div class="stat-label">Pending Withdrawals</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card" onclick="loadSection('tournaments')">
            <div class="stat-icon" style="background:rgba(250,204,21,0.15);color:#FACC15"><i class="bi bi-trophy-fill"></i></div>
            <div class="stat-value"><?= $stats['total_tournaments'] ?></div>
            <div class="stat-label">Tournaments</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card">
            <div class="stat-icon" style="background:rgba(168,85,247,0.15);color:#A855F7"><i class="bi bi-broadcast"></i></div>
            <div class="stat-value"><?= $stats['active_matches'] ?></div>
            <div class="stat-label">Active Matches</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card">
            <div class="stat-icon" style="background:rgba(20,184,166,0.15);color:#14B8A6"><i class="bi bi-clipboard-check"></i></div>
            <div class="stat-value"><?= number_format($stats['total_bets']) ?></div>
            <div class="stat-label">Total Bets</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="stat-card pending-action" onclick="loadSection('kyc')">
            <div class="stat-icon" style="background:rgba(99,102,241,0.15);color:#6366F1"><i class="bi bi-shield-exclamation"></i></div>
            <div class="stat-value"><?= $stats['pending_kyc'] ?></div>
            <div class="stat-label">KYC Pending</div>
        </div></div>
    </div>
    <div class="row g-3">
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title mb-3"><i class="bi bi-clock-history me-2"></i>Recent Deposits</h6>
                <div id="recentDeposits"></div>
            </div></div>
        </div>
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title mb-3"><i class="bi bi-people me-2"></i>Recent Users</h6>
                <div id="recentUsers"></div>
            </div></div>
        </div>
    </div>
</section>

<!-- USERS -->
<section id="sec-users" class="section">
    <div class="section-header">
        <h2>Users Management</h2>
        <div class="d-flex gap-2">
            <input type="text" class="form-control form-control-sm" id="userSearch" placeholder="Search user..." style="width:200px;">
            <button class="btn btn-sm btn-success" onclick="exportUsers()"><i class="bi bi-download"></i> Export</button>
        </div>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>User</th><th>Email</th><th>Balance</th><th>KYC</th><th>Joined</th><th>Actions</th></tr></thead>
                    <tbody id="usersTable"></tbody>
                </table>
            </div>
            <div class="d-flex justify-content-between align-items-center p-3">
                <small class="text-muted" id="usersCount"></small>
                <div id="usersPagination"></div>
            </div>
        </div>
    </div>
</section>

<!-- DEPOSITS -->
<section id="sec-deposits" class="section">
    <div class="section-header">
        <h2>Deposit Requests</h2>
        <div class="d-flex gap-2">
            <select class="form-select form-select-sm" id="depositFilter" onchange="loadDeposits()" style="width:150px;">
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="all">All</option>
            </select>
        </div>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>User</th><th>Amount</th><th>UTR</th><th>Receipt</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="depositsTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- WITHDRAWALS -->
<section id="sec-withdrawals" class="section">
    <div class="section-header">
        <h2>Withdrawal Requests</h2>
        <select class="form-select form-select-sm" id="withdrawFilter" onchange="loadWithdrawals()" style="width:150px;">
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="all">All</option>
        </select>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>User</th><th>Amount</th><th>Method</th><th>Details</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="withdrawalsTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- TOURNAMENTS -->
<section id="sec-tournaments" class="section">
    <div class="section-header">
        <h2>Tournaments</h2>
        <button class="btn btn-success btn-sm" onclick="openTournamentModal()"><i class="bi bi-plus-circle"></i> Add Tournament</button>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>Banner</th><th>Title</th><th>Game</th><th>Fee</th><th>Prize</th><th>Start</th><th>Slots</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="tournamentsTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- TOURNAMENT MANAGEMENT (Results) -->
<section id="sec-tourn-manage" class="section">
    <h2 class="section-title">Tournament Results & Prize Distribution</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h6>Select Tournament</h6>
                    <select class="form-select" id="tmTournSelect" onchange="loadTournamentParticipants()">
                        <option value="">-- Select Tournament --</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <h6>Participants & Prize</h6>
                        <button class="btn btn-primary btn-sm" onclick="distributePrizes()"><i class="bi bi-trophy"></i> Distribute Prizes</button>
                    </div>
                    <div id="participantsList"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- MATCHES -->
<section id="sec-matches" class="section">
    <div class="section-header">
        <h2>Matches</h2>
        <button class="btn btn-success btn-sm" onclick="openMatchModal()"><i class="bi bi-plus-circle"></i> Add Match</button>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>Teams</th><th>Type</th><th>Start</th><th>Status</th><th>Odds</th><th>Bets</th><th>Actions</th></tr></thead>
                    <tbody id="matchesTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- GAMES -->
<section id="sec-games" class="section">
    <div class="section-header">
        <h2>Games</h2>
        <button class="btn btn-success btn-sm" onclick="openGameModal()"><i class="bi bi-plus-circle"></i> Add Game</button>
    </div>
    <div class="row" id="gamesGrid"></div>
</section>

<!-- BANNERS/PROMOTIONS -->
<section id="sec-promotions" class="section">
    <div class="section-header">
        <h2>Banners & Promotions</h2>
        <button class="btn btn-success btn-sm" onclick="openBannerModal()"><i class="bi bi-plus-circle"></i> Add Banner</button>
    </div>
    <div class="row" id="bannersGrid"></div>
</section>

<!-- COUPONS -->
<section id="sec-coupons" class="section">
    <div class="section-header"><h2>Coupons</h2></div>
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-gift-fill me-2"></i>Create Coupon</h6>
                <form id="createCouponForm" onsubmit="createCoupon(event)">
                    <div class="mb-2"><label class="form-label">Amount (₹)</label><input type="number" class="form-control" name="amount" min="1" required></div>
                    <div class="mb-2"><label class="form-label">Balance Type</label>
                        <select class="form-select" name="balance_type">
                            <option value="cash">Cash Balance</option>
                            <option value="bonus">Bonus Balance</option>
                            <option value="winning">Winning Balance</option>
                        </select>
                    </div>
                    <div class="mb-2"><label class="form-label">Max Uses</label><input type="number" class="form-control" name="max_uses" value="1" min="1" required></div>
                    <div class="mb-2"><label class="form-label">Expiry</label><input type="datetime-local" class="form-control" name="expires_at" required></div>
                    <div class="mb-2"><label class="form-label">Count (1 = single, N = bulk)</label><input type="number" class="form-control" name="count" value="1" min="1" max="1000"></div>
                    <div id="couponStatus" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-lightning-fill"></i> Generate</button>
                </form>
            </div></div>
        </div>
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title">Active Coupons <button class="btn btn-sm btn-outline-secondary float-end" onclick="loadCoupons()"><i class="bi bi-arrow-clockwise"></i></button></h6>
                <div id="couponsList"></div>
            </div></div>
        </div>
    </div>
</section>

<!-- KYC -->
<section id="sec-kyc" class="section">
    <div class="section-header">
        <h2>KYC Verifications</h2>
        <select class="form-select form-select-sm" id="kycFilter" onchange="loadKYC()" style="width:140px;">
            <option value="submitted">Pending</option>
            <option value="verified">Verified</option>
            <option value="rejected">Rejected</option>
        </select>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>User</th><th>Doc Type</th><th>Documents</th><th>Submitted</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="kycTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- LEADERBOARD -->
<section id="sec-leaderboard" class="section">
    <div class="section-header">
        <h2>Leaderboard Management</h2>
        <button class="btn btn-success btn-sm" onclick="openLeaderboardModal()"><i class="bi bi-plus-circle"></i> Add Entry</button>
    </div>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead><tr><th>Rank</th><th>User</th><th>Points</th><th>Period</th><th>Actions</th></tr></thead>
                    <tbody id="leaderboardTable"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- CHAT -->
<section id="sec-chat" class="section">
    <div class="section-header"><h2>Support Chat</h2></div>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body p-0">
                    <div class="p-3 border-bottom" style="border-color:#333 !important;"><input type="text" class="form-control form-control-sm" id="chatUserSearch" placeholder="Search users..." oninput="filterChatUsers()"></div>
                    <div id="chatUsersList" style="height:500px;overflow-y:auto;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card" style="height:580px;display:flex;flex-direction:column;">
                <div class="card-header" id="activeChatHeader">Select a user to chat</div>
                <div class="card-body p-3" id="chatMessages" style="flex:1;overflow-y:auto;"></div>
                <div class="card-footer" id="chatInputArea" style="display:none;">
                    <div class="d-flex gap-2">
                        <input type="text" class="form-control" id="adminChatInput" placeholder="Type message...">
                        <button class="btn btn-primary" onclick="sendAdminMessage()"><i class="bi bi-send-fill"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- NOTIFICATIONS -->
<section id="sec-notifications" class="section">
    <div class="section-header"><h2>Send Notifications</h2></div>
    <div class="row g-3">
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6>Send to Specific User</h6>
                <form onsubmit="sendNotification(event,'user')">
                    <div class="mb-2"><label class="form-label">User ID or Email</label><input type="text" class="form-control" name="target" placeholder="User ID or email" required></div>
                    <div class="mb-2"><label class="form-label">Title</label><input type="text" class="form-control" name="title" required></div>
                    <div class="mb-2"><label class="form-label">Message</label><textarea class="form-control" name="message" required></textarea></div>
                    <div class="mb-2"><label class="form-label">Type</label>
                        <select class="form-select" name="type"><option value="info">Info</option><option value="success">Success</option><option value="warning">Warning</option><option value="error">Error</option></select>
                    </div>
                    <div id="notifStatus1" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-send"></i> Send</button>
                </form>
            </div></div>
        </div>
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6>Broadcast to All Users</h6>
                <form onsubmit="sendNotification(event,'all')">
                    <div class="mb-2"><label class="form-label">Title</label><input type="text" class="form-control" name="title" required></div>
                    <div class="mb-2"><label class="form-label">Message</label><textarea class="form-control" name="message" required></textarea></div>
                    <div class="mb-2"><label class="form-label">Type</label>
                        <select class="form-select" name="type"><option value="info">Info</option><option value="success">Success</option><option value="warning">Warning</option><option value="error">Error</option></select>
                    </div>
                    <div id="notifStatus2" class="mb-2"></div>
                    <button type="submit" class="btn btn-warning w-100"><i class="bi bi-megaphone"></i> Broadcast</button>
                </form>
            </div></div>
        </div>
    </div>
</section>

<!-- ANALYTICS -->
<section id="sec-analytics" class="section">
    <h2 class="section-title">Analytics</h2>
    <div class="row g-3">
        <div class="col-md-6"><div class="card"><div class="card-body"><canvas id="userGrowthChart" height="200"></canvas></div></div></div>
        <div class="col-md-6"><div class="card"><div class="card-body"><canvas id="depositChart" height="200"></canvas></div></div></div>
        <div class="col-md-6"><div class="card"><div class="card-body"><canvas id="betStatsChart" height="200"></canvas></div></div></div>
        <div class="col-md-6"><div class="card"><div class="card-body">
            <h6>Top Users by Balance</h6>
            <div id="topUsersTable"></div>
        </div></div></div>
    </div>
</section>

<!-- SETTINGS -->
<section id="sec-settings" class="section">
    <h2 class="section-title">Site Settings</h2>
    <div class="row g-3">
        <!-- General -->
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-globe me-2"></i>General Settings</h6>
                <form onsubmit="saveSettings(event,'general')">
                    <div class="mb-2"><label class="form-label">Site Name</label><input type="text" class="form-control" name="site_name" value="<?= htmlspecialchars(getSetting('site_name')) ?>"></div>
                    <div class="mb-2"><label class="form-label">Tagline</label><input type="text" class="form-control" name="site_tagline" value="<?= htmlspecialchars(getSetting('site_tagline')) ?>"></div>
                    <div class="mb-2"><label class="form-label">Site Logo</label>
                        <div class="d-flex align-items-center gap-2">
                            <?php if(getSetting('site_logo')): ?><img src="../<?= getSetting('site_logo') ?>" style="height:40px;border-radius:50%;"><?php endif; ?>
                            <input type="file" class="form-control" name="site_logo" accept="image/*">
                        </div>
                    </div>
                    <div class="mb-2"><label class="form-label">Maintenance Mode</label>
                        <select class="form-select" name="maintenance_mode">
                            <option value="0" <?= getSetting('maintenance_mode')=='0'?'selected':'' ?>>Off</option>
                            <option value="1" <?= getSetting('maintenance_mode')=='1'?'selected':'' ?>>On</option>
                        </select>
                    </div>
                    <div id="settingsStatus1" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Save</button>
                </form>
            </div></div>
        </div>
        <!-- Payment -->
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-credit-card me-2"></i>Payment Settings</h6>
                <form onsubmit="saveSettings(event,'payment')">
                    <div class="mb-2"><label class="form-label">UPI ID</label><input type="text" class="form-control" name="upi_id" value="<?= htmlspecialchars(getSetting('upi_id')) ?>"></div>
                    <div class="mb-2"><label class="form-label">UPI Name</label><input type="text" class="form-control" name="upi_name" value="<?= htmlspecialchars(getSetting('upi_name')) ?>"></div>
                    <div class="mb-2"><label class="form-label">QR Code Image</label>
                        <div class="d-flex align-items-center gap-2">
                            <?php if(getSetting('qr_image')): ?><img src="../<?= getSetting('qr_image') ?>" style="height:60px;border-radius:8px;"><?php endif; ?>
                            <input type="file" class="form-control" name="qr_image" accept="image/*">
                        </div>
                    </div>
                    <div class="row"><div class="col">
                        <label class="form-label">Min Deposit (₹)</label>
                        <input type="number" class="form-control" name="min_deposit" value="<?= getSetting('min_deposit',100) ?>">
                    </div><div class="col">
                        <label class="form-label">Max Deposit (₹)</label>
                        <input type="number" class="form-control" name="max_deposit" value="<?= getSetting('max_deposit',100000) ?>">
                    </div></div>
                    <div class="row mt-2"><div class="col">
                        <label class="form-label">Min Withdrawal (₹)</label>
                        <input type="number" class="form-control" name="min_withdrawal" value="<?= getSetting('min_withdrawal',100) ?>">
                    </div><div class="col">
                        <label class="form-label">Max Withdrawal (₹)</label>
                        <input type="number" class="form-control" name="max_withdrawal" value="<?= getSetting('max_withdrawal',50000) ?>">
                    </div></div>
                    <div id="settingsStatus2" class="mb-2 mt-2"></div>
                    <button type="submit" class="btn btn-primary mt-1"><i class="bi bi-save"></i> Save</button>
                </form>
            </div></div>
        </div>
        <!-- Referral -->
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-people-fill me-2"></i>Referral Settings</h6>
                <form onsubmit="saveSettings(event,'referral')">
                    <div class="mb-2"><label class="form-label">Referral Bonus Amount (₹)</label><input type="number" class="form-control" name="referral_bonus" value="<?= getSetting('referral_bonus',50) ?>"></div>
                    <div class="mb-2"><label class="form-label">Bonus Type</label>
                        <select class="form-select" name="referral_bonus_type">
                            <option value="cash" <?= getSetting('referral_bonus_type')=='cash'?'selected':'' ?>>Cash Balance</option>
                            <option value="bonus" <?= getSetting('referral_bonus_type')=='bonus'?'selected':'' ?>>Bonus Balance</option>
                            <option value="winning" <?= getSetting('referral_bonus_type')=='winning'?'selected':'' ?>>Winning Balance</option>
                        </select>
                    </div>
                    <div id="settingsStatus3" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Save</button>
                </form>
            </div></div>
        </div>
        <!-- Google -->
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-google me-2"></i>Google OAuth Settings</h6>
                <form onsubmit="saveSettings(event,'google')">
                    <div class="mb-2"><label class="form-label">Google Client ID</label><input type="text" class="form-control" name="google_client_id" value="<?= htmlspecialchars(getSetting('google_client_id')) ?>" placeholder="xxx.apps.googleusercontent.com"></div>
                    <div class="mb-2"><label class="form-label">Google Client Secret</label><input type="password" class="form-control" name="google_client_secret" value="<?= htmlspecialchars(getSetting('google_client_secret')) ?>"></div>
                    <div id="settingsStatus4" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Save</button>
                </form>
            </div></div>
        </div>
        <!-- Content -->
        <div class="col-12">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-file-text me-2"></i>Content Management</h6>
                <ul class="nav nav-tabs mb-3" id="contentTabs">
                    <li class="nav-item"><a class="nav-link active" href="#" onclick="switchContentTab('terms',this)">Terms</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="switchContentTab('privacy',this)">Privacy</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="switchContentTab('about',this)">About/Help</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="switchContentTab('refund',this)">Refund Policy</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="switchContentTab('withdrawal',this)">Withdrawal Note</a></li>
                </ul>
                <textarea class="form-control" id="contentEditor" rows="10"></textarea>
                <input type="hidden" id="activeContentKey">
                <div id="settingsStatus5" class="mt-2"></div>
                <button class="btn btn-primary mt-2" onclick="saveContent()"><i class="bi bi-save"></i> Save Content</button>
            </div></div>
        </div>
        <!-- Admin Password -->
        <div class="col-md-6">
            <div class="card"><div class="card-body">
                <h6 class="card-title"><i class="bi bi-lock me-2"></i>Change Admin Password</h6>
                <form onsubmit="changeAdminPassword(event)">
                    <div class="mb-2"><label class="form-label">Current Password</label><input type="password" class="form-control" name="current_password" required></div>
                    <div class="mb-2"><label class="form-label">New Password</label><input type="password" class="form-control" name="new_password" required minlength="6"></div>
                    <div id="pwdStatus" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </form>
            </div></div>
        </div>
    </div>
</section>

</div><!-- /main-content -->

<!-- MODALS -->
<!-- User Edit Modal -->
<div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">User Details</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="userModalBody"></div>
        </div>
    </div>
</div>

<!-- Tournament Modal -->
<div class="modal fade" id="tournamentModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="tournModalTitle">Add Tournament</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="tournamentForm" onsubmit="saveTournament(event)">
                    <input type="hidden" name="id" id="tournId">
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Title *</label><input type="text" class="form-control" name="title" required></div>
                        <div class="col-md-6"><label class="form-label">Game *</label>
                            <select class="form-select" name="game_id" id="tournGameSelect" required></select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Tournament Type</label>
                            <select class="form-select" name="tournament_type">
                                <option value="solo">Solo</option><option value="duo">Duo</option><option value="squad">Squad</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Entry Fee (₹)</label><input type="number" class="form-control" name="entry_fee" value="0" min="0"></div>
                        <div class="col-md-6"><label class="form-label">Prize Pool (₹)</label><input type="number" class="form-control" name="prize_pool" value="0" min="0"></div>
                        <div class="col-md-6"><label class="form-label">Max Slots</label><input type="number" class="form-control" name="max_slots" value="100" min="2"></div>
                        <div class="col-md-6"><label class="form-label">Per Kill Prize (₹)</label><input type="number" class="form-control" name="per_kill_prize" value="0" min="0"></div>
                        <div class="col-md-6"><label class="form-label">Start Time *</label><input type="datetime-local" class="form-control" name="start_time" required></div>
                        <div class="col-md-6"><label class="form-label">End Time</label><input type="datetime-local" class="form-control" name="end_time"></div>
                        <div class="col-md-6"><label class="form-label">Map</label><input type="text" class="form-control" name="map" placeholder="e.g. Erangel"></div>
                        <div class="col-md-6"><label class="form-label">Version</label><input type="text" class="form-control" name="version" placeholder="e.g. v2.1"></div>
                        <div class="col-md-6"><label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="upcoming">Upcoming</option><option value="live">Live</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Room ID</label><input type="text" class="form-control" name="room_id"></div>
                        <div class="col-md-6"><label class="form-label">Room Password</label><input type="text" class="form-control" name="room_password"></div>
                        <div class="col-12"><label class="form-label">Banner Image</label>
                            <div id="tournBannerPreview" class="mb-2"></div>
                            <input type="file" class="form-control" name="banner_image" accept="image/*">
                        </div>
                        <div class="col-12"><label class="form-label">Rules</label><textarea class="form-control" name="rules" rows="4"></textarea></div>
                        <div class="col-12"><label class="form-label">Prize Distribution</label><textarea class="form-control" name="prize_distribution" rows="4"></textarea></div>
                    </div>
                    <div id="tournStatus" class="mt-3"></div>
                    <div class="d-flex gap-2 mt-3">
                        <button type="submit" class="btn btn-primary flex-grow-1"><i class="bi bi-save"></i> Save</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Match Modal -->
<div class="modal fade" id="matchModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="matchModalTitle">Add Match</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="matchForm" onsubmit="saveMatch(event)">
                    <input type="hidden" name="id" id="matchId">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Team 1 Name *</label><input type="text" class="form-control" name="team1" required></div>
                        <div class="col-md-6"><label class="form-label">Team 2 Name *</label><input type="text" class="form-control" name="team2" required></div>
                        <div class="col-md-6"><label class="form-label">Team 1 Logo</label><input type="file" class="form-control" name="team1_logo" accept="image/*"></div>
                        <div class="col-md-6"><label class="form-label">Team 2 Logo</label><input type="file" class="form-control" name="team2_logo" accept="image/*"></div>
                        <div class="col-md-6"><label class="form-label">Match Type</label><input type="text" class="form-control" name="match_type" value="IPL T20"></div>
                        <div class="col-md-6"><label class="form-label">Start Time *</label><input type="datetime-local" class="form-control" name="start_time" required></div>
                        <div class="col-md-4"><label class="form-label">Team 1 Odds</label><input type="number" class="form-control" name="odds_team1" value="1.90" step="0.01"></div>
                        <div class="col-md-4"><label class="form-label">Team 2 Odds</label><input type="number" class="form-control" name="odds_team2" value="1.90" step="0.01"></div>
                        <div class="col-md-4"><label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="upcoming">Upcoming</option><option value="live">Live</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-12"><label class="form-label">Winner (if completed)</label><input type="text" class="form-control" name="winner" placeholder="Team name"></div>
                    </div>
                    <div id="matchStatus" class="mt-3"></div>
                    <div class="d-flex gap-2 mt-3">
                        <button type="submit" class="btn btn-primary flex-grow-1"><i class="bi bi-save"></i> Save</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Game Modal -->
<div class="modal fade" id="gameModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="gameModalTitle">Add Game</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="gameForm" onsubmit="saveGame(event)">
                    <input type="hidden" name="id" id="gameId">
                    <div class="mb-3"><label class="form-label">Game Name *</label><input type="text" class="form-control" name="name" required></div>
                    <div class="mb-3"><label class="form-label">Game Image</label>
                        <div id="gameImgPreview" class="mb-2"></div>
                        <input type="file" class="form-control" name="image" accept="image/*">
                    </div>
                    <div class="mb-3"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="3"></textarea></div>
                    <div class="mb-3"><label class="form-label">Status</label>
                        <select class="form-select" name="is_active"><option value="1">Active</option><option value="0">Inactive</option></select>
                    </div>
                    <div id="gameStatus" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Banner Modal -->
<div class="modal fade" id="bannerModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="bannerModalTitle">Add Banner</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="bannerForm" onsubmit="saveBanner(event)">
                    <input type="hidden" name="id" id="bannerId">
                    <div class="mb-3"><label class="form-label">Title (optional)</label><input type="text" class="form-control" name="title"></div>
                    <div class="mb-3"><label class="form-label">Banner Image *</label>
                        <div id="bannerImgPreview" class="mb-2"></div>
                        <input type="file" class="form-control" name="image" accept="image/*">
                    </div>
                    <div class="mb-3"><label class="form-label">Link URL (optional)</label><input type="text" class="form-control" name="link_url" placeholder="https://..."></div>
                    <div class="mb-3"><label class="form-label">Sort Order</label><input type="number" class="form-control" name="sort_order" value="0"></div>
                    <div class="mb-3"><label class="form-label">Status</label>
                        <select class="form-select" name="is_active"><option value="1">Active</option><option value="0">Inactive</option></select>
                    </div>
                    <div id="bannerStatus" class="mb-2"></div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Image Preview Modal -->
<div class="modal fade" id="imgPreviewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Image Preview</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body text-center"><img id="previewImg" style="max-width:100%;border-radius:8px;"></div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/admin.js"></script>
<script>
// Init charts on analytics
document.querySelectorAll('.nav-link[data-section]').forEach(link => {
    link.addEventListener('click', function(e){
        e.preventDefault();
        loadSection(this.dataset.section);
        document.querySelectorAll('.offcanvas').forEach(oc => bootstrap.Offcanvas.getInstance(oc)?.hide());
    });
});
loadDashboardData();
</script>
</body>
</html>

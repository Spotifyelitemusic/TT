<?php
require_once __DIR__ . '/../includes/auth.php';
session_start();

if (!empty($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
    if ($admin && verifyPassword($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_email'] = $admin['email'];
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    }
    exit;
}
$siteName = getSetting('site_name', 'CREX 11');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?= htmlspecialchars($siteName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body{background:#000;color:#fff;font-family:Poppins,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;}
        .login-card{background:#1A1A1A;border:1px solid #2a2a2a;border-radius:16px;padding:36px;width:100%;max-width:400px;}
        .form-control{background:#000;border:1px solid #333;color:#fff;border-radius:8px;}
        .form-control:focus{background:#000;color:#fff;border-color:#1DB954;box-shadow:0 0 0 0.2rem rgba(29,185,84,0.15);}
        .btn-primary{background:#1DB954;border:none;color:#000;font-weight:700;}
        .form-label{color:#aaa;font-size:0.82rem;}
        .logo{width:60px;height:60px;border-radius:50%;background:#1DB954;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:800;color:#000;margin:0 auto 15px;}
    </style>
</head>
<body>
<div class="login-card">
    <div class="logo"><i class="bi bi-shield-lock-fill"></i></div>
    <h3 class="text-center mb-1"><?= htmlspecialchars($siteName) ?></h3>
    <p class="text-center text-muted small mb-4">Admin Panel</p>
    <form id="loginForm" onsubmit="doLogin(event)">
        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
        <div class="mb-3"><label class="form-label">Password</label><input type="password" class="form-control" name="password" required></div>
        <div id="loginStatus" class="mb-3"></div>
        <button type="submit" class="btn btn-primary w-100">Login to Admin</button>
    </form>
</div>
<script>
async function doLogin(e){
    e.preventDefault();
    const fd=new FormData(e.target);
    const btn=e.target.querySelector('button[type=submit]');
    btn.textContent='Logging in...';btn.disabled=true;
    const res=await fetch('',{method:'POST',body:fd});
    const json=await res.json();
    btn.textContent='Login to Admin';btn.disabled=false;
    if(json.success){window.location.href='index.php';}
    else{document.getElementById('loginStatus').innerHTML=`<div style="color:#EF4444;font-size:0.85rem;">${json.message}</div>`;}
}
</script>
</body>
</html>

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$fields=['site_name','site_tagline','maintenance_mode','upi_id','upi_name','min_deposit','max_deposit','min_withdrawal','max_withdrawal','referral_bonus','referral_bonus_type','google_client_id','google_client_secret'];
foreach($fields as $f){if(isset($_POST[$f]))setSetting($f,sanitize($_POST[$f]));}
foreach(['site_logo','qr_image'] as $imgField){
    if(!empty($_FILES[$imgField]['tmp_name'])){
        $up=uploadFile($_FILES[$imgField],str_replace('_','/',$imgField));
        if($up['success'])setSetting($imgField,$up['path']);
    }
}
jsonResponse(['success'=>true,'message'=>'Settings saved!']);

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$id=(int)($_POST['id']??0);
$imgPath='';
if(!empty($_FILES['image']['tmp_name'])){$u=uploadFile($_FILES['image'],'games');if($u['success'])$imgPath=$u['path'];}
$name=sanitize($_POST['name']??'');$desc=sanitize($_POST['description']??'');$active=(int)($_POST['is_active']??1);
if(!$name){jsonResponse(['success'=>false,'message'=>'Name required']);}
if($id){
    $sql="UPDATE games SET name=?,description=?,is_active=?".($imgPath?",image=?":'')." WHERE id=?";
    $vals=[$name,$desc,$active];if($imgPath)$vals[]=$imgPath;$vals[]=$id;
    $db->prepare($sql)->execute($vals);
}else{
    $sql=$imgPath?"INSERT INTO games (name,description,is_active,image) VALUES (?,?,?,?)":"INSERT INTO games (name,description,is_active) VALUES (?,?,?)";
    $vals=[$name,$desc,$active];if($imgPath)$vals[]=$imgPath;
    $db->prepare($sql)->execute($vals);
}
jsonResponse(['success'=>true,'message'=>'Game saved!']);

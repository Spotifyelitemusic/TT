<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$userId = (int)($_POST['user_id'] ?? 0);
$action = sanitize($_POST['action'] ?? 'add');
$amount = (float)($_POST['amount'] ?? 0);
$balType = sanitize($_POST['balance_type'] ?? 'cash');
$note = sanitize($_POST['note'] ?? 'Admin adjustment');
if (!$userId || $amount <= 0) { jsonResponse(['success'=>false,'message'=>'Invalid data']); }
if ($action === 'add') {
    addBalance($userId, $amount, $balType, 'bonus', $note, 'admin');
    sendNotification($userId, 'Balance Added', "₹$amount {$balType} balance added by admin. Note: $note", 'success');
    jsonResponse(['success'=>true,'message'=>"₹$amount added to $userId's $balType balance"]);
} else {
    if (!deductBalance($userId, $amount, $balType)) { jsonResponse(['success'=>false,'message'=>'Insufficient balance']); }
    jsonResponse(['success'=>true,'message'=>"₹$amount deducted from $balType balance"]);
}

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$amount=(float)($_POST['amount']??0);$type=sanitize($_POST['balance_type']??'bonus');
$maxUses=(int)($_POST['max_uses']??1);$expiry=sanitize($_POST['expires_at']??'');
$count=min((int)($_POST['count']??1),1000);
if(!$amount||!$expiry){jsonResponse(['success'=>false,'message'=>'Fill all fields']);}
$codes=[];
for($i=0;$i<$count;$i++){
    $code=strtoupper(bin2hex(random_bytes(4)));
    try{
        $db->prepare("INSERT INTO coupons (code,amount,balance_type,max_uses,expires_at) VALUES (?,?,?,?,?)")->execute([$code,$amount,$type,$maxUses,$expiry]);
        $codes[]=$code;
    }catch(Exception $e){}
}
jsonResponse(['success'=>true,'count'=>count($codes),'codes'=>$codes]);

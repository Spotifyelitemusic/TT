<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
$tId = (int)($_GET['tournament_id'] ?? 0);
$stmt = $db->prepare("SELECT tr.*, u.username FROM tournament_registrations tr JOIN users u ON u.id = tr.user_id WHERE tr.tournament_id = ? ORDER BY tr.slot_number");
$stmt->execute([$tId]);
jsonResponse(['success'=>true,'participants'=>$stmt->fetchAll()]);

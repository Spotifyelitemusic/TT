<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$s=$db->prepare("SELECT u.id,u.username,u.avatar,(SELECT message FROM chat_messages WHERE user_id=u.id ORDER BY created_at DESC LIMIT 1) as last_message,(SELECT COUNT(*) FROM chat_messages WHERE user_id=u.id AND sender='user' AND is_read=0) as unread_count FROM users u WHERE EXISTS(SELECT 1 FROM chat_messages WHERE user_id=u.id) ORDER BY (SELECT created_at FROM chat_messages WHERE user_id=u.id ORDER BY created_at DESC LIMIT 1) DESC");
$s->execute();
jsonResponse(['success'=>true,'users'=>$s->fetchAll()]);

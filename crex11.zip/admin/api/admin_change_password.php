<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();$current=$_POST['current_password']??'';$new=$_POST['new_password']??'';
$stmt=$db->prepare("SELECT * FROM admins WHERE id=?");$stmt->execute([$_SESSION['admin_id']]);$admin=$stmt->fetch();
if(!verifyPassword($current,$admin['password'])){jsonResponse(['success'=>false,'message'=>'Current password incorrect']);}
if(strlen($new)<6){jsonResponse(['success'=>false,'message'=>'New password must be 6+ chars']);}
$db->prepare("UPDATE admins SET password=? WHERE id=?")->execute([hashPassword($new),$_SESSION['admin_id']]);
jsonResponse(['success'=>true,'message'=>'Password changed successfully!']);

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input=json_decode(file_get_contents('php://input'),true);
$type=$input['type']??'';$id=(int)($input['id']??0);
$db=getDB();
$tables=['tournament'=>'tournaments','match'=>'matches','game'=>'games','banner'=>'promotions','coupon'=>'coupons','leaderboard'=>'leaderboard'];
if(!isset($tables[$type])||!$id){jsonResponse(['success'=>false,'message'=>'Invalid']);}
$db->prepare("DELETE FROM {$tables[$type]} WHERE id=?")->execute([$id]);
jsonResponse(['success'=>true,'message'=>'Deleted!']);

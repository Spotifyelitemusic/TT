<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input = json_decode(file_get_contents('php://input'), true);
$matchId = (int)($input['match_id'] ?? 0);
$winner = sanitize($input['winner'] ?? '');
$db = getDB();
$stmt = $db->prepare("SELECT * FROM matches WHERE id=?");
$stmt->execute([$matchId]);
$match = $stmt->fetch();
if (!$match) { jsonResponse(['success'=>false,'message'=>'Match not found']); }
$db->prepare("UPDATE matches SET status='completed',winner=? WHERE id=?")->execute([$winner,$matchId]);
$bets = $db->prepare("SELECT * FROM bets WHERE match_id=? AND status='pending'");
$bets->execute([$matchId]);
$allBets = $bets->fetchAll();
$settled = 0;
foreach ($allBets as $bet) {
    if (trim(strtolower($bet['pick'])) === trim(strtolower($winner))) {
        $db->prepare("UPDATE bets SET status='won',settled_at=NOW() WHERE id=?")->execute([$bet['id']]);
        addBalance($bet['user_id'],$bet['potential_win'],'winning','win',"Match win: {$match['team1']} vs {$match['team2']}");
        $db->prepare("UPDATE users SET total_wins=total_wins+1 WHERE id=?")->execute([$bet['user_id']]);
        sendNotification($bet['user_id'],'You Won!','Congratulations! Your bet won ₹'.$bet['potential_win'].'. Amount credited.','success');
    } else {
        $db->prepare("UPDATE bets SET status='lost',settled_at=NOW() WHERE id=?")->execute([$bet['id']]);
        sendNotification($bet['user_id'],'Bet Lost','Your bet on '.$bet['pick'].' lost. Better luck next time!','error');
    }
    $settled++;
}
jsonResponse(['success'=>true,'message'=>'Match settled','settled_bets'=>$settled]);

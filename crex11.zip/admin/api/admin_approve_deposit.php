<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
$action = $input['action'] ?? 'approve';
$note = sanitize($input['note'] ?? '');
$db = getDB();
$stmt = $db->prepare("SELECT * FROM deposits WHERE id = ? AND status = 'pending'");
$stmt->execute([$id]);
$dep = $stmt->fetch();
if (!$dep) { jsonResponse(['success'=>false,'message'=>'Deposit not found or already processed']); }
if ($action === 'approve') {
    $db->prepare("UPDATE deposits SET status = 'approved', updated_at = NOW() WHERE id = ?")->execute([$id]);
    addBalance($dep['user_id'], $dep['amount'], 'cash', 'deposit', 'Deposit approved', $dep['utr_number']);
    sendNotification($dep['user_id'], 'Deposit Approved!', "Your deposit of ₹{$dep['amount']} has been approved and credited!", 'success');
    jsonResponse(['success'=>true,'message'=>'Deposit approved and balance credited']);
} else {
    $db->prepare("UPDATE deposits SET status = 'rejected', admin_note = ?, updated_at = NOW() WHERE id = ?")->execute([$note, $id]);
    sendNotification($dep['user_id'], 'Deposit Rejected', "Your deposit of ₹{$dep['amount']} was rejected. Reason: $note", 'error');
    jsonResponse(['success'=>true,'message'=>'Deposit rejected']);
}

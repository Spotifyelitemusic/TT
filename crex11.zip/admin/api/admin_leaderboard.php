<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $input=json_decode(file_get_contents('php://input'),true);
    $action=$input['action']??'';
    if($action==='add'){
        $db->prepare("INSERT INTO leaderboard (user_id,points,period) VALUES (?,?,'monthly') ON DUPLICATE KEY UPDATE points=?")->execute([$input['user_id'],$input['points'],$input['points']]);
        jsonResponse(['success'=>true,'message'=>'Entry added']);
    }
}
$s=$db->prepare("SELECT l.*,u.username FROM leaderboard l JOIN users u ON u.id=l.user_id ORDER BY l.points DESC LIMIT 100");
$s->execute();
jsonResponse(['success'=>true,'entries'=>$s->fetchAll()]);

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false,'message'=>'Unauthorized']); }
$db = getDB();
$page = (int)($_GET['page'] ?? 1);
$limit = (int)($_GET['limit'] ?? 20);
$search = sanitize($_GET['search'] ?? '');
$offset = ($page - 1) * $limit;
$where = $search ? "WHERE username LIKE ? OR email LIKE ?" : "";
$params = $search ? ["%$search%", "%$search%"] : [];
$total = $db->prepare("SELECT COUNT(*) FROM users $where");
$total->execute($params);
$totalCount = $total->fetchColumn();
$stmt = $db->prepare("SELECT * FROM users $where ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
$stmt->execute($params);
jsonResponse(['success'=>true,'users'=>$stmt->fetchAll(),'total'=>$totalCount]);

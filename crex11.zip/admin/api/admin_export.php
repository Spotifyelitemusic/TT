<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { header('HTTP/1.1 401 Unauthorized'); exit; }
$type=$_GET['type']??'users';$db=getDB();
header('Content-Type: text/csv');header('Content-Disposition: attachment;filename="'.$type.'_export.csv"');
$out=fopen('php://output','w');
if($type==='users'){
    fputcsv($out,['ID','Username','Email','Phone','Cash','Bonus','Winnings','KYC','Joined']);
    $s=$db->query("SELECT id,username,email,phone,cash_balance,bonus_balance,winning_balance,kyc_status,created_at FROM users");
    while($r=$s->fetch())fputcsv($out,$r);
}
fclose($out);exit;

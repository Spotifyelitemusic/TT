<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
$status = $_GET['status'] ?? 'pending';
$limit = (int)($_GET['limit'] ?? 100);
$where = $status === 'all' ? '' : "WHERE d.status = '$status'";
$stmt = $db->prepare("SELECT d.*, u.username, u.email FROM deposits d JOIN users u ON u.id = d.user_id $where ORDER BY d.created_at DESC LIMIT $limit");
$stmt->execute();
jsonResponse(['success'=>true,'deposits'=>$stmt->fetchAll()]);

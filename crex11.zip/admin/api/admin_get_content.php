<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$key=sanitize($_GET['key']??'');
jsonResponse(['success'=>true,'value'=>getSetting($key,'')]);

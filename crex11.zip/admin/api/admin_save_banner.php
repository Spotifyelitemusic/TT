<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$id=(int)($_POST['id']??0);
$imgPath='';
if(!empty($_FILES['image']['tmp_name'])){$u=uploadFile($_FILES['image'],'banners');if($u['success'])$imgPath=$u['path'];}
$title=sanitize($_POST['title']??'');$link=sanitize($_POST['link_url']??'');$sort=(int)($_POST['sort_order']??0);$active=(int)($_POST['is_active']??1);
if($id){
    $sql="UPDATE promotions SET title=?,link_url=?,sort_order=?,is_active=?".($imgPath?",image=?":'')." WHERE id=?";
    $v=[$title,$link,$sort,$active];if($imgPath)$v[]=$imgPath;$v[]=$id;
    $db->prepare($sql)->execute($v);
}else{
    if(!$imgPath){jsonResponse(['success'=>false,'message'=>'Image required']);}
    $db->prepare("INSERT INTO promotions (title,image,link_url,sort_order,is_active) VALUES (?,?,?,?,?)")->execute([$title,$imgPath,$link,$sort,$active]);
}
jsonResponse(['success'=>true,'message'=>'Banner saved!']);

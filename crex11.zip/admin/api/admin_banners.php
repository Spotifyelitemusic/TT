<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
if(isset($_GET['id'])){$s=$db->prepare("SELECT * FROM promotions WHERE id=?");$s->execute([(int)$_GET['id']]);jsonResponse(['success'=>true,'banner'=>$s->fetch()]);}
$s=$db->prepare("SELECT * FROM promotions ORDER BY sort_order,id DESC");$s->execute();
jsonResponse(['success'=>true,'banners'=>$s->fetchAll()]);

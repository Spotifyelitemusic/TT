<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input=json_decode(file_get_contents('php://input'),true);
$key=sanitize($input['key']??'');$value=$input['value']??'';
if(!$key){jsonResponse(['success'=>false,'message'=>'Invalid key']);}
setSetting($key,$value);
jsonResponse(['success'=>true,'message'=>'Saved!']);

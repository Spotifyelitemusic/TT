<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();$status=$_GET['status']??'submitted';
$s=$db->prepare("SELECT k.*,u.username,u.email FROM kyc_verifications k JOIN users u ON u.id=k.user_id WHERE k.status=? ORDER BY k.submitted_at DESC");
$s->execute([$status]);
jsonResponse(['success'=>true,'kyc'=>$s->fetchAll()]);

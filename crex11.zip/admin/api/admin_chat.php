<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();$userId=(int)($_GET['user_id']??0);
$s=$db->prepare("SELECT * FROM chat_messages WHERE user_id=? ORDER BY created_at ASC LIMIT 100");$s->execute([$userId]);
$db->prepare("UPDATE chat_messages SET is_read=1 WHERE user_id=? AND sender='user'")->execute([$userId]);
jsonResponse(['success'=>true,'messages'=>$s->fetchAll()]);

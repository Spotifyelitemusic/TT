<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
if (isset($_GET['id'])) {
    $stmt = $db->prepare("SELECT t.*, g.name as game_name FROM tournaments t LEFT JOIN games g ON g.id = t.game_id WHERE t.id = ?");
    $stmt->execute([(int)$_GET['id']]);
    $t = $stmt->fetch();
    jsonResponse(['success'=>true,'tournament'=>$t]);
}
$stmt = $db->prepare("SELECT t.*, g.name as game_name FROM tournaments t LEFT JOIN games g ON g.id = t.game_id ORDER BY t.created_at DESC");
$stmt->execute();
jsonResponse(['success'=>true,'tournaments'=>$stmt->fetchAll()]);

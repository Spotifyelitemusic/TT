<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input=json_decode(file_get_contents('php://input'),true);
$userId=(int)($input['user_id']??0);$action=$input['action']??'verify';$note=sanitize($input['note']??'');
$db=getDB();
if($action==='verify'){
    $db->prepare("UPDATE kyc_verifications SET status='verified',reviewed_at=NOW() WHERE user_id=?")->execute([$userId]);
    $db->prepare("UPDATE users SET kyc_status='verified' WHERE id=?")->execute([$userId]);
    sendNotification($userId,'KYC Verified!','Your identity has been successfully verified.','success');
}else{
    $db->prepare("UPDATE kyc_verifications SET status='rejected',admin_note=?,reviewed_at=NOW() WHERE user_id=?")->execute([$note,$userId]);
    $db->prepare("UPDATE users SET kyc_status='rejected' WHERE id=?")->execute([$userId]);
    sendNotification($userId,'KYC Rejected',"KYC rejected. Reason: $note. Please re-submit.",'error');
}
jsonResponse(['success'=>true,'message'=>$action==='verify'?'KYC verified!':'KYC rejected.']);

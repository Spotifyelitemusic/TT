<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$s=$db->prepare("SELECT * FROM coupons WHERE is_active=1 AND expires_at > NOW() ORDER BY created_at DESC");$s->execute();
jsonResponse(['success'=>true,'coupons'=>$s->fetchAll()]);

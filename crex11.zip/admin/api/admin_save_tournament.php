<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
$id = (int)($_POST['id'] ?? 0);
$bannerPath = '';
if (!empty($_FILES['banner_image']['tmp_name'])) {
    $up = uploadFile($_FILES['banner_image'], 'banners');
    if ($up['success']) $bannerPath = $up['path'];
}
$fields = ['title','game_id','tournament_type','entry_fee','prize_pool','max_slots','per_kill_prize','start_time','end_time','map','version','status','room_id','room_password','rules','prize_distribution'];
$data = [];
foreach ($fields as $f) $data[$f] = sanitize($_POST[$f] ?? '');
if ($id) {
    $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($data)));
    $vals = array_values($data);
    if ($bannerPath) { $sets .= ',banner_image=?'; $vals[] = $bannerPath; }
    $vals[] = $id;
    $db->prepare("UPDATE tournaments SET $sets WHERE id=?")->execute($vals);
} else {
    $cols = implode(',', array_keys($data));
    $placeholders = implode(',', array_fill(0, count($data), '?'));
    $vals = array_values($data);
    if ($bannerPath) { $cols .= ',banner_image'; $placeholders .= ',?'; $vals[] = $bannerPath; }
    $db->prepare("INSERT INTO tournaments ($cols) VALUES ($placeholders)")->execute($vals);
}
jsonResponse(['success'=>true,'message'=>'Tournament saved!']);

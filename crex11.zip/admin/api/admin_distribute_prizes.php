<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input = json_decode(file_get_contents('php://input'), true);
$tId = (int)($input['tournament_id'] ?? 0);
$participants = $input['participants'] ?? [];
$db = getDB();
foreach ($participants as $p) {
    $userId = (int)$p['user_id'];
    $prize = (float)$p['prize'];
    $kills = (int)$p['kills'];
    $rank = (int)$p['rank'];
    $db->prepare("UPDATE tournament_registrations SET rank_position=?,kills=?,prize_won=?,status=? WHERE tournament_id=? AND user_id=?")
       ->execute([$rank,$kills,$prize,$prize>0?'winner':'confirmed',$tId,$userId]);
    if ($prize > 0) {
        addBalance($userId,$prize,'winning','win',"Tournament prize - Rank #$rank","tourn_$tId");
        sendNotification($userId,'Prize Credited!',"Congratulations! ₹$prize prize credited for rank #$rank in tournament.",'success');
        $db->prepare("UPDATE users SET total_wins = total_wins + 1 WHERE id=?")->execute([$userId]);
    }
}
$db->prepare("UPDATE tournaments SET status='completed' WHERE id=?")->execute([$tId]);
jsonResponse(['success'=>true,'message'=>'Prizes distributed successfully!']);

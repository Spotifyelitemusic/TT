<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
$id = (int)($_POST['id'] ?? 0);
$t1Logo = $t2Logo = '';
if (!empty($_FILES['team1_logo']['tmp_name'])) { $u=uploadFile($_FILES['team1_logo'],'games'); if($u['success']) $t1Logo=$u['path']; }
if (!empty($_FILES['team2_logo']['tmp_name'])) { $u=uploadFile($_FILES['team2_logo'],'games'); if($u['success']) $t2Logo=$u['path']; }
$fields=['team1','team2','match_type','start_time','status','odds_team1','odds_team2','winner'];
$data=[];
foreach($fields as $f) $data[$f]=sanitize($_POST[$f]??'');
if($id){
    $sets=implode(',',array_map(fn($k)=>"$k=?",array_keys($data)));
    $vals=array_values($data);
    if($t1Logo){$sets.=',team1_logo=?';$vals[]=$t1Logo;}
    if($t2Logo){$sets.=',team2_logo=?';$vals[]=$t2Logo;}
    $vals[]=$id;
    $db->prepare("UPDATE matches SET $sets WHERE id=?")->execute($vals);
} else {
    $cols=implode(',',array_keys($data));
    $ph=implode(',',array_fill(0,count($data),'?'));
    $vals=array_values($data);
    if($t1Logo){$cols.=',team1_logo';$ph.=',?';$vals[]=$t1Logo;}
    if($t2Logo){$cols.=',team2_logo';$ph.=',?';$vals[]=$t2Logo;}
    $db->prepare("INSERT INTO matches ($cols) VALUES ($ph)")->execute($vals);
}
jsonResponse(['success'=>true,'message'=>'Match saved!']);

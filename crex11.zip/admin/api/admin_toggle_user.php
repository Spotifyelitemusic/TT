<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input = json_decode(file_get_contents('php://input'), true);
$userId = (int)($input['user_id'] ?? 0);
$isActive = (int)($input['is_active'] ?? 1);
$db = getDB();
$db->prepare("UPDATE users SET is_active = ? WHERE id = ?")->execute([$isActive, $userId]);
jsonResponse(['success'=>true,'message'=>$isActive ? 'User activated' : 'User banned']);

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();
$userGrowth=$db->query("SELECT DATE(created_at) as date,COUNT(*) as count FROM users WHERE created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date")->fetchAll();
$depositStats=$db->query("SELECT DATE(created_at) as date,SUM(amount) as total FROM deposits WHERE status='approved' AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date")->fetchAll();
$betStats=$db->query("SELECT status,COUNT(*) as count FROM bets GROUP BY status")->fetchAll();
$betMap=[];foreach($betStats as $b)$betMap[$b['status']]=$b['count'];
$topUsers=$db->query("SELECT username,(cash_balance+bonus_balance+winning_balance) as total FROM users ORDER BY total DESC LIMIT 10")->fetchAll();
jsonResponse(['success'=>true,'user_growth'=>$userGrowth,'deposit_stats'=>$depositStats,'bet_stats'=>$betMap,'top_users'=>$topUsers]);

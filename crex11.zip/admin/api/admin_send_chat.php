<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input=json_decode(file_get_contents('php://input'),true);
$userId=(int)($input['user_id']??0);$msg=trim($input['message']??'');
if(!$userId||!$msg){jsonResponse(['success'=>false,'message'=>'Invalid']);}
$db=getDB();
$db->prepare("INSERT INTO chat_messages (user_id,sender,message) VALUES (?,'admin',?)")->execute([$userId,$msg]);
sendNotification($userId,'New Support Message','Admin has replied to your support query.','info');
jsonResponse(['success'=>true]);

<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
if (isset($_GET['id'])) {
    $stmt = $db->prepare("SELECT * FROM matches WHERE id=?");
    $stmt->execute([(int)$_GET['id']]);
    jsonResponse(['success'=>true,'match'=>$stmt->fetch()]);
}
$stmt = $db->prepare("SELECT m.*, (SELECT COUNT(*) FROM bets WHERE match_id=m.id) as bet_count FROM matches m ORDER BY m.start_time DESC");
$stmt->execute();
jsonResponse(['success'=>true,'matches'=>$stmt->fetchAll()]);

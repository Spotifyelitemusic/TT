<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
$action = $input['action'] ?? 'approve';
$note = sanitize($input['note'] ?? '');
$db = getDB();
$stmt = $db->prepare("SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'");
$stmt->execute([$id]);
$w = $stmt->fetch();
if (!$w) { jsonResponse(['success'=>false,'message'=>'Not found or already processed']); }
if ($action === 'approve') {
    $db->prepare("UPDATE withdrawals SET status='approved',admin_note=?,updated_at=NOW() WHERE id=?")->execute([$note,$id]);
    $db->prepare("UPDATE transactions SET status='completed' WHERE user_id=? AND type='withdrawal' AND status='pending' ORDER BY created_at DESC LIMIT 1")->execute([$w['user_id']]);
    sendNotification($w['user_id'],'Withdrawal Approved!',"Your withdrawal of ₹{$w['amount']} has been approved and will be transferred shortly.",'success');
    jsonResponse(['success'=>true,'message'=>'Withdrawal approved']);
} else {
    $db->prepare("UPDATE withdrawals SET status='rejected',admin_note=?,updated_at=NOW() WHERE id=?")->execute([$note,$id]);
    // Refund balance
    addBalance($w['user_id'],$w['amount'],'winning','refund',"Withdrawal rejected: $note");
    sendNotification($w['user_id'],'Withdrawal Rejected',"Your withdrawal of ₹{$w['amount']} was rejected. Balance refunded. Reason: $note",'error');
    jsonResponse(['success'=>true,'message'=>'Withdrawal rejected and balance refunded']);
}

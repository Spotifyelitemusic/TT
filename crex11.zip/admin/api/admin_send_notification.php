<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db=getDB();$title=sanitize($_POST['title']??'');$msg=sanitize($_POST['message']??'');$type=sanitize($_POST['type']??'info');$targetType=$_POST['target_type']??'user';
if(!$title||!$msg){jsonResponse(['success'=>false,'message'=>'Fill all fields']);}
if($targetType==='all'){
    $db->prepare("INSERT INTO notifications (user_id,title,message,type,is_global) VALUES (NULL,?,?,?,1)")->execute([$title,$msg,$type]);
    jsonResponse(['success'=>true,'message'=>'Broadcast sent!']);
}else{
    $target=sanitize($_POST['target']??'');
    if(!$target){jsonResponse(['success'=>false,'message'=>'Enter user ID or email']);}
    $s=is_numeric($target)?$db->prepare("SELECT id FROM users WHERE id=?"):$db->prepare("SELECT id FROM users WHERE email=?");
    $s->execute([$target]);$user=$s->fetch();
    if(!$user){jsonResponse(['success'=>false,'message'=>'User not found']);}
    sendNotification($user['id'],$title,$msg,$type);
    jsonResponse(['success'=>true,'message'=>'Notification sent!']);
}

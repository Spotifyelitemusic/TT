<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
if (isset($_GET['id'])) { $s=$db->prepare("SELECT * FROM games WHERE id=?");$s->execute([(int)$_GET['id']]);jsonResponse(['success'=>true,'game'=>$s->fetch()]); }
$s=$db->prepare("SELECT * FROM games ORDER BY sort_order,name");$s->execute();
jsonResponse(['success'=>true,'games'=>$s->fetchAll()]);

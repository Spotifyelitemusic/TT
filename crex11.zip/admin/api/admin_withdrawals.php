<?php
require_once __DIR__ . '/../../includes/auth.php';
session_start();
if (empty($_SESSION['admin_id'])) { jsonResponse(['success'=>false]); }
$db = getDB();
$status = $_GET['status'] ?? 'pending';
$where = $status === 'all' ? '' : "WHERE w.status = '$status'";
$stmt = $db->prepare("SELECT w.*, u.username FROM withdrawals w JOIN users u ON u.id = w.user_id $where ORDER BY w.created_at DESC");
$stmt->execute();
jsonResponse(['success'=>true,'withdrawals'=>$stmt->fetchAll()]);
